Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents FocusedTextBox1 As FocusedTextbox.FocusedTextBox
    Friend WithEvents FocusedTextBox2 As FocusedTextbox.FocusedTextBox
    Friend WithEvents FocusedTextBox3 As FocusedTextbox.FocusedTextBox
    Friend WithEvents FocusedTextBox4 As FocusedTextbox.FocusedTextBox
    Friend WithEvents FocusedTextBox5 As FocusedTextbox.FocusedTextBox
    Friend WithEvents FocusedTextBox6 As FocusedTextbox.FocusedTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.FocusedTextBox1 = New FocusedTextbox.FocusedTextBox()
        Me.FocusedTextBox2 = New FocusedTextbox.FocusedTextBox()
        Me.FocusedTextBox3 = New FocusedTextbox.FocusedTextBox()
        Me.FocusedTextBox4 = New FocusedTextbox.FocusedTextBox()
        Me.FocusedTextBox5 = New FocusedTextbox.FocusedTextBox()
        Me.FocusedTextBox6 = New FocusedTextbox.FocusedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'FocusedTextBox1
        '
        Me.FocusedTextBox1.EnterFocusColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.FocusedTextBox1.LeaveFocusColor = System.Drawing.Color.Empty
        Me.FocusedTextBox1.Location = New System.Drawing.Point(124, 20)
        Me.FocusedTextBox1.Mandatory = True
        Me.FocusedTextBox1.MandatoryColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(192, Byte))
        Me.FocusedTextBox1.Name = "FocusedTextBox1"
        Me.FocusedTextBox1.Size = New System.Drawing.Size(176, 20)
        Me.FocusedTextBox1.TabIndex = 0
        Me.FocusedTextBox1.Text = ""
        '
        'FocusedTextBox2
        '
        Me.FocusedTextBox2.EnterFocusColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.FocusedTextBox2.LeaveFocusColor = System.Drawing.Color.Empty
        Me.FocusedTextBox2.Location = New System.Drawing.Point(124, 55)
        Me.FocusedTextBox2.MandatoryColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(192, Byte))
        Me.FocusedTextBox2.Name = "FocusedTextBox2"
        Me.FocusedTextBox2.Size = New System.Drawing.Size(266, 20)
        Me.FocusedTextBox2.TabIndex = 1
        Me.FocusedTextBox2.Text = ""
        '
        'FocusedTextBox3
        '
        Me.FocusedTextBox3.EnterFocusColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.FocusedTextBox3.LeaveFocusColor = System.Drawing.Color.Empty
        Me.FocusedTextBox3.Location = New System.Drawing.Point(124, 90)
        Me.FocusedTextBox3.MandatoryColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(192, Byte))
        Me.FocusedTextBox3.Name = "FocusedTextBox3"
        Me.FocusedTextBox3.Size = New System.Drawing.Size(138, 20)
        Me.FocusedTextBox3.TabIndex = 2
        Me.FocusedTextBox3.Text = ""
        '
        'FocusedTextBox4
        '
        Me.FocusedTextBox4.EnterFocusColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.FocusedTextBox4.LeaveFocusColor = System.Drawing.Color.Empty
        Me.FocusedTextBox4.Location = New System.Drawing.Point(124, 125)
        Me.FocusedTextBox4.MandatoryColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(192, Byte))
        Me.FocusedTextBox4.Name = "FocusedTextBox4"
        Me.FocusedTextBox4.Size = New System.Drawing.Size(206, 20)
        Me.FocusedTextBox4.TabIndex = 3
        Me.FocusedTextBox4.Text = ""
        '
        'FocusedTextBox5
        '
        Me.FocusedTextBox5.EnterFocusColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.FocusedTextBox5.LeaveFocusColor = System.Drawing.Color.Empty
        Me.FocusedTextBox5.Location = New System.Drawing.Point(124, 160)
        Me.FocusedTextBox5.MandatoryColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(192, Byte))
        Me.FocusedTextBox5.Name = "FocusedTextBox5"
        Me.FocusedTextBox5.TabIndex = 4
        Me.FocusedTextBox5.Text = ""
        '
        'FocusedTextBox6
        '
        Me.FocusedTextBox6.EnterFocusColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.FocusedTextBox6.LeaveFocusColor = System.Drawing.Color.Empty
        Me.FocusedTextBox6.Location = New System.Drawing.Point(124, 195)
        Me.FocusedTextBox6.Mandatory = True
        Me.FocusedTextBox6.MandatoryColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(192, Byte))
        Me.FocusedTextBox6.Name = "FocusedTextBox6"
        Me.FocusedTextBox6.Size = New System.Drawing.Size(232, 20)
        Me.FocusedTextBox6.TabIndex = 5
        Me.FocusedTextBox6.Text = ""
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(108, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Name"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(4, 57)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(108, 17)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Address"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(108, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "City"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(4, 127)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(108, 17)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "State ZIP"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(4, 197)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(108, 17)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "EMail"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 162)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(108, 17)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Phone"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(398, 235)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label6, Me.Label5, Me.Label4, Me.Label3, Me.Label2, Me.Label1, Me.FocusedTextBox6, Me.FocusedTextBox5, Me.FocusedTextBox4, Me.FocusedTextBox3, Me.FocusedTextBox2, Me.FocusedTextBox1})
        Me.Name = "Form1"
        Me.Text = "FocusedTextBox Test Form"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FocusedTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FocusedTextBox1.TextChanged

    End Sub
End Class
