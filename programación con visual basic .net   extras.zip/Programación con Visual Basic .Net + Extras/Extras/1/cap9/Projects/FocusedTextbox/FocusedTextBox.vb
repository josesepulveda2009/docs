Imports System.ComponentModel

<DefaultProperty("Mandatorry")> Public Class FocusedTextBox
    Inherits TextBox

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'FocusedTextBox
        '
        Me.Name = "FocusedTextBox"

    End Sub

#End Region

    Dim _mandatory As Boolean
    Dim _enterFocusColor, _leaveFocusColor As Color
    Dim _mandatoryColor As Color

    <Description("Indicates whether the control can be left blank"), _
     Category("Behavior"), DefaultValue(False)> _
    Property Mandatory() As Boolean
        Get
            Mandatory = _mandatory
        End Get
        Set(ByVal Value As Boolean)
            _mandatory = Value
        End Set
    End Property

    <Description("The color of the control when it receives focus"), _
     Category("Appearance")> _
     Property EnterFocusColor() As Color
        Get
            EnterFocusColor = _enterFocusColor
        End Get
        Set(ByVal Value As Color)
            _enterFocusColor = Value
        End Set
    End Property

    <Description("The color of the control when it looses focus"), _
     Category("Appearance")> _
    Property LeaveFocusColor() As Color
        Get
            LeaveFocusColor = _leaveFocusColor
        End Get
        Set(ByVal Value As Color)
            _leaveFocusColor = Value
        End Set
    End Property

    <Description("The color of the control when Mandatory = True and the control is empty"), _
     Category("Appearance"), DefaultValue("False")> _
    Property MandatoryColor() As Color
        Get
            MandatoryColor = _mandatoryColor
        End Get
        Set(ByVal Value As Color)
            _mandatoryColor = Value
        End Set
    End Property

    Private Sub FocusedTextBox_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Enter
        Me.BackColor = _enterFocusColor
    End Sub

    Private Sub FocusedTextBox_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        If Trim(Me.Text).Length = 0 And _mandatory Then
            Me.BackColor = _mandatoryColor
        Else
            Me.BackColor = _leaveFocusColor
        End If
        If IsNumeric(Me.Text) Then
            Me.Text = FormatCurrency(Me.Text, 2, False, True, True)
            If Val(Me.Text) < 0 Then
                Me.Text = "(" & Me.Text & ")"
            End If
        End If

    End Sub

End Class
