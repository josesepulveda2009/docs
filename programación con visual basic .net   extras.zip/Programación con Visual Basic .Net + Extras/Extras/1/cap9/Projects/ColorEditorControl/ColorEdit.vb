Public Class ColorEdit
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents HScrollBar1 As System.Windows.Forms.HScrollBar
    Friend WithEvents HScrollBar2 As System.Windows.Forms.HScrollBar
    Friend WithEvents HScrollBar3 As System.Windows.Forms.HScrollBar
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.HScrollBar2 = New System.Windows.Forms.HScrollBar()
        Me.HScrollBar3 = New System.Windows.Forms.HScrollBar()
        Me.HScrollBar1 = New System.Windows.Forms.HScrollBar()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Black
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Location = New System.Drawing.Point(3, 2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(150, 104)
        Me.Label1.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(163, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 15)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Red"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(163, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Green"
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownWidth = 157
        Me.ComboBox1.Location = New System.Drawing.Point(5, 114)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(157, 21)
        Me.ComboBox1.TabIndex = 7
        Me.ComboBox1.Text = "ComboBox1"
        '
        'HScrollBar2
        '
        Me.HScrollBar2.Location = New System.Drawing.Point(163, 70)
        Me.HScrollBar2.Maximum = 255
        Me.HScrollBar2.Name = "HScrollBar2"
        Me.HScrollBar2.Size = New System.Drawing.Size(212, 16)
        Me.HScrollBar2.TabIndex = 2
        '
        'HScrollBar3
        '
        Me.HScrollBar3.Location = New System.Drawing.Point(163, 118)
        Me.HScrollBar3.Maximum = 255
        Me.HScrollBar3.Name = "HScrollBar3"
        Me.HScrollBar3.Size = New System.Drawing.Size(210, 16)
        Me.HScrollBar3.TabIndex = 3
        '
        'HScrollBar1
        '
        Me.HScrollBar1.Location = New System.Drawing.Point(163, 26)
        Me.HScrollBar1.Maximum = 255
        Me.HScrollBar1.Name = "HScrollBar1"
        Me.HScrollBar1.Size = New System.Drawing.Size(212, 16)
        Me.HScrollBar1.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(163, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Blue"
        '
        'ctrlColorEditor
        '
        Me.BackColor = System.Drawing.Color.LightGray
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ComboBox1, Me.Label4, Me.Label3, Me.Label2, Me.HScrollBar3, Me.HScrollBar2, Me.HScrollBar1, Me.Label1})
        Me.Name = "ctrlColorEditor"
        Me.Size = New System.Drawing.Size(378, 138)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub HScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar1.Scroll, HScrollBar2.Scroll, HScrollBar3.Scroll
        ComboBox1.SelectedItem = "Unknown"
        ShowColor()
    End Sub

    Sub ShowColor()
        Label1.BackColor = Color.FromArgb(255, HScrollBar1.Value, HScrollBar2.Value, HScrollBar3.Value)
    End Sub

    Private Sub ctrlColorEditor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AddNamedColors()
    End Sub

    Property SelectedColor() As Color
        Get
            SelectedColor = Label1.BackColor
        End Get
        Set(ByVal Value As Color)
            HScrollBar1.Value = Value.R
            HScrollBar2.Value = Value.G
            HScrollBar3.Value = Value.B
            ShowColor()
        End Set
    End Property

    ReadOnly Property NamedColor() As String
        Get
            NamedColor = ComboBox1.SelectedItem
        End Get
    End Property

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim namedColor As Color
        Dim colorName As String
        colorName = ComboBox1.SelectedItem
        If colorName <> "Unknown" Then
            namedColor = Color.FromName(colorName)
            HScrollBar1.Value = namedColor.R
            HScrollBar2.Value = namedColor.G
            HScrollBar3.Value = namedColor.B
            ShowColor()
        End If
    End Sub


    Private Sub AddNamedColors()
        With ComboBox1.Items
            .Add("AliceBlue")
            .Add("AntiqueWhite")
            .Add("Aqua")
            .Add("Aquamarine")
            .Add("Azure")
            .Add("Beige")
            .Add("Bisque")
            .Add("Black")
            .Add("BlanchedAlmond")
            .Add("Blue")
            .Add("BlueViolet")
            .Add("Brown")
            .Add("BurlyWood")
            .Add("CadetBlue")
            .Add("Chartreuse")
            .Add("Chocolate")
            .Add("Coral")
            .Add("Cornflower")
            .Add("Cornsilk")
            .Add("Crimson")
            .Add("Cyan")
            .Add("DarkBlue")
            .Add("DarkCyan")
            .Add("DarkGoldenrod")
            .Add("DarkGray")
            .Add("DarkGreen")
            .Add("DarkKhaki")
            .Add("DarkMagenta")
            .Add("DarkOliveGreen")
            .Add("DarkOrange")
            .Add("DarkOrchid")
            .Add("DarkRed")
            .Add("DarkSalmon")
            .Add("DarkSeaGreen")
            .Add("DarkSlateBlue")
            .Add("DarkSlateGray")
            .Add("DarkTurquoise")
            .Add("DarkViolet")
            .Add("DeepPink")
            .Add("DeepSkyBlue")
            .Add("DimGray")
            .Add("DodgerBlue")
            .Add("Firebrick")
            .Add("FloralWhite")
            .Add("ForestGreen")
            .Add("Fuchsia")
            .Add("Gainsboro")
            .Add("GhostWhite")
            .Add("Gold")
            .Add("Goldenrod")
            .Add("Gray")
            .Add("Green")
            .Add("GreenYellow")
            .Add("Honeydew")
            .Add("HotPink")
            .Add("IndianRed")
            .Add("Indigo")
            .Add("Ivory")
            .Add("Khaki")
            .Add("Lavender")
            .Add("LavenderBlush")
            .Add("LawnGreen")
            .Add("LemonChiffon")
            .Add("LightBlue")
            .Add("LightCoral")
            .Add("LightCyan")
            .Add("LightGoldenrodYellow")
            .Add("LightGray")
            .Add("LightGreen")
            .Add("LightPink")
            .Add("LightSalmon")
            .Add("LightSeaGreen")
            .Add("LightSkyBlue")
            .Add("LightSlateGray")
            .Add("LightSteelBlue")
            .Add("LightYellow")
            .Add("Lime")
            .Add("LimeGreen")
            .Add("Linen")
            .Add("Magenta")
            .Add("Maroon")
            .Add("MediumAquamarine")
            .Add("MediumBlue")
            .Add("MediumOrchid")
            .Add("MediumPurple")
            .Add("MediumSeaGreen")
            .Add("MediumSlateBlue")
            .Add("MediumSpringGreen")
            .Add("MediumTurquoise")
            .Add("MediumVioletRed")
            .Add("MidnightBlue")
            .Add("MintCream")
            .Add("MistyRose")
            .Add("Moccasin")
            .Add("NavajoWhite")
            .Add("Navy")
            .Add("OldLace")
            .Add("Olive")
            .Add("OliveDrab")
            .Add("Orange")
            .Add("OrangeRed")
            .Add("Orchid")
            .Add("PaleGoldenrod")
            .Add("PaleGreen")
            .Add("PaleTurquoise")
            .Add("PaleVioletRed")
            .Add("PapayaWhip")
            .Add("PeachPuff")
            .Add("Peru")
            .Add("Pink")
            .Add("Plum")
            .Add("PowderBlue")
            .Add("Purple")
            .Add("Red")
            .Add("RosyBrown")
            .Add("RoyalBlue")
            .Add("SaddleBrown")
            .Add("Salmon")
            .Add("SandyBrown")
            .Add("SeaGreen")
            .Add("SeaShell")
            .Add("Sienna")
            .Add("Silver")
            .Add("SkyBlue")
            .Add("SlateBlue")
            .Add("SlateGray")
            .Add("Snow")
            .Add("SpringGreen")
            .Add("SteelBlue")
            .Add("Tan")
            .Add("Teal")
            .Add("Thistle")
            .Add("Tomato")
            .Add("Transparent")
            .Add("Turquoise")
            .Add("Violet")
            .Add("Wheat")
            .Add("White")
            .Add("WhiteSmoke")
            .Add("Yellow")
            .Add("YellowGreen")
            .Add("Unknown")
        End With
        ComboBox1.SelectedItem = "Black"
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        e.Graphics.DrawRectangle(New Pen(Color.Silver, 2), 0, 0, Me.ClientRectangle.Width - 1, Me.ClientRectangle.Height - 1)
    End Sub

    Private Sub ctrlColorEditor_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Me.Width = 378
        Me.Height = 138
    End Sub

    Public Event ColorClick(ByVal sender As Object, ByVal e As ColorEvent)

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        Dim ev As ColorEvent
        ' set the color property of the EventArgs argument
        ev.color = Label1.BackColor
        ' and then raise the event ColorClick
        RaiseEvent ColorClick(Me, ev)
    End Sub

End Class

' create a new type of argument that exposes the color property
Public Class ColorEvent
    Inherits EventArgs
    Public Shared color As color
End Class