Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3D1 As FlexLabel.Label3D
    Friend WithEvents AlignmentBox As System.Windows.Forms.ComboBox
    Friend WithEvents EffectsBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3D1 = New FlexLabel.Label3D()
        Me.AlignmentBox = New System.Windows.Forms.ComboBox()
        Me.EffectsBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(342, 178)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(183, 27)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Text Font"
        '
        'Label3D1
        '
        Me.Label3D1.Alignment = FlexLabel.Label3D.Align.CenterMiddle
        Me.Label3D1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.Label3D1.Caption = "Label3D"
        Me.Label3D1.Effect = FlexLabel.Label3D.Effect3D.Raised
        Me.Label3D1.Font = New System.Drawing.Font("Comic Sans MS", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3D1.Location = New System.Drawing.Point(8, 8)
        Me.Label3D1.Name = "Label3D1"
        Me.Label3D1.Size = New System.Drawing.Size(518, 142)
        Me.Label3D1.TabIndex = 2
        '
        'AlignmentBox
        '
        Me.AlignmentBox.Location = New System.Drawing.Point(12, 184)
        Me.AlignmentBox.Name = "AlignmentBox"
        Me.AlignmentBox.Size = New System.Drawing.Size(159, 21)
        Me.AlignmentBox.TabIndex = 3
        Me.AlignmentBox.Text = "ComboBox1"
        '
        'EffectsBox
        '
        Me.EffectsBox.Location = New System.Drawing.Point(182, 184)
        Me.EffectsBox.Name = "EffectsBox"
        Me.EffectsBox.Size = New System.Drawing.Size(151, 21)
        Me.EffectsBox.TabIndex = 4
        Me.EffectsBox.Text = "ComboBox1"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(14, 162)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 21)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Text Alignment"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(178, 164)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 21)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Text Effect"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(14, 212)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(318, 20)
        Me.TextBox1.TabIndex = 7
        Me.TextBox1.Text = "FlexLabel control"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(534, 241)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1, Me.Label2, Me.Label1, Me.EffectsBox, Me.AlignmentBox, Me.Label3D1, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "FlexLabel Test Form"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Label3D1_AlignmentChanged(ByVal sender As System.Object, ByVal ev As System.EventArgs)
        MsgBox("Alignment changed")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AlignmentBox.Items.Add(Label3D1.Align.BottomLeft)
        AlignmentBox.Items.Add(Label3D1.Align.BottomMiddle)
        AlignmentBox.Items.Add(Label3D1.Align.BottomRight)
        AlignmentBox.Items.Add(Label3D1.Align.CenterLeft)
        AlignmentBox.Items.Add(Label3D1.Align.CenterMiddle)
        AlignmentBox.Items.Add(Label3D1.Align.CenterRight)
        AlignmentBox.Items.Add(Label3D1.Align.TopLeft)
        AlignmentBox.Items.Add(Label3D1.Align.TopMiddle)
        AlignmentBox.Items.Add(Label3D1.Align.TopRight)
        AlignmentBox.SelectedIndex = 4

        EffectsBox.Items.Add(Label3D1.Effect3D.Carved)
        EffectsBox.Items.Add(Label3D1.Effect3D.CarvedHeavy)
        EffectsBox.Items.Add(Label3D1.Effect3D.None)
        EffectsBox.Items.Add(Label3D1.Effect3D.Raised)
        EffectsBox.Items.Add(Label3D1.Effect3D.RaisedHeavy)
        EffectsBox.SelectedIndex = 3
    End Sub

    Private Sub AlignmentBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlignmentBox.SelectedIndexChanged
        Label3D1.Alignment = AlignmentBox.SelectedItem
    End Sub

    Private Sub EffectsBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EffectsBox.SelectedIndexChanged
        Label3D1.Effect = EffectsBox.SelectedItem
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        FontDialog1.Font = Label3D1.Font
        If FontDialog1.ShowDialog = DialogResult.OK Then
            Label3D1.Font = FontDialog1.Font
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Label3D1.Caption = TextBox1.Text
    End Sub

    Private Sub Label3D1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label3D1.Click
        MsgBox("My properties are " & vbCrLf & _
              "Caption = " & Label3D1.Caption & vbCrLf & _
              "Alignment = " & Label3D1.Alignment & vbCrLf & _
              "Effect = " & Label3D1.Effect)
    End Sub
    
End Class
