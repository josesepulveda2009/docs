Imports System.ComponentModel

Public Class Label3D
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        'Add any initialization after the InitializeComponent() call
        mCaption = "Label3D"
        mAlignment = Align.CenterMiddle
        mEffect = Effect3D.Raised
        setstyle(ControlStyles.ResizeRedraw, "True")
    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Label3D
        '
        Me.Font = New System.Drawing.Font("Comic Sans MS", 18!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Label3D"
        Me.Size = New System.Drawing.Size(174, 150)

    End Sub

#End Region

    Public Enum Align
        TopLeft
        TopMiddle
        TopRight
        CenterLeft
        CenterMiddle
        CenterRight
        BottomLeft
        BottomMiddle
        BottomRight
    End Enum

    Public Enum Effect3D
        None
        Raised
        RaisedHeavy
        Carved
        CarvedHeavy
    End Enum

    Private mAlignment As Align
    Private mEffect As Effect3D
    Private mCaption As String

    Private mOnAlignmentChanged As EventHandler
    Private mOnEffectChanged As EventHandler
    Private mOnCaptionChanged As EventHandler

    Property Caption() As String
        Get
            Caption = mCaption
        End Get
        Set(ByVal Value As String)
            mCaption = Value
            'Invalidate()
            OnCaptionChanged(EventArgs.Empty)
        End Set
    End Property

    Public Property Alignment() As Align
        Get
            Alignment = mAlignment
        End Get
        Set(ByVal Value As Align)
            mAlignment = Value
            'Invalidate()
            OnAlignmentChanged(EventArgs.Empty)
        End Set
    End Property

    <Category("Appearance")> Public Property Effect() As Effect3D
        Get
            Effect = mEffect
        End Get
        Set(ByVal Value As Effect3D)
            mEffect = Value
            'Invalidate()
            OnEffectChanged(EventArgs.Empty)
        End Set
    End Property

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim lblFont As Font = Me.Font
        Dim lblBrush As New SolidBrush(Color.Red)
        Dim X, Y As Integer
        Dim textSize As SizeF
        textSize = e.Graphics.MeasureString(mCaption, lblFont)
        Select Case Me.mAlignment
            Case Align.BottomLeft
                X = 2
                Y = Me.Height - textSize.Height
            Case Align.BottomMiddle
                X = CInt((Me.Width - textSize.Width) / 2)
                Y = Me.Height - textSize.Height
            Case Align.BottomRight
                X = Me.Width - textSize.Width - 2
                Y = Me.Height - textSize.Height
            Case Align.CenterLeft
                X = 2
                Y = (Me.Height - textSize.Height) / 2
            Case Align.CenterMiddle
                X = (Me.Width - textSize.Width) / 2
                Y = (Me.Height - textSize.Height) / 2
            Case Align.CenterRight
                X = Me.Width - textSize.Width - 2
                Y = (Me.Height - textSize.Height) / 2
            Case Align.TopLeft
                X = 2
                Y = 2
            Case Align.TopMiddle
                X = (Me.Width - textSize.Width) / 2
                Y = 2
            Case Align.TopRight
                X = Me.Width - textSize.Width - 2
                Y = 2
        End Select
        Dim dispX, dispY As Integer
        Select Case mEffect
            Case Effect3D.None : dispX = 0 : dispY = 0
            Case Effect3D.Raised : dispX = 1 : dispY = 1
            Case Effect3D.RaisedHeavy : dispX = 2 : dispY = 2
            Case Effect3D.Carved : dispX = -1 : dispY = -1
            Case Effect3D.CarvedHeavy : dispX = -2 : dispY = -2
        End Select
        e.Graphics.Clear(Me.BackColor)
        lblBrush.Color = Color.White
        e.Graphics.DrawString(mCaption, lblFont, lblBrush, X, Y)
        lblBrush.Color = Me.ForeColor
        If Me.DesignMode Then
            e.Graphics.DrawString("DesignTime", New Font("Verdana", 24, FontStyle.Bold), New SolidBrush(Color.FromArgb(200, 230, 200, 255)), 0, 0)
        Else
            e.Graphics.DrawString("RunTime", New Font("Verdana", 24, FontStyle.Bold), New SolidBrush(Color.FromArgb(200, 230, 200, 255)), 0, 0)
        End If
        e.Graphics.DrawString(mCaption, lblFont, lblBrush, X + dispX, Y + dispY)
    End Sub

    Public Event AlignmentChanged(ByVal sender As Object, ByVal ev As EventArgs)
    Public Event EffectChanged(ByVal sender As Object, ByVal ev As EventArgs)
    Public Event CaptionChanged(ByVal sender As Object, ByVal ev As EventArgs)

    Protected Overridable Sub OnAlignmentChanged(ByVal E As EventArgs)
        Invalidate()
        If Not (mOnAlignmentChanged Is Nothing) Then mOnAlignmentChanged.Invoke(Me, E)
    End Sub

    Protected Overridable Sub OnEffectChanged(ByVal E As EventArgs)
        Invalidate()
        If Not (mOnEffectChanged Is Nothing) Then mOnEffectChanged.Invoke(Me, E)
    End Sub

    Protected Overridable Sub OnCaptionChanged(ByVal E As EventArgs)
        Invalidate()
        If Not (mOnCaptionChanged Is Nothing) Then mOnCaptionChanged.Invoke(Me, E)
    End Sub

    Private Sub Label3D_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
