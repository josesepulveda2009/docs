Option Strict On
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents CtrlAlarm1 As Alarm.ctrlAlarm
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents CtrlAlarm2 As Alarm.ctrlAlarm
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.CtrlAlarm1 = New Alarm.ctrlAlarm()
        Me.CtrlAlarm2 = New Alarm.ctrlAlarm()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(6, 171)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(177, 43)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Start Timers"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(194, 12)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(304, 202)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.Text = ""
        '
        'CtrlAlarm1
        '
        Me.CtrlAlarm1.AlarmTime = New Date(CType(0, Long))
        Me.CtrlAlarm1.CountDown = False
        Me.CtrlAlarm1.Location = New System.Drawing.Point(6, 12)
        Me.CtrlAlarm1.Name = "CtrlAlarm1"
        Me.CtrlAlarm1.Size = New System.Drawing.Size(182, 64)
        Me.CtrlAlarm1.TabIndex = 3
        '
        'CtrlAlarm2
        '
        Me.CtrlAlarm2.AlarmTime = New Date(CType(0, Long))
        Me.CtrlAlarm2.CountDown = False
        Me.CtrlAlarm2.Location = New System.Drawing.Point(6, 80)
        Me.CtrlAlarm2.Name = "CtrlAlarm2"
        Me.CtrlAlarm2.Size = New System.Drawing.Size(182, 64)
        Me.CtrlAlarm2.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(9, 22)
        Me.ClientSize = New System.Drawing.Size(506, 223)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.CtrlAlarm2, Me.CtrlAlarm1, Me.TextBox1, Me.Button1})
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Alarm Control Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CtrlAlarm1.CountDown = True
        CtrlAlarm2.CountDown = False
        CtrlAlarm1.AlarmTime = Now.AddSeconds(10)
        CtrlAlarm2.AlarmTime = Now.AddSeconds(20)
        CtrlAlarm1.StartTimer()
        CtrlAlarm2.StartTimer()
        TextBox1.Text = "Current date and time: " & vbCrLf & Now & vbCrLf
        TextBox1.Text = TextBox1.Text + "Alarm1" & vbCrLf
        TextBox1.Text = TextBox1.Text & "    set for " & CtrlAlarm1.AlarmTime.ToShortDateString
        TextBox1.Text = TextBox1.Text & "   " & CtrlAlarm1.AlarmTime.ToLongTimeString & vbCrLf
        TextBox1.Text = TextBox1.Text & "    and counting down" & vbCrLf
        TextBox1.Text = TextBox1.Text & vbCrLf & "Alarm2" & vbCrLf
        TextBox1.Text = TextBox1.Text & "    set for " & CtrlAlarm2.AlarmTime.ToShortDateString
        TextBox1.Text = TextBox1.Text & "   " & CtrlAlarm2.AlarmTime.ToLongTimeString & vbCrLf
        TextBox1.Text = TextBox1.Text & "    and counting up" & vbCrLf
    End Sub

    Private Sub CtrlAlarm1_TimeOut() Handles CtrlAlarm1.TimeOut
        Beep()
        MsgBox("Alarm1 is off!")
    End Sub

    Private Sub CtrlAlarm2_TimeOut() Handles CtrlAlarm2.TimeOut
        Beep()
        MsgBox("Alarm2 is off!")
    End Sub

    Private Sub CtrlAlarm1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CtrlAlarm1.Load

    End Sub

    Private Sub CtrlAlarm1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles CtrlAlarm1.DoubleClick
        CtrlAlarm1.StopTimer()
    End Sub

    Private Sub CtrlAlarm2_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles CtrlAlarm2.DoubleClick
        CtrlAlarm2.StopTimer()
    End Sub
End Class
