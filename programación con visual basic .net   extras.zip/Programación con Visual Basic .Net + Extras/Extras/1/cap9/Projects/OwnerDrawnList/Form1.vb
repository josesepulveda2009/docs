Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(303, 225)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(114, 46)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Populate List"
        '
        'ListBox1
        '
        Me.ListBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable
        Me.ListBox1.Location = New System.Drawing.Point(6, 8)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(288, 263)
        Me.ListBox1.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Verdana", 12!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(303, 166)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 46)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Add New Item"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 275)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button2, Me.Button1, Me.ListBox1})
        Me.Name = "Form1"
        Me.Text = "OwnerDrawn ListBox Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim items As New ArrayList()
    Dim fnt As New Font("Verdana", 11, FontStyle.Regular)

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        items.Add("First Item")
        items.Add("Second Item")
        items.Add("This is a fairly lengthy item")
        items.Add("This item is just too long to be displayed on a single line")
        items.Add("and this is the last item")
        ListBox1.Items.Clear()
        Dim i As Integer
        For i = 0 To 4
            ListBox1.Items.Add(items(i).ToString)
        Next
    End Sub

    Private Sub ListBox1_MeasureItem(ByVal sender As Object, ByVal e As System.Windows.Forms.MeasureItemEventArgs) Handles ListBox1.MeasureItem
        Dim itmSize As SizeF
        Dim S As New SizeF(ListBox1.Width, 200)
        itmSize = e.Graphics.MeasureString(items(e.Index).ToString, fnt, S)
        e.ItemHeight = itmSize.Height
        e.ItemWidth = itmSize.Width
    End Sub

    Private Sub ListBox1_DrawItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles ListBox1.DrawItem
        If e.Index = -1 Then Exit Sub
        Dim txtBrush As SolidBrush
        Dim bgBrush As SolidBrush
        Dim txtfnt As Font
        If e.Index / 2 = CInt(e.Index / 2) Then
            txtBrush = New SolidBrush(Color.Blue)
            bgBrush = New SolidBrush(Color.LightYellow)
        Else
            txtBrush = New SolidBrush(Color.Blue)
            bgBrush = New SolidBrush(Color.Cyan)
        End If
        If e.State And DrawItemState.Selected Then
            txtBrush = New SolidBrush(Color.Red)
            txtfnt = New Font(fnt.Name, fnt.Size, FontStyle.Bold)
        Else
            txtfnt = fnt
        End If
        e.Graphics.FillRectangle(bgBrush, e.Bounds)
        e.Graphics.DrawRectangle(Pens.Black, e.Bounds)
        Dim R As New RectangleF(e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height)
        e.Graphics.DrawString(items(e.Index).ToString, txtfnt, txtBrush, R)
        e.DrawFocusRectangle()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim newItem As String
        newItem = InputBox("Enter item to add to the list")
        items.Add(newItem)
        ListBox1.Items.Add("")
    End Sub


    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        MsgBox("Item at location " & ListBox1.SelectedIndex & _
                " is " & vbCrLf & ListBox1.SelectedItem)
    End Sub
End Class
