Option Strict On
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(10, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(200, 32)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Multiply Matrices"
        '
        'Button2
        '
        Me.Button2.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.Button2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(260, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(200, 32)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "Add Matrices"
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.TextBox1.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(10, 66)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox1.Size = New System.Drawing.Size(450, 280)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = ""
        Me.TextBox1.WordWrap = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(468, 353)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1, Me.Button2, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Matrix Operations"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim a As Matrix = New Matrix(3, 4)
        Dim MTR As New Matrix()

        Dim i, j As Integer
        Dim rnd As System.Random = New System.Random()
        For i = 0 To a.Rows - 1
            For j = 0 To a.Cols - 1
                a.Cell(i, j) = rnd.Next(300)
            Next
        Next

        Dim b As Matrix = New Matrix(4, 3)
        For i = 0 To b.Rows - 1
            For j = 0 To b.Cols - 1
                b.Cell(i, j) = rnd.Next(300)
            Next
        Next
        Dim c As New Matrix()
        c = MTR.Multiply(a, b)
        ' TO TEST THE INSTANCE VERSION OF THE MULTIPLY METHOD
        ' CALL IT AS FOLLOWS:
        '   c = b.Multiply(a)
        If c.Rows = 0 Or c.Cols = 0 Then
            MsgBox("Invalid martices")
            Exit Sub
        End If
        TextBox1.Clear()
        For i = 0 To a.Rows - 1
            For j = 0 To a.Cols - 1
                TextBox1.AppendText(a.Cell(i, j) & vbTab)
            Next
            TextBox1.AppendText(vbCrLf)
        Next
        TextBox1.AppendText("******************************" & vbCrLf)
        For i = 0 To b.Rows - 1
            For j = 0 To b.Cols - 1
                TextBox1.AppendText(b.Cell(i, j) & vbTab)
            Next
            TextBox1.AppendText(vbCrLf)
        Next
        TextBox1.AppendText("******************************" & vbCrLf)
        For i = 0 To c.Rows - 1
            For j = 0 To c.Cols - 1
                TextBox1.AppendText(c.Cell(i, j) & vbTab)
            Next
            TextBox1.AppendText(vbCrLf)
        Next

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim a As Matrix = New Matrix(3, 4)
        Dim MTR As New Matrix()

        Dim i, j As Integer
        Dim rnd As System.Random = New System.Random()
        For i = 0 To a.Rows - 1
            For j = 0 To a.Cols - 1
                a.Cell(i, j) = rnd.Next(100)
            Next
        Next

        Dim b As Matrix = New Matrix(3, 4)
        For i = 0 To b.Rows - 1
            For j = 0 To b.Cols - 1
                b.Cell(i, j) = rnd.Next(100)
            Next
        Next
        Dim c As New Matrix()
        c = MTR.Add(a, b)
        TextBox1.Clear()
        For i = 0 To a.Rows - 1
            For j = 0 To a.Cols - 1
                TextBox1.AppendText(a.Cell(i, j) & vbTab)
            Next
            TextBox1.AppendText(vbCrLf)
        Next
        TextBox1.AppendText("******************************" & vbCrLf)
        For i = 0 To b.Rows - 1
            For j = 0 To b.Cols - 1
                TextBox1.AppendText(b.Cell(i, j) & vbTab)
            Next
            TextBox1.AppendText(vbCrLf)
        Next
        TextBox1.AppendText("******************************" & vbCrLf)
        For i = 0 To c.Rows - 1
            For j = 0 To c.Cols - 1
                TextBox1.AppendText(c.Cell(i, j) & vbTab)
            Next
            TextBox1.AppendText(vbCrLf)
        Next


    End Sub
End Class

Public Class Matrix
    Private _table(1, 1) As Double
    Private _rows, _cols As Integer
    ' Overloaded constructor (creates a new matrix)
    Sub New(ByVal R As Integer, ByVal C As Integer)
        MyBase.new()
        _rows = R
        _cols = C
        ReDim _table(_rows, _cols)
    End Sub

    ' overloaded constructor (creates a n instance of the class and an empty matrix)
    Sub New()
        MyBase.new()
        _rows = 0
        _cols = 0
        ReDim _table(_rows, _cols)
    End Sub

    ' set/read a cell value
    ' ADD CODE TO MAKE SURE THE SPECIFIED CELL INDICES ARE VALID
    ' IF NOT, THROW AN EXCEPTION (USE THE ARGUMENTOUTOFRANGEEXCEPTION CLASS)
    Public Property Cell(ByVal row As Integer, ByVal col As Integer) As Double
        Get
            Cell = _table(row, col)
        End Get
        Set(ByVal Value As Double)
            _table(row, col) = Value
        End Set
    End Property

    ' set/read the number of rows
    Public Property Rows() As Integer
        Get
            Rows = _rows
        End Get
        Set(ByVal Value As Integer)
            _rows = Value
        End Set
    End Property

    ' set/read the numberof columns
    Public Property Cols() As Integer
        Get
            Cols = _cols
        End Get
        Set(ByVal Value As Integer)
            _cols = Value
        End Set
    End Property

    ' Reference method to add two matrices
    ' Both matrices must have the same dimensions
    Public Overloads Function Add(ByVal A As Matrix, ByVal B As Matrix) As Matrix
        Dim Row, Col As Integer
        If Not (A.Rows = B.Rows And A.Cols = B.Cols) Then
            Add = New Matrix()
            Exit Function
        End If
        Dim newMatrix As New Matrix(A.Rows, A.Cols)
        For Row = 0 To A.Rows - 1
            For Col = 0 To A.Cols - 1
                newMatrix.Cell(Row, Col) = A.Cell(Row, Col) + B.Cell(Row, Col)
            Next
        Next
        Add = newMatrix
    End Function


    ' Instance method to add two matrices
    ' The specified matrix must have the same dimensions as current matrix
    Public Overloads Function Add(ByVal A As Matrix) As Matrix
        Dim Row, Col As Integer
        If Not (A.Rows = MyClass.Rows And A.Cols = MyClass.Cols) Then
            Add = New Matrix()

            Exit Function
        End If
        Dim newMatrix As New Matrix(MyClass.Rows, MyClass.Cols)
        For Row = 0 To MyClass.Rows - 1
            For Col = 0 To MyClass.Cols - 1
                newMatrix.Cell(Row, Col) = A.Cell(Row, Col) + MyClass.Cell(Row, Col)
            Next
        Next
        Add = newMatrix
    End Function

    ' Reference method to subtract two matrices
    ' Both matrices must have the same dimensions
    Public Function Subtract(ByVal A As Matrix, ByVal B As Matrix) As Matrix
        Dim Row, Col As Integer
        If Not (A.Rows = B.Rows And A.Cols = B.Cols) Then
            Subtract = New Matrix()
            Exit Function
        End If
        Dim newMatrix As Matrix = New Matrix(A.Rows, B.Cols)
        For Row = 0 To A.Rows - 1
            For Col = 0 To A.Cols - 1
                newMatrix.Cell(Row, Col) = A.Cell(Row, Col) - B.Cell(Row, Col)
            Next
        Next
        Subtract = newMatrix
    End Function

    ' Reference method to multiply two matrices
    ' The two matrices must have compatible dimensions (d1, d2) X (d2, d3)
    Public Function Multiply(ByVal A As Matrix, ByVal B As Matrix) As Matrix
        Dim Row, Col As Integer
        Dim i As Integer
        Console.WriteLine(A.Rows)
        Console.WriteLine(B.Cols)
        If Not (A.Cols = B.Rows) Then
            Multiply = New Matrix()
            Exit Function
        End If
        Dim newMatrix As Matrix = New Matrix(A.Rows, B.Cols)
        Dim pSum As Double
        For Row = 0 To A.Rows - 1
            For Col = 0 To B.Cols - 1
                pSum = 0
                For i = 0 To A.Cols - 1
                    pSum = pSum + A.Cell(Row, i) * B.Cell(i, Col)
                Next
                newMatrix.Cell(Row, Col) = pSum
            Next
        Next
        Multiply = newMatrix
    End Function

    ' Instance method to multiply two matrices
    ' The specified matrix must have compatible dimensions with the current instance (d1, d2) X (d2, d3)
    Public Function Multiply(ByVal A As Matrix) As Matrix
        Dim Row, Col As Integer
        Dim i As Integer
        Console.WriteLine(A.Rows)
        Console.WriteLine(MyClass.Cols)
        If Not (A.Cols = MyClass.Rows) Then
            Multiply = New Matrix()
            Exit Function
        End If
        Dim newMatrix As Matrix = New Matrix(A.Rows, MyClass.Cols)
        Dim pSum As Double
        For Row = 0 To A.Rows - 1
            For Col = 0 To MyClass.Cols - 1
                pSum = 0
                For i = 0 To A.Cols - 1
                    pSum = pSum + A.Cell(Row, i) * MyClass.Cell(i, Col)
                Next
                newMatrix.Cell(Row, Col) = pSum
            Next
        Next
        Multiply = newMatrix
    End Function

    Public Function IsEmpty() As Boolean
        If _rows = 0 Or _cols = 0 Then
            IsEmpty = True
        Else
            IsEmpty = False
        End If
    End Function

    Public Function TableToString() As String
        Dim Row, Col As Integer
        Dim msg As String
        Dim vbTab, vbNewLine As String
        vbTab = Microsoft.VisualBasic.ControlChars.Tab
        vbNewLine = Microsoft.VisualBasic.ControlChars.CrLf
        For Row = 0 To _rows - 1
            For Col = 0 To _cols - 1
                msg = msg & _table(Row, Col) & vbTab
            Next
            msg = msg & vbNewLine
        Next
        TableToString = msg
    End Function
End Class