Option Strict On
Public Class MDIForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Private WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private WithEvents MdiClient1 As System.Windows.Forms.MdiClient
    Private WithEvents WindowArrange As System.Windows.Forms.MenuItem
    Private WithEvents FileMenu As System.Windows.Forms.MenuItem
    Private WithEvents FileNew As System.Windows.Forms.MenuItem
    Private WithEvents FileExit As System.Windows.Forms.MenuItem
    Private WithEvents WindowMenu As System.Windows.Forms.MenuItem
    Private WithEvents WindowTileH As System.Windows.Forms.MenuItem
    Private WithEvents WindowTileV As System.Windows.Forms.MenuItem
    Private WithEvents WindowCascade As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.WindowMenu = New System.Windows.Forms.MenuItem()
        Me.WindowTileH = New System.Windows.Forms.MenuItem()
        Me.WindowTileV = New System.Windows.Forms.MenuItem()
        Me.WindowCascade = New System.Windows.Forms.MenuItem()
        Me.WindowArrange = New System.Windows.Forms.MenuItem()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.FileMenu = New System.Windows.Forms.MenuItem()
        Me.FileNew = New System.Windows.Forms.MenuItem()
        Me.FileExit = New System.Windows.Forms.MenuItem()
        Me.MdiClient1 = New System.Windows.Forms.MdiClient()
        Me.SuspendLayout()
        '
        'WindowMenu
        '
        Me.WindowMenu.Index = 1
        Me.WindowMenu.MdiList = True
        Me.WindowMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.WindowTileH, Me.WindowTileV, Me.WindowCascade, Me.WindowArrange})
        Me.WindowMenu.MergeOrder = 9
        Me.WindowMenu.Text = "Window"
        '
        'WindowTileH
        '
        Me.WindowTileH.Index = 0
        Me.WindowTileH.Text = "Tile Horizontally"
        '
        'WindowTileV
        '
        Me.WindowTileV.Index = 1
        Me.WindowTileV.Text = "Tile Vertically"
        '
        'WindowCascade
        '
        Me.WindowCascade.Index = 2
        Me.WindowCascade.Text = "Cascade"
        '
        'WindowArrange
        '
        Me.WindowArrange.Index = 3
        Me.WindowArrange.Text = "Arrange"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileMenu, Me.WindowMenu})
        '
        'FileMenu
        '
        Me.FileMenu.Index = 0
        Me.FileMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileNew, Me.FileExit})
        Me.FileMenu.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.FileMenu.Text = "File"
        '
        'FileNew
        '
        Me.FileNew.Index = 0
        Me.FileNew.Text = "New"
        '
        'FileExit
        '
        Me.FileExit.Index = 1
        Me.FileExit.MergeOrder = 99
        Me.FileExit.Text = "Exit"
        '
        'MdiClient1
        '
        Me.MdiClient1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MdiClient1.Name = "MdiClient1"
        Me.MdiClient1.TabIndex = 0
        '
        'MDIForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(648, 433)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.MdiClient1})
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "MDIForm"
        Me.Text = "MDIForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Shared activeChildForm As DocumentForm
    Private Sub FileNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileNew.Click
        Dim child1 As New DocumentForm()
        child1.MdiParent = Me
        child1.Show()
        child1.Text = "Untitled"
    End Sub

    Private Sub MDIForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        ' The following statements demonstrate how you can access all child forms
        ' of the MDI parent form and find out whether their text has been edited.
        ' Then, you can prompt the user to save each file.
        ' The sample code prints the names of the documents that have been edited
        ' on the Output window.
        ' The changedFiles Boolean variable is set to True event if one of the documents
        ' has been edited.
        ' The listChangedFiles is a string variable that contains the names of the documents
        ' that have been modified (and should be saved).
        '
        ' THE CODE SHOWN IN THE TEXT RESIDES IN THE CLOSING EVENT HANDLER OF THE
        ' CHILD FORMS AND PROMPTS THE USER FOR EACH EDITED DOCUMENT. THE TWO
        ' APPROACHES ARE EQUIVALENT. 
        '
        ' Dim changedFiles As Boolean = False
        ' Dim cfrm As DocumentForm
        ' Dim listChangedFiles As String
        ' For Each cfrm In Me.MdiChildren
        '     If cfrm.Editor.Modified Then
        '         changedFiles = True
        '         listChangedFiles = listChangedFiles & cfrm.Text & vbCrLf
        '     End If
        ' Next
        ' If listChangedFiles <> "" Then Console.WriteLine(listChangedFiles)
        '
        ' Since the program handles the closing of each document individually, 
        ' there's no need to program the MDI form's Closing event. The following event handler
        ' was included for demonstration purposes and you can safely remove this event handler.
        Dim reply As MsgBoxResult
        reply = MsgBox("Are you sure you want to terminate the application?", MsgBoxStyle.YesNo)
        If reply = MsgBoxResult.No Then
            e.Cancel = True
            Exit Sub
        Else
            End
        End If
    End Sub

    Private Sub MDIForm_MdiChildActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.MdiChildActivate
        If Me.ActiveMdiChild Is Nothing Then
            Me.Text = "MDIPad - no document"
        Else
            Me.Text = Me.ActiveMdiChild.Text
            ' IF OPTION STRICT = OFF THEN THE FOLLOWING STATEMENT CAN BE WRITTEN AS:
            ' activeChildForm = Me.ActiveMdiChild
            activeChildForm = CType(Me.ActiveMdiChild, DocumentForm)
        End If
    End Sub

    Private Sub FileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileExit.Click
        Me.Close()
    End Sub

    Private Sub WindowTileH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowTileH.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub WindowTileV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowTileV.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub WindowCascade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub WindowArrange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowArrange.Click
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub
End Class