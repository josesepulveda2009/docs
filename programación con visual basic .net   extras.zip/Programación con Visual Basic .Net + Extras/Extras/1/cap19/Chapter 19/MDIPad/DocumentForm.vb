Option Strict On
Public Class DocumentForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.

    Private WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Private WithEvents EditPaste As System.Windows.Forms.MenuItem
    Private WithEvents EditCut As System.Windows.Forms.MenuItem
    Private WithEvents EditMenu As System.Windows.Forms.MenuItem
    Private WithEvents EditCopy As System.Windows.Forms.MenuItem
    Private WithEvents FileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Private WithEvents FileOpen As System.Windows.Forms.MenuItem
    Private WithEvents FileSave As System.Windows.Forms.MenuItem
    Private WithEvents FileSaveAs As System.Windows.Forms.MenuItem
    Private WithEvents FilePrint As System.Windows.Forms.MenuItem
    Private WithEvents FileClose As System.Windows.Forms.MenuItem
    Public WithEvents Editor As System.Windows.Forms.TextBox
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents EditWrap As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents FormatFont As System.Windows.Forms.MenuItem
    Friend WithEvents FormatTextColor As System.Windows.Forms.MenuItem
    Friend WithEvents FormatPageColor As System.Windows.Forms.MenuItem
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents EditFind As System.Windows.Forms.MenuItem
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.FormatTextColor = New System.Windows.Forms.MenuItem()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.FileMenu = New System.Windows.Forms.MenuItem()
        Me.FileOpen = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.FileSave = New System.Windows.Forms.MenuItem()
        Me.FileSaveAs = New System.Windows.Forms.MenuItem()
        Me.MenuItem6 = New System.Windows.Forms.MenuItem()
        Me.FilePrint = New System.Windows.Forms.MenuItem()
        Me.MenuItem8 = New System.Windows.Forms.MenuItem()
        Me.FileClose = New System.Windows.Forms.MenuItem()
        Me.EditMenu = New System.Windows.Forms.MenuItem()
        Me.EditCopy = New System.Windows.Forms.MenuItem()
        Me.EditCut = New System.Windows.Forms.MenuItem()
        Me.EditPaste = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.EditFind = New System.Windows.Forms.MenuItem()
        Me.EditWrap = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.FormatFont = New System.Windows.Forms.MenuItem()
        Me.FormatPageColor = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Editor = New System.Windows.Forms.TextBox()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.SuspendLayout()
        '
        'FormatTextColor
        '
        Me.FormatTextColor.Index = 1
        Me.FormatTextColor.Text = "Text Color"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileMenu, Me.EditMenu, Me.MenuItem3})
        '
        'FileMenu
        '
        Me.FileMenu.Index = 0
        Me.FileMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileOpen, Me.MenuItem1, Me.FileSave, Me.FileSaveAs, Me.MenuItem6, Me.FilePrint, Me.MenuItem8, Me.FileClose})
        Me.FileMenu.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.FileMenu.Text = "File"
        '
        'FileOpen
        '
        Me.FileOpen.Index = 0
        Me.FileOpen.MergeOrder = 1
        Me.FileOpen.Text = "Open"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 1
        Me.MenuItem1.MergeOrder = 2
        Me.MenuItem1.Text = "-"
        '
        'FileSave
        '
        Me.FileSave.Index = 2
        Me.FileSave.MergeOrder = 3
        Me.FileSave.Text = "Save"
        '
        'FileSaveAs
        '
        Me.FileSaveAs.Index = 3
        Me.FileSaveAs.MergeOrder = 4
        Me.FileSaveAs.Text = "Save As"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 4
        Me.MenuItem6.MergeOrder = 5
        Me.MenuItem6.Text = "-"
        '
        'FilePrint
        '
        Me.FilePrint.Index = 5
        Me.FilePrint.MergeOrder = 6
        Me.FilePrint.Text = "Print"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 6
        Me.MenuItem8.MergeOrder = 7
        Me.MenuItem8.Text = "-"
        '
        'FileClose
        '
        Me.FileClose.Index = 7
        Me.FileClose.MergeOrder = 8
        Me.FileClose.MergeType = System.Windows.Forms.MenuMerge.Replace
        Me.FileClose.Text = "Close"
        '
        'EditMenu
        '
        Me.EditMenu.Index = 1
        Me.EditMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.EditCopy, Me.EditCut, Me.EditPaste, Me.MenuItem2, Me.EditFind, Me.EditWrap})
        Me.EditMenu.MergeOrder = 1
        Me.EditMenu.Text = "Edit"
        '
        'EditCopy
        '
        Me.EditCopy.Index = 0
        Me.EditCopy.Text = "Copy"
        '
        'EditCut
        '
        Me.EditCut.Index = 1
        Me.EditCut.Text = "Cut"
        '
        'EditPaste
        '
        Me.EditPaste.Index = 2
        Me.EditPaste.Text = "Paste"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 3
        Me.MenuItem2.Text = "-"
        '
        'EditFind
        '
        Me.EditFind.Index = 4
        Me.EditFind.Text = "Find"
        '
        'EditWrap
        '
        Me.EditWrap.Checked = True
        Me.EditWrap.Index = 5
        Me.EditWrap.Text = "Word Wrap"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FormatFont, Me.FormatTextColor, Me.FormatPageColor})
        Me.MenuItem3.MergeOrder = 2
        Me.MenuItem3.Text = "Format"
        '
        'FormatFont
        '
        Me.FormatFont.Index = 0
        Me.FormatFont.Text = "Font"
        '
        'FormatPageColor
        '
        Me.FormatPageColor.Index = 2
        Me.FormatPageColor.Text = "Page Color"
        '
        'ListBox1
        '
        Me.ListBox1.Items.AddRange(New Object() {""})
        Me.ListBox1.Location = New System.Drawing.Point(354, 42)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(120, 95)
        Me.ListBox1.TabIndex = 1
        Me.ListBox1.Visible = False
        '
        'Editor
        '
        Me.Editor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Editor.HideSelection = False
        Me.Editor.Multiline = True
        Me.Editor.Name = "Editor"
        Me.Editor.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.Editor.Size = New System.Drawing.Size(584, 329)
        Me.Editor.TabIndex = 0
        Me.Editor.Text = ""
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "doc1"
        '
        'DocumentForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(584, 329)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ListBox1, Me.Editor})
        Me.Menu = Me.MainMenu1
        Me.Name = "DocumentForm"
        Me.Text = "MDIPad"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim extForm As Form = New FindForm()

    Private Sub FileOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileOpen.Click
        OpenFileDialog1.DefaultExt = "*.txt"
        OpenFileDialog1.ShowDialog()
        If OpenFileDialog1.FileName <> "" Then
            Dim fname As String = OpenFileDialog1.FileName
            Me.Text = fname.Substring(fname.LastIndexOf("\") + 1)
            Dim StrReader As System.IO.StreamReader
            StrReader = New System.IO.StreamReader(fname)
            Editor.Text = StrReader.ReadToEnd
            Editor.SelectionStart = 0
            Editor.SelectionLength = 0
            ' Store the file's path and the date/time it was opened
            ' to the ListBox control
            ' You can store additional properties of the document
            ' to the same control (document's original size, and so on)
            ListBox1.Items.Add(fname)
            ListBox1.Items.Add(Now())
        End If
    End Sub

    Private Sub FileClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileClose.Click
        ' Close the current document
        ' The Close method will trigger the Form's Closing event,
        ' where we can determine whether the file was edited since it
        ' was read, or last saved
        Me.Close()
    End Sub

    Private Sub Form1_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        ' Prompt user before closing a document that has been edited
        ' since it was last saved.
        If Me.Editor.Modified Then
            Dim reply As MsgBoxResult
            reply = MsgBox("Document " & Me.Text & " was modified but not saved. " & _
            "Discard the edits?", MsgBoxStyle.YesNo)
            If reply = MsgBoxResult.No Then
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub EditCopy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditCopy.Click
        If Me.Editor.SelectedText = "" Then
            MsgBox("Please select some text to copy")
        Else
            ' The code in the book's first printing shows how to copy
            ' text to the Clipboard by copying the selected text onto
            ' the Clipboard with the following statement:
            '       Clipboard.SetDataObject(Me.Editor.SelectedText)
            ' The TextBox control provides the Copy method and you should prefer it
            Me.Editor.Copy()
        End If
    End Sub

    Private Sub EditCut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditCut.Click
        If Me.Editor.SelectedText = "" Then
            MsgBox("Please select some text to cut")
        Else
            ' The code in the book's first printing shows how to cut
            ' text by copying the selected text onto the Clipboard
            ' and then clear the selection with the following statements
            '       Clipboard.SetDataObject(Me.Editor.SelectedText)
            '       Me.Editor.SelectedText = ""
            ' This technique doesn't affect the TextBox control's Modified property,
            ' you should use the control's Cut method:
            Me.Editor.Cut()
        End If
    End Sub

    Private Sub EditPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditPaste.Click
        ' The code in the book's first printing shows how to paste
        ' text by repolacing the selected text with the Clipboard's contents:
        '          Me.Editor.SelectedText = Clipboard.GetDataObject.GetData(DataFormats.Text).ToString
        ' This technique doesn't affect the TextBox control's Modified property,
        ' you should use the control's Paste method:
        Me.Editor.Paste()
    End Sub

    Private Sub EditWrap_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditWrap.Click
        EditWrap.Checked = Not EditWrap.Checked
        Me.Editor.WordWrap = EditWrap.Checked
    End Sub

    Private Sub FormatFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FormatFont.Click
        FontDialog1.Font = Me.Editor.Font
        FontDialog1.ShowDialog()
        If Not FontDialog1.Font Is Nothing Then
            Me.Editor.Font = FontDialog1.Font
        End If

    End Sub

    Private Sub FormatTextColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FormatTextColor.Click
        ColorDialog1.Color = Me.Editor.ForeColor
        ColorDialog1.ShowDialog()
        Me.Editor.ForeColor = ColorDialog1.Color
    End Sub

    Private Sub FormatPageColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FormatPageColor.Click
        ColorDialog1.Color = Me.Editor.BackColor
        ColorDialog1.ShowDialog()
        Me.Editor.BackColor = ColorDialog1.Color
    End Sub

    Private Sub EditFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditFind.Click
        extForm.Show()
    End Sub

    Private Sub FileSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileSave.Click
        Dim saveFileName As String
        ' The File > Save command retrieves the text file's path
        ' from the ListBox control with the other properties of 
        ' the current document
        saveFileName = ListBox1.Items.Item(0).ToString
        If saveFileName = "" Then
            FileSaveAs_Click(sender, e)
        Else
            Dim StrWriter As System.IO.StreamWriter
            StrWriter = New System.IO.StreamWriter(saveFileName)
            StrWriter.Write(Editor.Text)
            Me.Editor.Modified = False
        End If
    End Sub

    Private Sub FileSaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileSaveAs.Click
        SaveFileDialog1.DefaultExt = "*.txt"
        Dim saveFileName As String
        ' The File > Save As command prompts for a file name
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim StrWriter As System.IO.StreamWriter
            StrWriter = New System.IO.StreamWriter(saveFileName)
            StrWriter.Write(Editor.Text)
            ListBox1.Items.Add(saveFileName)
            Me.Editor.Modified = False
        Else
            Exit Sub
        End If
    End Sub
End Class
