Option Strict On
Public Class FindForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents bttnFind As System.Windows.Forms.Button
    Friend WithEvents bttnFindNext As System.Windows.Forms.Button
    Friend WithEvents bttnReplace As System.Windows.Forms.Button
    Friend WithEvents bttnReplaceAll As System.Windows.Forms.Button
    Friend WithEvents srchWord As System.Windows.Forms.TextBox
    Friend WithEvents chkCase As System.Windows.Forms.CheckBox
    Friend WithEvents replaceWord As System.Windows.Forms.TextBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.replaceWord = New System.Windows.Forms.TextBox()
        Me.bttnReplace = New System.Windows.Forms.Button()
        Me.bttnFind = New System.Windows.Forms.Button()
        Me.bttnReplaceAll = New System.Windows.Forms.Button()
        Me.chkCase = New System.Windows.Forms.CheckBox()
        Me.srchWord = New System.Windows.Forms.TextBox()
        Me.bttnFindNext = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'replaceWord
        '
        Me.replaceWord.Location = New System.Drawing.Point(8, 40)
        Me.replaceWord.Name = "replaceWord"
        Me.replaceWord.Size = New System.Drawing.Size(280, 20)
        Me.replaceWord.TabIndex = 1
        Me.replaceWord.Text = ""
        '
        'bttnReplace
        '
        Me.bttnReplace.Enabled = False
        Me.bttnReplace.Location = New System.Drawing.Point(296, 40)
        Me.bttnReplace.Name = "bttnReplace"
        Me.bttnReplace.TabIndex = 3
        Me.bttnReplace.Text = "Replace"
        '
        'bttnFind
        '
        Me.bttnFind.Location = New System.Drawing.Point(296, 8)
        Me.bttnFind.Name = "bttnFind"
        Me.bttnFind.TabIndex = 2
        Me.bttnFind.Text = "Find"
        '
        'bttnReplaceAll
        '
        Me.bttnReplaceAll.Enabled = False
        Me.bttnReplaceAll.Location = New System.Drawing.Point(384, 40)
        Me.bttnReplaceAll.Name = "bttnReplaceAll"
        Me.bttnReplaceAll.TabIndex = 5
        Me.bttnReplaceAll.Text = "Replace All"
        '
        'chkCase
        '
        Me.chkCase.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCase.Location = New System.Drawing.Point(8, 72)
        Me.chkCase.Name = "chkCase"
        Me.chkCase.Size = New System.Drawing.Size(168, 16)
        Me.chkCase.TabIndex = 6
        Me.chkCase.Text = "Case-sensitive search"
        '
        'srchWord
        '
        Me.srchWord.Location = New System.Drawing.Point(8, 8)
        Me.srchWord.Name = "srchWord"
        Me.srchWord.Size = New System.Drawing.Size(280, 20)
        Me.srchWord.TabIndex = 0
        Me.srchWord.Text = ""
        '
        'bttnFindNext
        '
        Me.bttnFindNext.Enabled = False
        Me.bttnFindNext.Location = New System.Drawing.Point(384, 8)
        Me.bttnFindNext.Name = "bttnFindNext"
        Me.bttnFindNext.TabIndex = 4
        Me.bttnFindNext.Text = "Find Next"
        '
        'FindForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(464, 109)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.replaceWord, Me.chkCase, Me.bttnReplaceAll, Me.bttnReplace, Me.bttnFindNext, Me.bttnFind, Me.srchWord})
        Me.Name = "FindForm"
        Me.Text = "Find & Replace"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' The code uses the InStr() function instead of the IndexOf method of the 
    ' String class, because this method can perform case sensitive/insensitive searhces

    Private Sub bttnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnFind.Click
        Dim selStart As Integer
        Dim srchMode As CompareMethod

        ' The SetSearchMode() function sets the appropriate
        ' search mode depending on the user's selections on
        ' the FindForm form
        srchMode = SetSearchMode()
        selStart = InStr(MDIForm.activeChildForm.Editor.Text, srchWord.Text, srchMode)
        If selStart = 0 Then
            MsgBox("Can't find word")
            Exit Sub
        End If

        ' If the text was found:
        '    1. Select the located text 
        MDIForm.activeChildForm.Editor.Select(selStart - 1, srchWord.Text.Length)
        '    2. bring it into view
        MDIForm.activeChildForm.Editor.ScrollToCaret()
        '    3. and enable the other buttons on the form
        bttnFindNext.Enabled = True
        bttnReplace.Enabled = True
        bttnReplaceAll.Enabled = True
    End Sub

    Private Sub bttnFindNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnFindNext.Click
        ' The code of this event is nearly identical to the code 
        ' of the Find button's Click event handler 
        ' The only difference is that it starts searching 
        ' after the current location in the text
        Dim selStart As Integer
        Dim srchMode As CompareMethod
        Dim srchStart As Integer
        srchMode = SetSearchMode()

        srchStart = MDIForm.activeChildForm.Editor.SelectionStart + MDIForm.activeChildForm.Editor.SelectionLength
        selStart = InStr(srchStart + 1, MDIForm.activeChildForm.Editor.Text, srchWord.Text, srchMode)
        If selStart = 0 Then
            MsgBox("There are no more instances of the specified word")
            bttnFindNext.Enabled = False
            Exit Sub
        End If

        MDIForm.activeChildForm.Editor.Select(selStart - 1, srchWord.Text.Length)
        MDIForm.activeChildForm.Editor.ScrollToCaret()

        bttnFindNext.Enabled = True
        bttnReplace.Enabled = True
        bttnReplaceAll.Enabled = True
    End Sub

    Private Sub bttnReplace_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnReplace.Click
        ' This event handler replaces the current selection, even if the user has
        ' selected a segment of the text, other than the one located by the Find buttons
        MDIForm.activeChildForm.Editor.SelectedText = replaceWord.Text
        bttnFindNext_Click(sender, e)
    End Sub

    Private Sub bttnReplaceAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnReplaceAll.Click
        ' This event handler replaces all the instances of the specified
        ' string, but doesn't change the pointer's position
        Dim srchMode As CompareMethod
        Dim srchStart As Integer
        srchMode = SetSearchMode()
        Dim pointerLocation As Integer = MDIForm.activeChildForm.Editor.SelectionStart
        MDIForm.activeChildForm.Editor.Text = Replace(MDIForm.activeChildForm.Editor.Text, srchWord.Text, replaceWord.Text, , , srchMode)
        MDIForm.activeChildForm.Editor.SelectionStart = pointerLocation
    End Sub

    Function SetSearchMode() As CompareMethod
        ' Case-sensitive   = binary search mode
        ' Case-insensitive = text search mode
        If chkCase.Checked = True Then
            Return CompareMethod.Binary
        Else
            Return CompareMethod.Text
        End If
    End Function

    Private Sub FindForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        ' Do not close the Find form, just hide it, even if the user clicks the Close button
        e.Cancel = True
        Me.Hide()
    End Sub

    Private Sub FindForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        srchWord.Focus()
    End Sub
End Class