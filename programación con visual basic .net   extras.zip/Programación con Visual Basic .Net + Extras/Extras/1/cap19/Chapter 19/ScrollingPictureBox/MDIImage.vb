Public Class MDIImage
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub


    Private WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private WithEvents MdiClient1 As System.Windows.Forms.MdiClient
    Private WithEvents FileMenu As System.Windows.Forms.MenuItem
    Private WithEvents FileNew As System.Windows.Forms.MenuItem
    Private WithEvents FileExit As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents WindowTileV As System.Windows.Forms.MenuItem
    Friend WithEvents WindowTileH As System.Windows.Forms.MenuItem
    Friend WithEvents WindowCascade As System.Windows.Forms.MenuItem
    Friend WithEvents WindowArrange As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MdiClient1 = New System.Windows.Forms.MdiClient()
        Me.FileExit = New System.Windows.Forms.MenuItem()
        Me.FileNew = New System.Windows.Forms.MenuItem()
        Me.FileMenu = New System.Windows.Forms.MenuItem()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.WindowTileV = New System.Windows.Forms.MenuItem()
        Me.WindowTileH = New System.Windows.Forms.MenuItem()
        Me.WindowCascade = New System.Windows.Forms.MenuItem()
        Me.WindowArrange = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'MdiClient1
        '
        Me.MdiClient1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MdiClient1.Name = "MdiClient1"
        Me.MdiClient1.TabIndex = 0
        '
        'FileExit
        '
        Me.FileExit.Index = 1
        Me.FileExit.MergeOrder = 99
        Me.FileExit.Text = "Exit"
        '
        'FileNew
        '
        Me.FileNew.Index = 0
        Me.FileNew.Text = "New Image"
        '
        'FileMenu
        '
        Me.FileMenu.Index = 0
        Me.FileMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileNew, Me.FileExit})
        Me.FileMenu.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.FileMenu.Text = "File"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileMenu, Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 1
        Me.MenuItem1.MdiList = True
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.WindowTileV, Me.WindowTileH, Me.WindowCascade, Me.WindowArrange})
        Me.MenuItem1.MergeOrder = 9
        Me.MenuItem1.Text = "Window"
        '
        'WindowTileV
        '
        Me.WindowTileV.Index = 0
        Me.WindowTileV.Text = "Tile Vertical"
        '
        'WindowTileH
        '
        Me.WindowTileH.Index = 1
        Me.WindowTileH.Text = "Tile Horizontal"
        '
        'WindowCascade
        '
        Me.WindowCascade.Index = 2
        Me.WindowCascade.Text = "Cascade"
        '
        'WindowArrange
        '
        Me.WindowArrange.Index = 3
        Me.WindowArrange.Text = "Arrange Icons"
        '
        'MDIImage
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(680, 393)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.MdiClient1})
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "MDIImage"
        Me.Text = "Scrolling PictureBox Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' The MDI parent form contains trivial commands for creating a new child form 
    ' and for rearranging the child windows on the parent form.
    Private Sub FileNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileNew.Click
        Dim child1 As New ImageForm()
        child1.MdiParent = Me
        child1.Show()
    End Sub

    Private Sub FileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileExit.Click
        End
    End Sub

    Private Sub ParentForm_MdiChildActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.MdiChildActivate
        If Not Me.ActiveMdiChild Is Nothing Then Me.Text = "Scrolling PictureBox - " & Me.ActiveMdiChild.Text
    End Sub

    Private Sub WindowTileV_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowTileV.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub WindowTileH_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowTileH.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub WindowCascade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub WindowArrange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowArrange.Click
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub
End Class
