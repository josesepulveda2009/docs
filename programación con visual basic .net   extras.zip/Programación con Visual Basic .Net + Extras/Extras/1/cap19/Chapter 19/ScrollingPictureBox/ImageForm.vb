Option Explicit On 
Public Class ImageForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Private WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Private WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Private WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Private WithEvents FlipHorizontal As System.Windows.Forms.MenuItem
    Private WithEvents ProcessMenu As System.Windows.Forms.MenuItem
    Private WithEvents RotateLeft As System.Windows.Forms.MenuItem
    Private WithEvents RotateRight As System.Windows.Forms.MenuItem
    Private WithEvents FlipVertical As System.Windows.Forms.MenuItem
    Private WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Private WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Private WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Private WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Private WithEvents ZoomMenu As System.Windows.Forms.MenuItem
    Private WithEvents PrintMenu As System.Windows.Forms.MenuItem
    Private WithEvents FileLoad As System.Windows.Forms.MenuItem
    Private WithEvents FileClose As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents ImageProps As System.Windows.Forms.MenuItem
    Private WithEvents Zoom25 As System.Windows.Forms.MenuItem
    Private WithEvents Zoom50 As System.Windows.Forms.MenuItem
    Private WithEvents Zoom200 As System.Windows.Forms.MenuItem
    Private WithEvents ZoomAuto As System.Windows.Forms.MenuItem
    Private WithEvents Zoom75 As System.Windows.Forms.MenuItem
    Private WithEvents Zoom100 As System.Windows.Forms.MenuItem
    Friend WithEvents ImageInfo As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.FlipHorizontal = New System.Windows.Forms.MenuItem()
        Me.RotateLeft = New System.Windows.Forms.MenuItem()
        Me.FileLoad = New System.Windows.Forms.MenuItem()
        Me.Zoom200 = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ZoomMenu = New System.Windows.Forms.MenuItem()
        Me.ZoomAuto = New System.Windows.Forms.MenuItem()
        Me.Zoom100 = New System.Windows.Forms.MenuItem()
        Me.Zoom75 = New System.Windows.Forms.MenuItem()
        Me.Zoom50 = New System.Windows.Forms.MenuItem()
        Me.Zoom25 = New System.Windows.Forms.MenuItem()
        Me.MenuItem4 = New System.Windows.Forms.MenuItem()
        Me.RotateRight = New System.Windows.Forms.MenuItem()
        Me.FlipVertical = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.FileClose = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.ProcessMenu = New System.Windows.Forms.MenuItem()
        Me.ImageProps = New System.Windows.Forms.MenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.ImageInfo = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'FlipHorizontal
        '
        Me.FlipHorizontal.Index = 3
        Me.FlipHorizontal.Text = "Flip Horizontal"
        '
        'RotateLeft
        '
        Me.RotateLeft.Index = 0
        Me.RotateLeft.Text = "Rotate Left"
        '
        'FileLoad
        '
        Me.FileLoad.Index = 0
        Me.FileLoad.Text = "Load"
        '
        'Zoom200
        '
        Me.Zoom200.Index = 1
        Me.Zoom200.Text = "200%"
        '
        'ZoomMenu
        '
        Me.ZoomMenu.Enabled = False
        Me.ZoomMenu.Index = 1
        Me.ZoomMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ZoomAuto, Me.Zoom200, Me.Zoom100, Me.Zoom75, Me.Zoom50, Me.Zoom25})
        Me.ZoomMenu.Text = "Zoom"
        '
        'ZoomAuto
        '
        Me.ZoomAuto.Index = 0
        Me.ZoomAuto.Text = "Auto"
        '
        'Zoom100
        '
        Me.Zoom100.Checked = True
        Me.Zoom100.Index = 2
        Me.Zoom100.Text = "100%"
        '
        'Zoom75
        '
        Me.Zoom75.Index = 3
        Me.Zoom75.Text = "75%"
        '
        'Zoom50
        '
        Me.Zoom50.Index = 4
        Me.Zoom50.Text = "50%"
        '
        'Zoom25
        '
        Me.Zoom25.Index = 5
        Me.Zoom25.Text = "25%"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "-"
        '
        'RotateRight
        '
        Me.RotateRight.Index = 1
        Me.RotateRight.Text = "Rotate Right"
        '
        'FlipVertical
        '
        Me.FlipVertical.Index = 2
        Me.FlipVertical.Text = "Flip Vertical"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileLoad, Me.FileClose, Me.MenuItem4})
        Me.MenuItem1.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.MenuItem1.Text = "File"
        '
        'FileClose
        '
        Me.FileClose.Index = 1
        Me.FileClose.Text = "Close"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 4
        Me.MenuItem2.Text = "-"
        '
        'ProcessMenu
        '
        Me.ProcessMenu.Enabled = False
        Me.ProcessMenu.Index = 2
        Me.ProcessMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.RotateLeft, Me.RotateRight, Me.FlipVertical, Me.FlipHorizontal, Me.MenuItem2, Me.ImageProps})
        Me.ProcessMenu.Text = "Image"
        '
        'ImageProps
        '
        Me.ImageProps.Index = 5
        Me.ImageProps.Text = "Image Properties"
        '
        'PictureBox1
        '
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.ZoomMenu, Me.ProcessMenu})
        '
        'ImageInfo
        '
        Me.ImageInfo.Location = New System.Drawing.Point(224, 8)
        Me.ImageInfo.Name = "ImageInfo"
        Me.ImageInfo.Size = New System.Drawing.Size(120, 17)
        Me.ImageInfo.TabIndex = 1
        Me.ImageInfo.Visible = False
        '
        'ImageForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(514, 306)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ImageInfo, Me.PictureBox1})
        Me.Menu = Me.MainMenu1
        Me.Name = "ImageForm"
        Me.Text = "New Image"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FileLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileLoad.Click
        Dim imgFile As String
        OpenFileDialog1.Filter = "Images|*.jpg;*.tif"
        OpenFileDialog1.ShowDialog()
        imgFile = OpenFileDialog1.FileName
        ' The FileInfo object is used to extract the name of the file selected by the user
        Dim FI As System.IO.FileInfo
        FI = New System.IO.FileInfo(imgFile)
        Me.Text = FI.Name

        PictureBox1.Image = Image.FromFile(imgFile)
        PictureBox1.Width = PictureBox1.Image.Width
        PictureBox1.Height = PictureBox1.Image.Height
        Me.ZoomMenu.Enabled = True
        Me.ProcessMenu.Enabled = True
        ' The following statements add information about the image
        ' to the ImageInfo ListBox control. 
        ' 1st item: the file's name
        ' 2nd item: the image's width
        ' 3rd item: the image's height
        ' 4th item: the current magnification of the image 
        ImageInfo.Items.Add(imgFile)                    ' FILE NAME
        ImageInfo.Items.Add(PictureBox1.Image.Width)    ' IMAGE'S WIDTH
        ImageInfo.Items.Add(PictureBox1.Image.Height)   ' IMAGE'S HEIGHT
        ImageInfo.Items.Add("Normal")
        Zoom100.Checked = True
    End Sub

    Private Sub RotateLeft_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotateLeft.Click
        PictureBox1.Image.RotateFlip(RotateFlipType.Rotate270FlipNone)
        PictureBox1.Invalidate()
        ' once the image is rotated, we must also swap the dimensions of its container
        Dim tmp As Integer
        tmp = PictureBox1.Width
        PictureBox1.Width = PictureBox1.Height
        PictureBox1.Height = tmp
    End Sub

    Private Sub RotateRight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotateRight.Click
        PictureBox1.Image.RotateFlip(RotateFlipType.Rotate90FlipNone)
        PictureBox1.Invalidate()
        ' once the image is rotated, we must also swap the dimensions of its container
        Dim tmp As Integer
        tmp = PictureBox1.Width
        PictureBox1.Width = PictureBox1.Height
        PictureBox1.Height = tmp
    End Sub

    Private Sub FlipVertical_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FlipVertical.Click
        PictureBox1.Image.RotateFlip(RotateFlipType.Rotate180FlipX)
        PictureBox1.Invalidate()
    End Sub

    Private Sub FlipHorizontal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FlipHorizontal.Click
        PictureBox1.Image.RotateFlip(RotateFlipType.Rotate180FlipY)
        PictureBox1.Invalidate()
    End Sub

    Private Sub FileClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileClose.Click
        Me.Close()
    End Sub

    ' The code for the Zoom > Auto command is different in this project
    ' than the listing in the book's first printing.
    ' It takes into consideration the dimensions of the PictureBox, as well
    ' as the dimensions of the borders and the menu bar
    ' The problem with an image displayed in Auto mode is how to resize it
    ' when the child form is resized. the aspect ratios of the child form and
    ' the image are widely different, the image will almost fit in the child form.
    '
    Private Sub ZoomAuto_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomAuto.Click
        'If PictureBox1.Image.Width < PictureBox1.Image.Height Then
        If PictureBox1.Image.Width < PictureBox1.Image.Height Then
            ' the height of the PictureBox control is made equal to the height
            ' of the MDI child form that hosts the control, minus the borders and the caption
            PictureBox1.Height = Me.Height - (4 * SystemInformation.Border3DSize.Height + SystemInformation.CaptionHeight + 1)
            PictureBox1.Width = PictureBox1.Height * (PictureBox1.Image.Width / PictureBox1.Image.Height)
        Else
            PictureBox1.Width = Me.Width - 4 * SystemInformation.Border3DSize.Width - 1
            PictureBox1.Height = PictureBox1.Width * (PictureBox1.Image.Height / PictureBox1.Image.Width)
        End If
        UncheckZoomMenu()
        ZoomAuto.Checked = True
    End Sub

    Sub ZoomImage(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom100.Click, Zoom200.Click, Zoom75.Click, Zoom50.Click, Zoom25.Click
        UncheckZoomMenu()
        Me.PictureBox1.Width = PictureBox1.Image.Width * Val(CType(sender, MenuItem).Text) / 100
        Me.PictureBox1.Height = PictureBox1.Image.Height * Val(CType(sender, MenuItem).Text) / 100
        ImageInfo.Items.Item(3) = Val(sender.text) / 100
        CType(sender, MenuItem).Checked = True
    End Sub

    Sub UncheckZoomMenu()
        Me.ZoomAuto.Checked = False
        Me.Zoom200.Checked = False
        Me.Zoom100.Checked = False
        Me.Zoom75.Checked = False
        Me.Zoom50.Checked = False
        Me.Zoom25.Checked = False
    End Sub

    Private Sub ImageProps_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImageProps.Click
        Dim msg As String
        msg = "Image File " & ImageInfo.Items(0) & vbCrLf
        msg = msg & "Width " & ImageInfo.Items(1) & vbCrLf
        msg = msg & "Height " & ImageInfo.Items(2) & vbCrLf
        MsgBox(msg)
    End Sub

    Private Sub ImageForm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        If ZoomAuto.Checked = True Then
            ZoomAuto_Click(sender, e)
        End If
    End Sub
End Class
