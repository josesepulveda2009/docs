Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Private WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Private WithEvents MdiClient1 As System.Windows.Forms.MdiClient
    Private WithEvents FileMenu As System.Windows.Forms.MenuItem
    Private WithEvents FileNew As System.Windows.Forms.MenuItem
    Private WithEvents FileExit As System.Windows.Forms.MenuItem
    Private WithEvents WindowTileH As System.Windows.Forms.MenuItem
    Private WithEvents WindowTileV As System.Windows.Forms.MenuItem
    Private WithEvents WindowCascade As System.Windows.Forms.MenuItem
    Private WithEvents WindowArrange As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.FileMenu = New System.Windows.Forms.MenuItem()
        Me.FileNew = New System.Windows.Forms.MenuItem()
        Me.FileExit = New System.Windows.Forms.MenuItem()
        Me.MenuItem4 = New System.Windows.Forms.MenuItem()
        Me.WindowTileH = New System.Windows.Forms.MenuItem()
        Me.WindowTileV = New System.Windows.Forms.MenuItem()
        Me.WindowCascade = New System.Windows.Forms.MenuItem()
        Me.WindowArrange = New System.Windows.Forms.MenuItem()
        Me.MdiClient1 = New System.Windows.Forms.MdiClient()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileMenu, Me.MenuItem4})
        '
        'FileMenu
        '
        Me.FileMenu.Index = 0
        Me.FileMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileNew, Me.FileExit})
        Me.FileMenu.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.FileMenu.Text = "File"
        '
        'FileNew
        '
        Me.FileNew.Index = 0
        Me.FileNew.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.FileNew.Text = "New"
        '
        'FileExit
        '
        Me.FileExit.Index = 1
        Me.FileExit.MergeOrder = 9
        Me.FileExit.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.FileExit.Text = "Exit"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 1
        Me.MenuItem4.MdiList = True
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.WindowTileH, Me.WindowTileV, Me.WindowCascade, Me.WindowArrange})
        Me.MenuItem4.MergeOrder = 99
        Me.MenuItem4.Text = " Window"
        '
        'WindowTileH
        '
        Me.WindowTileH.Index = 0
        Me.WindowTileH.Text = "Tile Horizontally"
        '
        'WindowTileV
        '
        Me.WindowTileV.Index = 1
        Me.WindowTileV.Text = "Tile Vertically"
        '
        'WindowCascade
        '
        Me.WindowCascade.Index = 2
        Me.WindowCascade.Text = "Cascade"
        '
        'WindowArrange
        '
        Me.WindowArrange.Index = 3
        Me.WindowArrange.Text = "Arrange"
        '
        'MdiClient1
        '
        Me.MdiClient1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MdiClient1.Name = "MdiClient1"
        Me.MdiClient1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(680, 433)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.MdiClient1})
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "MDIForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileNew.Click
        Static i As Integer
        Dim child As New ChildForm()
        child.MdiParent = Me
        child.Text = "Child window # " & i.ToString
        child.Show()
        i = i + 1
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowTileH.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowTileV.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub MenuItem7_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowCascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WindowArrange.Click
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub Form1_MdiChildActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.MdiChildActivate
        Me.Text = "MDIPad - " & Me.ActiveMdiChild.Text
    End Sub

    Private Sub Form1_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Dim frm As Form
        For Each frm In Me.MdiChildren
            MsgBox(frm.Text)
        Next
    End Sub
End Class
