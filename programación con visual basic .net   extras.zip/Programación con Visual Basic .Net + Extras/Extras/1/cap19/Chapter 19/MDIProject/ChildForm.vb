Public Class ChildForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Private WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Private WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Private WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Private WithEvents MenuFile As System.Windows.Forms.MenuItem
    Private WithEvents FileOpen As System.Windows.Forms.MenuItem
    Private WithEvents FileSave As System.Windows.Forms.MenuItem
    Private WithEvents FileSaveAs As System.Windows.Forms.MenuItem
    Private WithEvents FileClose As System.Windows.Forms.MenuItem
    Private WithEvents FilePageSetup As System.Windows.Forms.MenuItem
    Private WithEvents FilePrint As System.Windows.Forms.MenuItem
    Private WithEvents EditMenu As System.Windows.Forms.MenuItem
    Private WithEvents EditCopy As System.Windows.Forms.MenuItem
    Private WithEvents EditCut As System.Windows.Forms.MenuItem
    Private WithEvents EditPaste As System.Windows.Forms.MenuItem
    Private WithEvents Editor As System.Windows.Forms.TextBox
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents EditWordWrap As System.Windows.Forms.MenuItem
    Friend WithEvents TextFont As System.Windows.Forms.MenuItem
    Friend WithEvents CustomizeMenu As System.Windows.Forms.MenuItem
    Friend WithEvents TextColor As System.Windows.Forms.MenuItem
    Friend WithEvents PageColor As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.EditWordWrap = New System.Windows.Forms.MenuItem()
        Me.EditCut = New System.Windows.Forms.MenuItem()
        Me.MenuItem11 = New System.Windows.Forms.MenuItem()
        Me.FilePageSetup = New System.Windows.Forms.MenuItem()
        Me.Editor = New System.Windows.Forms.TextBox()
        Me.MenuFile = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.FileOpen = New System.Windows.Forms.MenuItem()
        Me.FileSave = New System.Windows.Forms.MenuItem()
        Me.FileSaveAs = New System.Windows.Forms.MenuItem()
        Me.FileClose = New System.Windows.Forms.MenuItem()
        Me.MenuItem8 = New System.Windows.Forms.MenuItem()
        Me.FilePrint = New System.Windows.Forms.MenuItem()
        Me.TextFont = New System.Windows.Forms.MenuItem()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.EditMenu = New System.Windows.Forms.MenuItem()
        Me.EditCopy = New System.Windows.Forms.MenuItem()
        Me.EditPaste = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.CustomizeMenu = New System.Windows.Forms.MenuItem()
        Me.TextColor = New System.Windows.Forms.MenuItem()
        Me.PageColor = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'EditWordWrap
        '
        Me.EditWordWrap.Checked = True
        Me.EditWordWrap.Index = 4
        Me.EditWordWrap.Text = "Wrap Words"
        '
        'EditCut
        '
        Me.EditCut.Index = 1
        Me.EditCut.Text = "Cut"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 8
        Me.MenuItem11.Text = "-"
        '
        'FilePageSetup
        '
        Me.FilePageSetup.Index = 6
        Me.FilePageSetup.Text = "Page Setup"
        '
        'Editor
        '
        Me.Editor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Editor.Multiline = True
        Me.Editor.Name = "Editor"
        Me.Editor.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.Editor.Size = New System.Drawing.Size(592, 337)
        Me.Editor.TabIndex = 0
        Me.Editor.Text = ""
        '
        'MenuFile
        '
        Me.MenuFile.Index = 0
        Me.MenuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem3, Me.FileOpen, Me.FileSave, Me.FileSaveAs, Me.FileClose, Me.MenuItem8, Me.FilePageSetup, Me.FilePrint, Me.MenuItem11})
        Me.MenuFile.MergeType = System.Windows.Forms.MenuMerge.MergeItems
        Me.MenuFile.Text = "File"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 0
        Me.MenuItem3.Text = "-"
        '
        'FileOpen
        '
        Me.FileOpen.Index = 1
        Me.FileOpen.Text = "Open"
        '
        'FileSave
        '
        Me.FileSave.Index = 2
        Me.FileSave.Text = "Save"
        '
        'FileSaveAs
        '
        Me.FileSaveAs.Index = 3
        Me.FileSaveAs.Text = "Save As"
        '
        'FileClose
        '
        Me.FileClose.Index = 4
        Me.FileClose.Text = "Close"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 5
        Me.MenuItem8.Text = "-"
        '
        'FilePrint
        '
        Me.FilePrint.Index = 7
        Me.FilePrint.Text = "Print"
        '
        'TextFont
        '
        Me.TextFont.Index = 0
        Me.TextFont.Text = "Font"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuFile, Me.EditMenu, Me.CustomizeMenu})
        '
        'EditMenu
        '
        Me.EditMenu.Index = 1
        Me.EditMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.EditCopy, Me.EditCut, Me.EditPaste, Me.MenuItem1, Me.EditWordWrap})
        Me.EditMenu.Text = "Edit"
        '
        'EditCopy
        '
        Me.EditCopy.Index = 0
        Me.EditCopy.Text = "Copy"
        '
        'EditPaste
        '
        Me.EditPaste.Index = 2
        Me.EditPaste.Text = "Paste"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 3
        Me.MenuItem1.Text = "-"
        '
        'CustomizeMenu
        '
        Me.CustomizeMenu.Index = 2
        Me.CustomizeMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.TextFont, Me.TextColor, Me.PageColor})
        Me.CustomizeMenu.Text = "Customize"
        '
        'TextColor
        '
        Me.TextColor.Index = 1
        Me.TextColor.Text = "Text Color"
        '
        'PageColor
        '
        Me.PageColor.Index = 2
        Me.PageColor.Text = "Page Color"
        '
        'ChildForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(592, 337)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Editor})
        Me.Menu = Me.MainMenu1
        Me.Name = "ChildForm"
        Me.Text = "ChildForm"
        Me.ResumeLayout(False)

    End Sub

#End Region



End Class
