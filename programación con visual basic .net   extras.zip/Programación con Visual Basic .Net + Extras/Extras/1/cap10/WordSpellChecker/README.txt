April 1, 2002
REVISED WORDSPELLCHECKER PROJECT TO FIX A BUG
WITH THE CLOSE & QUIT METHODS

The original application (as discussed in the book),
calls the Document.Close method to close an open document
and the Application.Quit method to terminate Word. However,
you can't call these methods directly - if you do, an exception
will be raised, because these two method names are not 
unique in their namespace.

To close a document, convert the Document object
that represents an open document to the Word._Document
type and then call the Close method:
 
CType(thisDoc, Word._Document).Close(Word.WdSaveOptions.wdDoNotSaveChanges)

To close Word, convert the Word.Application object
that represents the running application to the 
Word._Application type and then call its Quit method:

CType(WordApp, Word._Application).Quit(Word.WdSaveOptions.wdDoNotSaveChanges)

The argument passed to both method indicates that Word
shouldn't prompt the user to saving the changes. You
can also call these methods passing False as argument.

The changes affect the statements that close an open document
and terminate the Word application. It's critical that you close
any documents you no longer need and shut down the running instance
of Word. If not, you'll get an exception when you attempt to open the
same document again.
