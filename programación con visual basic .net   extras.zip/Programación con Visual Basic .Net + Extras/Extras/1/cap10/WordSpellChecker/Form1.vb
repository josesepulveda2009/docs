Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub


    Private WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Button2 As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(408, 240)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(192, 32)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "SpellCheck Document"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(8, 8)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(594, 224)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = ""
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.ItemHeight = 14
        Me.ListBox1.Location = New System.Drawing.Point(8, 240)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(184, 172)
        Me.ListBox1.TabIndex = 4
        '
        'ListBox2
        '
        Me.ListBox2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox2.ItemHeight = 14
        Me.ListBox2.Location = New System.Drawing.Point(200, 240)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(200, 172)
        Me.ListBox2.TabIndex = 4
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(408, 380)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(192, 32)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Replace Word"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(604, 417)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button2, Me.ListBox2, Me.ListBox1, Me.TextBox1, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "WordSpellChecker"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim WordApp As New Word.Application()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim DRange As Word.Range
        Me.Text = "starting word ..."
        WordApp.Documents.Add()
        Me.Text = "checking words..."
        DRange = WordApp.ActiveDocument.Range
        DRange.InsertAfter(TextBox1.Text)
        Dim SpellCollection As Word.ProofreadingErrors
        SpellCollection = DRange.SpellingErrors
        If SpellCollection.Count > 0 Then
            ListBox1.Items.Clear()
            ListBox2.Items.Clear()
            Dim iword As Integer
            Dim newWord As String
            For iword = 1 To SpellCollection.Count
                newWord = SpellCollection.Item(iword).Text
                If ListBox1.FindStringExact(newWord) < 0 Then
                    ListBox1.Items.Add(newWord)
                End If
            Next
        End If
        Me.Text = "Word spelling Demo"
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim CorrectionsCollection As Word.SpellingSuggestions
        CorrectionsCollection = _
                 WordApp.GetSpellingSuggestions(ListBox1.Text)
        ListBox2.Items.Clear()
        If CorrectionsCollection.Count > 0 Then
            Dim iWord As Integer
            For iWord = 1 To CorrectionsCollection.Count
                ListBox2.Items.Add(CorrectionsCollection.Item(iWord).Name)
            Next
        Else
            ListBox2.Items.Add("No suggestions!")
        End If
    End Sub

    Private Sub Form1_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        CType(WordApp, Word._Application).Quit(False)
        WordApp = Nothing
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If ListBox1.SelectedIndex >= 0 And ListBox2.SelectedIndex >= 0 Then
            TextBox1.Text = Replace(TextBox1.Text, ListBox1.SelectedItem, ListBox2.SelectedItem)
            ListBox1.Items.Remove(ListBox1.SelectedIndex)
            ListBox2.Items.Clear()
        End If
    End Sub

End Class
