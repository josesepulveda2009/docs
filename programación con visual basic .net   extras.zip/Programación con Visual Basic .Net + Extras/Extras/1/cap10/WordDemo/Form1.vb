Option Strict Off
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(64, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(168, 32)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "TypeText"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "doc1"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(64, 72)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(168, 32)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "InsertAfter"
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(64, 112)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(168, 32)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Edit Document"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 181)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button3, Me.Button2, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Word Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim WordApp As New Word.Application()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim doc As New Word.Document()
        doc = WordApp.Documents.Add()
        Dim str As String
        str = "Text Formatting:"
        With WordApp.Selection
            .Font.Size = WordApp.Selection.Font.Size + 2
            .Font.Bold = True
            .TypeText(str)
            .Font.Size = WordApp.Selection.Font.Size - 2
            .Font.Bold = False
            .TypeParagraph()
            .Font.Color = Word.WdColor.wdColorDarkRed
            .Font.Italic = False
            .TypeText("This sentence will appear in red. ")

            .TypeParagraph()
            .Font.Color = Word.WdColor.wdColorBlack
            .Font.Italic = True
            .Font.Size = WordApp.Selection.Font.Size + 2
            .TypeText("Text color was reset to black, " & _
                    "but the font size was increased by two points")
        End With
        Dim fName As String
        SaveFileDialog1.Filter = "Documents|*.doc"
        SaveFileDialog1.ShowDialog()
        fName = SaveFileDialog1.FileName
        If fName <> "" Then
            Try
                doc.SaveAs(fName)
            Catch exc As Exception
                MsgBox("Failed to save document" & _
                        vbCrLf & exc.Message)
            End Try
        End If
        MsgBox("The document contains " & doc.Paragraphs.Count & " paragraphs " & vbCrLf & _
                doc.Words.Count & " words and " & doc.Characters.Count & " words")
        CType(doc, Word._Document).Close(Word.WdSaveOptions.wdDoNotSaveChanges)
    End Sub

    Private Sub Form1_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        CType(WordApp, Word._Application).Quit(Word.WdSaveOptions.wdDoNotSaveChanges)
        WordApp = Nothing
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim doc As New Word.Document()
        doc = WordApp.Documents.Add()
        With doc.Range
            .InsertAfter("A New Architecture " & _
                    "for Building Distributed Applications")
            .InsertParagraphAfter()
            .InsertAfter("ADO.NET is the latest data access " & _
                    "technology from Microsoft, geared towards " & _
                    "distributed applications. Unlike its predecessor, " & _
                    "ADO.NET uses disconnected recordsets.")
            .InsertParagraphAfter()
            .InsertAfter("The disconnected recordsets are called " & _
                    "DataSets and they may contain multiple tables. " & _
                    "If the tables are related, the DataSet knows " & _
                    "how to handle the relations and it provides " & _
                    "methods that allow you to move from any row of " & _
                    "a table to the related rows of the other tables.")
            .InsertParagraphAfter()
            .InsertParagraphAfter()
            .InsertAfter("ADO.NET uses XML to move rows between " & _
                    "the database and the middle tier, as well as " & _
                    "between the middle tier and the client. " & _
                    "XML passes through firewalls and it's an ideal " & _
                    "candidate for moving binary information between " & _
                    "layers and/or different operating systems.")
        End With
        Dim selRange As Word.Range
        selRange = doc.Paragraphs.Item(1).Range
        selRange.Font.Size = 14
        selRange.Font.Bold = True
        selRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft
        selRange = doc.Paragraphs.Item(2).Range.Sentences.Item(2)
        selRange.Italic = True
        selRange = doc.Paragraphs.Item(3).Range.Words.Item(6)
        selRange.Font.Bold = True
        selRange = doc.Paragraphs.Item(5).Range.Words.Item(5)
        selRange.Font.Bold = True

        Dim fName As String
        SaveFileDialog1.Filter = "Documents|*.doc"
        SaveFileDialog1.ShowDialog()
        fName = SaveFileDialog1.FileName
        If fName <> "" Then
            Try
                doc.SaveAs(fName)
            Catch exc As Exception
                MsgBox("Failed to save document" & _
                        vbCrLf & exc.Message)
            End Try
        End If
        MsgBox("The document contains " & doc.Paragraphs.Count & " paragraphs " & vbCrLf & _
                doc.Words.Count & " words and " & doc.Characters.Count & " words")
        CType(doc, Word._Document).Close(False)
        doc = Nothing
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim thisDoc As Word.Document
        Dim thisRange As Word.Range

        WordApp.Documents.Open("c:\sample.doc")
        WordApp.Visible = False
        thisDoc = WordApp.ActiveDocument
        thisDoc.Content.Find.Execute(FindText:="VB7", _
                   ReplaceWith:="VB.NET", _
                   Replace:=Word.WdReplace.wdReplaceAll)
        While thisDoc.Content.Find.Execute(FindText:="  ", _
                           Wrap:=Word.WdFindWrap.wdFindContinue)
            thisDoc.Content.Find.Execute(FindText:="  ", _
                           ReplaceWith:=" ", _
                           Replace:=Word.WdReplace.wdReplaceAll, _
                           Wrap:=Word.WdFindWrap.wdFindContinue)
        End While
        WordApp.Documents.Item(1).Save()
        MsgBox("Replaced all instances of 'VB7' with 'VB.NET' and saved the document")
        CType(thisDoc, Word._Document).Close(Word.WdSaveOptions.wdDoNotSaveChanges)
    End Sub
End Class
