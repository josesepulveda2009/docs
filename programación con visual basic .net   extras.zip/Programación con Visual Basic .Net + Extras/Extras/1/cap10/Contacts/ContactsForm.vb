Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.

    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtTel As System.Windows.Forms.TextBox
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents txtEMail As System.Windows.Forms.TextBox
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents txtFullName As System.Windows.Forms.TextBox
    Private WithEvents txtFAX As System.Windows.Forms.TextBox
        Private WithEvents bttnReadCompanies As System.Windows.Forms.Button
    Private WithEvents ListofCompanies As System.Windows.Forms.ListBox
    Private WithEvents ListofContacts As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ListofCompanies = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ListofContacts = New System.Windows.Forms.ListBox()
        Me.txtFAX = New System.Windows.Forms.TextBox()
        Me.txtFullName = New System.Windows.Forms.TextBox()
        Me.txtEMail = New System.Windows.Forms.TextBox()
        Me.bttnReadCompanies = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTel = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'ListofCompanies
        '
        Me.ListofCompanies.DisplayMember = "CompanyName"
        Me.ListofCompanies.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.ListofCompanies.ItemHeight = 14
        Me.ListofCompanies.Location = New System.Drawing.Point(8, 8)
        Me.ListofCompanies.Name = "ListofCompanies"
        Me.ListofCompanies.Size = New System.Drawing.Size(192, 186)
        Me.ListofCompanies.TabIndex = 9
        Me.ListofCompanies.ValueMember = "CompanyName"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.Location = New System.Drawing.Point(208, 248)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 24)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Selected Contact Information"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label2.Location = New System.Drawing.Point(208, 304)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Phone"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label3.Location = New System.Drawing.Point(208, 336)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "FAX"
        '
        'ListofContacts
        '
        Me.ListofContacts.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.ListofContacts.ItemHeight = 14
        Me.ListofContacts.Location = New System.Drawing.Point(208, 8)
        Me.ListofContacts.Name = "ListofContacts"
        Me.ListofContacts.Size = New System.Drawing.Size(272, 228)
        Me.ListofContacts.TabIndex = 10
        '
        'txtFAX
        '
        Me.txtFAX.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtFAX.Location = New System.Drawing.Point(320, 336)
        Me.txtFAX.Name = "txtFAX"
        Me.txtFAX.ReadOnly = True
        Me.txtFAX.Size = New System.Drawing.Size(128, 22)
        Me.txtFAX.TabIndex = 5
        Me.txtFAX.Text = ""
        '
        'txtFullName
        '
        Me.txtFullName.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtFullName.Location = New System.Drawing.Point(208, 272)
        Me.txtFullName.Name = "txtFullName"
        Me.txtFullName.ReadOnly = True
        Me.txtFullName.Size = New System.Drawing.Size(272, 22)
        Me.txtFullName.TabIndex = 5
        Me.txtFullName.Text = ""
        '
        'txtEMail
        '
        Me.txtEMail.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtEMail.Location = New System.Drawing.Point(320, 368)
        Me.txtEMail.Name = "txtEMail"
        Me.txtEMail.ReadOnly = True
        Me.txtEMail.Size = New System.Drawing.Size(160, 22)
        Me.txtEMail.TabIndex = 5
        Me.txtEMail.Text = ""
        '
        'bttnReadCompanies
        '
        Me.bttnReadCompanies.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnReadCompanies.Location = New System.Drawing.Point(8, 200)
        Me.bttnReadCompanies.Name = "bttnReadCompanies"
        Me.bttnReadCompanies.Size = New System.Drawing.Size(192, 32)
        Me.bttnReadCompanies.TabIndex = 7
        Me.bttnReadCompanies.Text = "Show Company Names"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label4.Location = New System.Drawing.Point(208, 368)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "E-Mail"
        '
        'txtTel
        '
        Me.txtTel.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtTel.Location = New System.Drawing.Point(320, 304)
        Me.txtTel.Name = "txtTel"
        Me.txtTel.ReadOnly = True
        Me.txtTel.Size = New System.Drawing.Size(128, 22)
        Me.txtTel.TabIndex = 5
        Me.txtTel.Text = ""
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(488, 397)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ListofContacts, Me.ListofCompanies, Me.bttnReadCompanies, Me.txtFAX, Me.txtFullName, Me.Label4, Me.Label2, Me.txtEMail, Me.Label3, Me.txtTel, Me.Label1})
        Me.Name = "Form1"
        Me.Text = "Outlook Contacts"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim OutlookAPP As New Outlook.Application()
    Dim allContacts As Outlook.MAPIFolder
    Dim OLNameSpace As Outlook.NameSpace
    Dim ContactKeys As New ArrayList()

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnReadCompanies.Click

        OLNameSpace = OutlookAPP.GetNamespace("MAPI")
        allContacts = OLNameSpace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderContacts)
        allContacts.Items.Sort("CompanyName")

        Dim contact As Outlook.ContactItem
        Dim cnt As Integer
        ContactKeys.Clear()
        ListofContacts.Items.Clear()
        For cnt = 1 To allContacts.Items.Count
            contact = allContacts.Items.Item(cnt)
            If contact.CompanyName <> "" Then
                If Not ListofCompanies.Items.Contains(contact.CompanyName) Then
                    ListofCompanies.Items.Add(contact.CompanyName)
                End If
            End If
        Next
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListofCompanies.SelectedIndexChanged
        Dim contacts As Outlook._Items
        contacts = allContacts.Items.Restrict("[CompanyName]='" & ListofCompanies.Text & "'")
        Dim contact As Outlook.ContactItem
        Dim cnt As Integer
        ListofContacts.Items.Clear()
        ContactKeys.Clear()
        For cnt = 1 To contacts.Count
            contact = contacts.Item(cnt)
            If contact.Email1Address <> "" Then
                If contact.Email1Address <> "" And (Not ListofContacts.Items.Contains(contact.Email1Address)) Then
                    ListofContacts.Items.Add(contact.Email1Address)
                    ContactKeys.Add(contact.EntryID)
                End If
            End If
        Next
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListofContacts.SelectedIndexChanged
        Dim contact As Outlook.ContactItem
        contact = OLNameSpace.GetItemFromID(ContactKeys(ListofContacts.SelectedIndex))
        txtFullName.Text = ""
        txtTel.Text = ""
        txtFAX.Text = ""
        txtFullName.Text = contact.FullName
        txtTel.Text = contact.BusinessTelephoneNumber
        txtFAX.Text = contact.BusinessFaxNumber
    End Sub

End Class
