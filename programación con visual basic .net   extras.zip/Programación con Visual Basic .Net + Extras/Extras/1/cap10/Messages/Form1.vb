Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Private WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Private WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Private WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Private WithEvents Button1 As System.Windows.Forms.Button
    Private WithEvents Panel1 As System.Windows.Forms.Panel
    Private WithEvents ListView1 As System.Windows.Forms.ListView
    Private WithEvents colSender As System.Windows.Forms.ColumnHeader
    Private WithEvents colSubject As System.Windows.Forms.ColumnHeader
    Private WithEvents colID As System.Windows.Forms.ColumnHeader
    Private WithEvents chkSender As System.Windows.Forms.CheckBox
    Private WithEvents chkDates As System.Windows.Forms.CheckBox
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents lblSender As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents lblSentOn As System.Windows.Forms.Label
    Private WithEvents lblRecvdOn As System.Windows.Forms.Label
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents lblSubject As System.Windows.Forms.Label
    Private WithEvents txtMessage As System.Windows.Forms.TextBox
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents lstAttachments As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblSubject = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.lblRecvdOn = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lstAttachments = New System.Windows.Forms.ListBox()
        Me.lblSentOn = New System.Windows.Forms.Label()
        Me.lblSender = New System.Windows.Forms.Label()
        Me.txtMessage = New System.Windows.Forms.TextBox()
        Me.colSubject = New System.Windows.Forms.ColumnHeader()
        Me.chkSender = New System.Windows.Forms.CheckBox()
        Me.colSender = New System.Windows.Forms.ColumnHeader()
        Me.chkDates = New System.Windows.Forms.CheckBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.colID = New System.Windows.Forms.ColumnHeader()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(128, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(88, 16)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Received On"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(224, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 16)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Subject"
        '
        'lblSubject
        '
        Me.lblSubject.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSubject.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubject.Location = New System.Drawing.Point(312, 8)
        Me.lblSubject.Name = "lblSubject"
        Me.lblSubject.Size = New System.Drawing.Size(312, 16)
        Me.lblSubject.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Sent By"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Sent On"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 16)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Attachments"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(448, 168)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(208, 32)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Show Selected Messages"
        '
        'lblRecvdOn
        '
        Me.lblRecvdOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRecvdOn.Location = New System.Drawing.Point(128, 96)
        Me.lblRecvdOn.Name = "lblRecvdOn"
        Me.lblRecvdOn.Size = New System.Drawing.Size(80, 16)
        Me.lblRecvdOn.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Silver
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstAttachments, Me.Label3, Me.lblSubject, Me.Label6, Me.Label5, Me.lblRecvdOn, Me.lblSentOn, Me.Label2, Me.lblSender, Me.Label1, Me.txtMessage})
        Me.Panel1.Location = New System.Drawing.Point(8, 224)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(648, 224)
        Me.Panel1.TabIndex = 7
        '
        'lstAttachments
        '
        Me.lstAttachments.ItemHeight = 14
        Me.lstAttachments.Location = New System.Drawing.Point(8, 136)
        Me.lstAttachments.Name = "lstAttachments"
        Me.lstAttachments.Size = New System.Drawing.Size(208, 74)
        Me.lstAttachments.TabIndex = 3
        '
        'lblSentOn
        '
        Me.lblSentOn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSentOn.Location = New System.Drawing.Point(8, 96)
        Me.lblSentOn.Name = "lblSentOn"
        Me.lblSentOn.Size = New System.Drawing.Size(80, 16)
        Me.lblSentOn.TabIndex = 2
        '
        'lblSender
        '
        Me.lblSender.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSender.Location = New System.Drawing.Point(8, 40)
        Me.lblSender.Name = "lblSender"
        Me.lblSender.Size = New System.Drawing.Size(208, 16)
        Me.lblSender.TabIndex = 2
        '
        'txtMessage
        '
        Me.txtMessage.Location = New System.Drawing.Point(224, 32)
        Me.txtMessage.Multiline = True
        Me.txtMessage.Name = "txtMessage"
        Me.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMessage.Size = New System.Drawing.Size(416, 184)
        Me.txtMessage.TabIndex = 0
        Me.txtMessage.Text = ""
        '
        'colSubject
        '
        Me.colSubject.Text = "Subject"
        Me.colSubject.Width = 400
        '
        'chkSender
        '
        Me.chkSender.Location = New System.Drawing.Point(432, 16)
        Me.chkSender.Name = "chkSender"
        Me.chkSender.Size = New System.Drawing.Size(192, 24)
        Me.chkSender.TabIndex = 1
        Me.chkSender.Text = "From this sender"
        '
        'colSender
        '
        Me.colSender.Text = "Sender"
        Me.colSender.Width = 150
        '
        'chkDates
        '
        Me.chkDates.Location = New System.Drawing.Point(432, 88)
        Me.chkDates.Name = "chkDates"
        Me.chkDates.Size = New System.Drawing.Size(168, 24)
        Me.chkDates.TabIndex = 3
        Me.chkDates.Text = "Between these dates"
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownWidth = 208
        Me.ComboBox1.Location = New System.Drawing.Point(456, 48)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(200, 22)
        Me.ComboBox1.TabIndex = 2
        Me.ComboBox1.Text = "ComboBox1"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.DateTimePicker1.Location = New System.Drawing.Point(448, 120)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(96, 22)
        Me.DateTimePicker1.TabIndex = 4
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 50
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.DateTimePicker2.Location = New System.Drawing.Point(560, 120)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(96, 22)
        Me.DateTimePicker2.TabIndex = 5
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSender, Me.colSubject, Me.colID})
        Me.ListView1.FullRowSelect = True
        Me.ListView1.Location = New System.Drawing.Point(8, 8)
        Me.ListView1.MultiSelect = False
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(408, 208)
        Me.ListView1.TabIndex = 8
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(7, 15)
        Me.ClientSize = New System.Drawing.Size(664, 453)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ListView1, Me.Panel1, Me.Button1, Me.DateTimePicker2, Me.DateTimePicker1, Me.chkDates, Me.ComboBox1, Me.chkSender})
        Me.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "Messages Demo Project"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim OutlookApp As New outlook.Application()
    Dim InBox As outlook.MAPIFolder
    Dim OLObjects As Outlook.NameSpace

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim OLNameSpace As Outlook.NameSpace
        OLNameSpace = OutlookApp.GetNamespace("MAPI")
        InBox = OLNameSpace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderInbox)
        Dim selMessages As Outlook._Items
        Dim filter As String
        ListView1.Items.Clear()
        If chkSender.Checked Then
            filter = "[SenderName]='" & ComboBox1.Text & "'"
        End If
        If chkDates.Checked Then
            If filter <> "" Then filter = filter & " And "
            filter = filter & "[SentOn] > '" & DateTimePicker1.Value.ToShortDateString & "' And [SentOn] <= '" & DateTimePicker2.Value.ToShortDateString & "'"
        End If
        If filter <> "" Then
            selMessages = InBox.Items.Restrict(filter)
        Else
            selMessages = InBox.Items
        End If
        Dim mssg As Outlook.MailItem
        Dim imssg As Integer
        Dim itm As ListViewItem
        For imssg = 1 To selMessages.Count
            mssg = selMessages.Item(imssg)
            itm = New ListViewItem()
            itm.Text = mssg.SenderName
            itm.SubItems.Add(mssg.Subject)
            itm.SubItems.Add(mssg.EntryID)
            ListView1.Items.Add(itm)
            itm = Nothing
        Next
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        OLObjects = OutlookApp.GetNamespace("MAPI")
        InBox = OLObjects.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderInbox)
        Dim mssg As Outlook.MailItem
        Dim imssg As Integer
        For imssg = 1 To InBox.Items.Count
            mssg = InBox.Items.Item(imssg)
            If Not mssg.SenderName Is Nothing Then
                If Not ComboBox1.Items.Contains(mssg.SenderName) Then
                    ComboBox1.Items.Add(mssg.SenderName)
                End If
            End If
        Next
        ComboBox1.Sorted = True
        ComboBox1.SelectedIndex = 0
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        Dim selID As String
        If ListView1.SelectedItems.Count() = 0 Then Exit Sub
        txtMessage.Text = ""
        selID = ListView1.SelectedItems(0).SubItems(2).Text
        Dim mssg As Outlook.MailItem
        mssg = OLObjects.GetItemFromID(selID)
        txtMessage.Text = mssg.Body
        lblSubject.Text = mssg.Subject
        lblSender.Text = mssg.SenderName
        lblSentOn.Text = mssg.SentOn.ToShortDateString
        lblRecvdOn.Text = mssg.ReceivedTime.ToShortDateString
        Dim i As Integer
        lstAttachments.Items.Clear()
        For i = 1 To mssg.Attachments.Count
            lstAttachments.Items.Add(mssg.Attachments.Item(i).FileName)
        Next
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        chkSender.Checked = True
    End Sub

    Private Sub DateTimePicker1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePicker1.ValueChanged
        chkDates.Checked = True
    End Sub

    Private Sub lstAttachments_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstAttachments.SelectedIndexChanged
        System.Diagnostics.Process.Start(lstAttachments.SelectedItem)

    End Sub
End Class
