Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Private WithEvents TreeView1 As System.Windows.Forms.TreeView
    Private WithEvents ListBox1 As System.Windows.Forms.ListBox
    Private WithEvents bttnShowContacts As System.Windows.Forms.Button
    Friend WithEvents bttnSend As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.bttnShowContacts = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.bttnSend = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bttnShowContacts
        '
        Me.bttnShowContacts.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnShowContacts.Location = New System.Drawing.Point(8, 264)
        Me.bttnShowContacts.Name = "bttnShowContacts"
        Me.bttnShowContacts.Size = New System.Drawing.Size(200, 32)
        Me.bttnShowContacts.TabIndex = 0
        Me.bttnShowContacts.Text = "Show All Contact Folders"
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(224, 8)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ListBox1.Size = New System.Drawing.Size(296, 244)
        Me.ListBox1.TabIndex = 2
        '
        'TreeView1
        '
        Me.TreeView1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(8, 8)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(200, 248)
        Me.TreeView1.TabIndex = 1
        '
        'bttnSend
        '
        Me.bttnSend.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnSend.Location = New System.Drawing.Point(232, 264)
        Me.bttnSend.Name = "bttnSend"
        Me.bttnSend.Size = New System.Drawing.Size(280, 32)
        Me.bttnSend.TabIndex = 0
        Me.bttnSend.Text = "Send Message to Selected Contacts"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(528, 301)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.bttnSend, Me.ListBox1, Me.TreeView1, Me.bttnShowContacts})
        Me.Name = "Form1"
        Me.Text = "AllContacts Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim OutlookApp As New Outlook.Application()
    Dim OlObjects As Outlook.NameSpace
    Dim OlContacts As Outlook.MAPIFolder

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnShowContacts.Click
        OlObjects = OutlookApp.GetNamespace("MAPI")
        OlContacts = OlObjects.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderContacts)
        Dim rootNode, newNode As TreeNode
        rootNode = TreeView1.Nodes.Add("Contacts")
        rootNode.Tag = OlContacts.EntryID

        Dim allFolders As Outlook.Folders
        Dim folder As Outlook.MAPIFolder
        allFolders = OlContacts.Folders

        folder = allFolders.GetFirst
        While Not folder Is Nothing
            newNode = rootNode.Nodes.Add(folder.Name)
            ScanSubFolders(folder, newNode)
            folder = allFolders.GetNext
        End While
    End Sub

    Private Sub ScanSubFolders(ByVal currentFolder As outlook.MAPIFolder, ByVal currentNode As TreeNode)
        Dim subfolders As Outlook.Folders
        subfolders = currentFolder.Folders
        Dim parentNode As TreeNode = currentNode
        Dim newNode As TreeNode
        If subfolders.Count > 0 Then
            Dim strFolderKey As String
            Dim subFolder As Outlook.MAPIFolder
            subFolder = subfolders.GetFirst
            While Not subFolder Is Nothing
                newNode = parentNode.Nodes.Add(subFolder.Name)
                newNode.Tag = subFolder.EntryID
                ScanSubFolders(subFolder, newNode)
                subFolder = subfolders.GetNext
            End While
        End If
    End Sub

    Private Sub TreeView1_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView1.AfterSelect
        If e.Node.Tag Is Nothing Then Exit Sub
        Dim folderid As String = e.Node.Tag
        Dim selFolder As Outlook.MAPIFolder
        selFolder = OlObjects.GetFolderFromID(folderid)
        Dim itm As Integer
        ListBox1.Items.Clear()
        For itm = 1 To selFolder.Items.Count
            ListBox1.Items.Add(selFolder.Items.Item(itm).Email1Address)
            ListBox1.Items.Add(vbTab & selFolder.Items.Item(itm).FullName)
        Next
    End Sub

    Private Sub bttnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnSend.Click
        Dim msg As Outlook.MailItem
        msg = OutlookApp.CreateItem(Outlook.OlItemType.olMailItem)
        Dim iContact As Integer
        For iContact = 0 To ListBox1.SelectedIndices.Count - 1
            msg.Recipients.Add(ListBox1.Items(ListBox1.SelectedIndices.Item(iContact).ToString)
            msg.Subject = "Automated Message"
            msg.Body = "Enter the message's body here"
            msg.send()
        Next
    End Sub
End Class
