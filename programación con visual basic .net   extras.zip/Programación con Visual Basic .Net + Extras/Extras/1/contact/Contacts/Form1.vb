Option Strict On
Imports System.IO
Imports System.runtime.Serialization
Imports System.runtime.Serialization.Formatters.Binary

Public Class Form1

    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents txtCompany As System.Windows.Forms.TextBox
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress1 As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents txtZIP As System.Windows.Forms.TextBox
    Friend WithEvents txtTel As System.Windows.Forms.TextBox
    Friend WithEvents txtEMail As System.Windows.Forms.TextBox
    Friend WithEvents txtURL As System.Windows.Forms.TextBox
    Friend WithEvents bttnFirst As System.Windows.Forms.Button
    Friend WithEvents bttnPrevious As System.Windows.Forms.Button
    Friend WithEvents bttnNext As System.Windows.Forms.Button
    Friend WithEvents bttnLast As System.Windows.Forms.Button
    Friend WithEvents bttnAdd As System.Windows.Forms.Button
    Friend WithEvents bttnDelete As System.Windows.Forms.Button
    Friend WithEvents bttnOK As System.Windows.Forms.Button
    Friend WithEvents bttnCancel As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents bttnEdit As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents FileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FileNew As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItemfileLoad As System.Windows.Forms.MenuItem
    Friend WithEvents FileSave As System.Windows.Forms.MenuItem
    Friend WithEvents FileExit As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.bttnNext = New System.Windows.Forms.Button()
        Me.bttnOK = New System.Windows.Forms.Button()
        Me.bttnFirst = New System.Windows.Forms.Button()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.bttnAdd = New System.Windows.Forms.Button()
        Me.bttnCancel = New System.Windows.Forms.Button()
        Me.FileNew = New System.Windows.Forms.MenuItem()
        Me.bttnPrevious = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtTel = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.FileMenu = New System.Windows.Forms.MenuItem()
        Me.MenuItem6 = New System.Windows.Forms.MenuItem()
        Me.MenuItemfileLoad = New System.Windows.Forms.MenuItem()
        Me.FileSave = New System.Windows.Forms.MenuItem()
        Me.MenuItem7 = New System.Windows.Forms.MenuItem()
        Me.FileExit = New System.Windows.Forms.MenuItem()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtEMail = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtZIP = New System.Windows.Forms.TextBox()
        Me.txtAddress1 = New System.Windows.Forms.TextBox()
        Me.txtAddress2 = New System.Windows.Forms.TextBox()
        Me.bttnLast = New System.Windows.Forms.Button()
        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.txtURL = New System.Windows.Forms.TextBox()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.bttnDelete = New System.Windows.Forms.Button()
        Me.bttnEdit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'bttnNext
        '
        Me.bttnNext.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnNext.Location = New System.Drawing.Point(312, 304)
        Me.bttnNext.Name = "bttnNext"
        Me.bttnNext.Size = New System.Drawing.Size(72, 32)
        Me.bttnNext.TabIndex = 25
        Me.bttnNext.Text = ">"
        '
        'bttnOK
        '
        Me.bttnOK.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnOK.Location = New System.Drawing.Point(408, 264)
        Me.bttnOK.Name = "bttnOK"
        Me.bttnOK.Size = New System.Drawing.Size(72, 32)
        Me.bttnOK.TabIndex = 27
        Me.bttnOK.Text = "OK"
        Me.bttnOK.Visible = False
        '
        'bttnFirst
        '
        Me.bttnFirst.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnFirst.Location = New System.Drawing.Point(120, 304)
        Me.bttnFirst.Name = "bttnFirst"
        Me.bttnFirst.Size = New System.Drawing.Size(72, 32)
        Me.bttnFirst.TabIndex = 23
        Me.bttnFirst.Text = "<<"
        '
        'txtContact
        '
        Me.txtContact.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtContact.Location = New System.Drawing.Point(120, 46)
        Me.txtContact.Name = "txtContact"
        Me.txtContact.ReadOnly = True
        Me.txtContact.Size = New System.Drawing.Size(264, 22)
        Me.txtContact.TabIndex = 3
        Me.txtContact.Text = ""
        '
        'bttnAdd
        '
        Me.bttnAdd.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnAdd.Location = New System.Drawing.Point(120, 264)
        Me.bttnAdd.Name = "bttnAdd"
        Me.bttnAdd.Size = New System.Drawing.Size(72, 32)
        Me.bttnAdd.TabIndex = 20
        Me.bttnAdd.Text = "Add"
        '
        'bttnCancel
        '
        Me.bttnCancel.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnCancel.Location = New System.Drawing.Point(120, 264)
        Me.bttnCancel.Name = "bttnCancel"
        Me.bttnCancel.Size = New System.Drawing.Size(72, 32)
        Me.bttnCancel.TabIndex = 28
        Me.bttnCancel.Text = "Cancel"
        Me.bttnCancel.Visible = False
        '
        'FileNew
        '
        Me.FileNew.Index = 0
        Me.FileNew.Text = "New collection"
        '
        'bttnPrevious
        '
        Me.bttnPrevious.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnPrevious.Location = New System.Drawing.Point(216, 304)
        Me.bttnPrevious.Name = "bttnPrevious"
        Me.bttnPrevious.Size = New System.Drawing.Size(72, 32)
        Me.bttnPrevious.TabIndex = 24
        Me.bttnPrevious.Text = "<"
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label10.Location = New System.Drawing.Point(344, 139)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(32, 16)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "ZIP"
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label8.Location = New System.Drawing.Point(8, 229)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 16)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "&URL"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label9.Location = New System.Drawing.Point(240, 139)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 16)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "State"
        '
        'txtTel
        '
        Me.txtTel.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtTel.Location = New System.Drawing.Point(120, 166)
        Me.txtTel.Name = "txtTel"
        Me.txtTel.ReadOnly = True
        Me.txtTel.Size = New System.Drawing.Size(120, 22)
        Me.txtTel.TabIndex = 15
        Me.txtTel.Text = ""
        '
        'txtCity
        '
        Me.txtCity.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtCity.Location = New System.Drawing.Point(120, 136)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.ReadOnly = True
        Me.txtCity.TabIndex = 9
        Me.txtCity.Text = ""
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 109)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Address2"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 139)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 16)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "City"
        '
        'FileMenu
        '
        Me.FileMenu.Index = 0
        Me.FileMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileNew, Me.MenuItem6, Me.MenuItemfileLoad, Me.FileSave, Me.MenuItem7, Me.FileExit})
        Me.FileMenu.Text = "File"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 1
        Me.MenuItem6.Text = "-"
        '
        'MenuItemfileLoad
        '
        Me.MenuItemfileLoad.Index = 2
        Me.MenuItemfileLoad.Text = "Load Collection"
        '
        'FileSave
        '
        Me.FileSave.Index = 3
        Me.FileSave.Text = "Save Collection"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 4
        Me.MenuItem7.Text = "-"
        '
        'FileExit
        '
        Me.FileExit.Index = 5
        Me.FileExit.Text = "Exit"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label7.Location = New System.Drawing.Point(8, 199)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 16)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "&EMail"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Contact"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 16)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Address1"
        '
        'txtEMail
        '
        Me.txtEMail.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtEMail.Location = New System.Drawing.Point(120, 196)
        Me.txtEMail.Name = "txtEMail"
        Me.txtEMail.ReadOnly = True
        Me.txtEMail.Size = New System.Drawing.Size(184, 22)
        Me.txtEMail.TabIndex = 17
        Me.txtEMail.Text = ""
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 169)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 16)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Telephone"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileMenu})
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "&Company"
        '
        'txtZIP
        '
        Me.txtZIP.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtZIP.Location = New System.Drawing.Point(384, 136)
        Me.txtZIP.Name = "txtZIP"
        Me.txtZIP.ReadOnly = True
        Me.txtZIP.Size = New System.Drawing.Size(56, 22)
        Me.txtZIP.TabIndex = 13
        Me.txtZIP.Text = ""
        '
        'txtAddress1
        '
        Me.txtAddress1.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtAddress1.Location = New System.Drawing.Point(120, 76)
        Me.txtAddress1.Name = "txtAddress1"
        Me.txtAddress1.ReadOnly = True
        Me.txtAddress1.Size = New System.Drawing.Size(360, 22)
        Me.txtAddress1.TabIndex = 5
        Me.txtAddress1.Text = ""
        '
        'txtAddress2
        '
        Me.txtAddress2.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtAddress2.Location = New System.Drawing.Point(120, 106)
        Me.txtAddress2.Name = "txtAddress2"
        Me.txtAddress2.ReadOnly = True
        Me.txtAddress2.Size = New System.Drawing.Size(360, 22)
        Me.txtAddress2.TabIndex = 7
        Me.txtAddress2.Text = ""
        '
        'bttnLast
        '
        Me.bttnLast.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnLast.Location = New System.Drawing.Point(406, 304)
        Me.bttnLast.Name = "bttnLast"
        Me.bttnLast.Size = New System.Drawing.Size(72, 32)
        Me.bttnLast.TabIndex = 26
        Me.bttnLast.Text = ">>"
        '
        'txtCompany
        '
        Me.txtCompany.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtCompany.Location = New System.Drawing.Point(120, 16)
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.ReadOnly = True
        Me.txtCompany.Size = New System.Drawing.Size(320, 22)
        Me.txtCompany.TabIndex = 1
        Me.txtCompany.Text = ""
        '
        'txtURL
        '
        Me.txtURL.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtURL.Location = New System.Drawing.Point(120, 226)
        Me.txtURL.Name = "txtURL"
        Me.txtURL.ReadOnly = True
        Me.txtURL.Size = New System.Drawing.Size(328, 22)
        Me.txtURL.TabIndex = 19
        Me.txtURL.Text = ""
        '
        'txtState
        '
        Me.txtState.Font = New System.Drawing.Font("Verdana", 9!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtState.Location = New System.Drawing.Point(288, 136)
        Me.txtState.Name = "txtState"
        Me.txtState.ReadOnly = True
        Me.txtState.Size = New System.Drawing.Size(40, 22)
        Me.txtState.TabIndex = 11
        Me.txtState.Text = ""
        '
        'bttnDelete
        '
        Me.bttnDelete.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnDelete.Location = New System.Drawing.Point(408, 264)
        Me.bttnDelete.Name = "bttnDelete"
        Me.bttnDelete.Size = New System.Drawing.Size(72, 32)
        Me.bttnDelete.TabIndex = 22
        Me.bttnDelete.Text = "Delete"
        '
        'bttnEdit
        '
        Me.bttnEdit.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.bttnEdit.Location = New System.Drawing.Point(256, 264)
        Me.bttnEdit.Name = "bttnEdit"
        Me.bttnEdit.Size = New System.Drawing.Size(72, 32)
        Me.bttnEdit.TabIndex = 21
        Me.bttnEdit.Text = "Edit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(488, 341)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.bttnEdit, Me.Label10, Me.Label9, Me.Label8, Me.Label7, Me.Label6, Me.Label5, Me.Label4, Me.Label3, Me.Label2, Me.Label1, Me.bttnCancel, Me.bttnOK, Me.bttnDelete, Me.bttnAdd, Me.bttnLast, Me.bttnNext, Me.bttnPrevious, Me.bttnFirst, Me.txtURL, Me.txtEMail, Me.txtTel, Me.txtZIP, Me.txtState, Me.txtCity, Me.txtAddress2, Me.txtAddress1, Me.txtContact, Me.txtCompany})
        Me.KeyPreview = True
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Contacts Demo"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' A simple application that demonstrates how the design of a functional
    ' data browsing and editing form.
    ' The data resides in an ArrayList and the form displays one record at a time.
    ' Fields can be edited only with the edit buttons (Edit/Add/Delete) and the
    ' corresponding operation must end by clicking the Ok/Cancel button.

    ' The project also demonstrates how to serialize and deserialize an ArrayList
    ' of structures. This topic of serialization is discussed in detail in Chapter 11.

    ' IN CHAPTER 8 YOU WILL FIND A DIFFERENT IMPLEMENTATION OF THE SAME APPLICATION
    ' THAT USES A CLASS AND STORES EACH CONTACT ON A LISTBOX CONTROL. THE LISTBOX
    ' CONTROL IS USED AS A MORE FUNCTIONAL NAVIGATIONAL TOOL

    <Serializable()> Structure Contact
        Dim Company As String
        Dim Name As String
        Dim Address1 As String
        Dim Address2 As String
        Dim City As String
        Dim State As String
        Dim ZIP As String
        Dim Tel As String
        Dim EMail As String
        Dim URL As String
    End Structure

    Dim MyContacts As New ArrayList()
    Dim currentContact As Integer
    Dim adding As Boolean

    Private Sub bttnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnCancel.Click
        ShowContact()
        ShowButtons()
    End Sub

    Private Sub bttnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnOK.Click
        Dim contact As New Contact()
        SaveContact()
        ShowButtons()
    End Sub

    Private Sub bttnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnDelete.Click
        If currentContact > -1 Then
            MyContacts.RemoveAt(currentContact)
            If currentContact = MyContacts.Count Then currentContact = MyContacts.Count - 1
            If currentContact = -1 Then
                ClearFields()
                MsgBox("There are no more contacts")
            Else
                ShowContact()
            End If
        Else
            MsgBox("No selected contact to delete")
        End If
    End Sub

    Private Sub bttnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bttnAdd.Click
        adding = True
        ClearFields()
        HideButtons()
    End Sub

    Private Sub bttnFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnFirst.Click
        currentContact = 0
        ShowContact()
    End Sub

    Private Sub bttnLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnLast.Click
        currentContact = MyContacts.Count - 1
        ShowContact()
    End Sub

    Private Sub bttnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnPrevious.Click
        If currentContact > 0 Then
            currentContact -= 1
        End If
        ShowContact()
    End Sub

    Private Sub bttnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnNext.Click
        If currentContact < MyContacts.Count - 1 Then
            currentContact += 1
        End If
        ShowContact()
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        ' F10 displays the number of contacts
        If e.KeyCode = Keys.F10 Then
            MsgBox("There are " & MyContacts.Count.ToString & _
                      " contacts in the database")
            e.Handled = True
        End If
        ' ALT+ takes you to next contact, ALT- takes you to previous contact
        If e.KeyCode = Keys.Subtract And e.Modifiers = Keys.Alt Then
            bttnPrevious_Click(sender, e)
        End If
        If e.KeyCode = Keys.Add And e.Modifiers = Keys.Alt Then
            bttnNext_Click(sender, e)
        End If
    End Sub

    Private Sub Form1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        If Not bttnOK.Visible Then
            e.Handled = True
        End If
    End Sub

    Private Sub FileSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileSave.Click
        Dim saveFile As FileStream
        saveFile = File.Create("..\CONTACTS.BIN")
        saveFile.Seek(0, SeekOrigin.End)
        Dim Formatter As BinaryFormatter = New BinaryFormatter()
        Formatter.Serialize(saveFile, MyContacts)
        saveFile.Close()
        Formatter = Nothing
    End Sub

    Private Sub MenuItemfileLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemfileLoad.Click
        Dim readFile As FileStream
        readFile = File.OpenRead("..\CONTACTS.BIN")
        Dim Formatter As New BinaryFormatter()
        MyContacts = CType(Formatter.Deserialize(readFile), ArrayList)
        readFile.Close()
        Formatter = Nothing
        currentContact = 0
        ShowContact()
    End Sub

    Private Sub FileNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileNew.Click
        MyContacts.Clear()
    End Sub

    Private Sub FileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileExit.Click
        End
    End Sub

    Sub SaveContact()
        Dim contact As New Contact()
        If Not adding Then
            contact = CType(MyContacts.Item(currentContact), Contact)
        End If
        contact.Company = txtCompany.Text
        contact.Name = txtContact.Text
        contact.Address1 = txtAddress1.Text
        contact.Address2 = txtAddress2.Text
        contact.City = txtCity.Text
        contact.State = txtState.Text
        contact.ZIP = txtZIP.Text
        contact.Tel = txtTel.Text
        contact.EMail = txtEMail.Text
        contact.URL = txtURL.Text
        If adding Then
            currentContact = MyContacts.Add(contact)
        Else
            MyContacts.Item(currentContact) = contact
        End If
    End Sub

    Private Sub bttnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnEdit.Click
        If currentContact <= 0 Then
            MsgBox("Please select a contact to edit")
            Exit Sub
        End If
        adding = False
        HideButtons()
    End Sub

    ' Helper routines to show contact, show/hide editing buttons 
    Sub ShowContact()
        Dim contact As New Contact()
        contact = CType(MyContacts(currentContact), Contact)
        txtCompany.Text = contact.Company
        txtContact.Text = contact.Name
        txtAddress1.Text = contact.Address1
        txtAddress2.Text = contact.Address2
        txtCity.Text = contact.City
        txtState.Text = contact.State
        txtZIP.Text = contact.ZIP
        txtTel.Text = contact.Tel
        txtEMail.Text = contact.EMail
        txtURL.Text = contact.URL
    End Sub

    Sub HideButtons()
        UnlockControls()
        bttnAdd.Visible = False
        bttnDelete.Visible = False
        bttnEdit.Visible = False
        bttnFirst.Visible = False
        bttnLast.Visible = False
        bttnPrevious.Visible = False
        bttnNext.Visible = False
        bttnOK.Visible = True
        bttnCancel.Visible = True
    End Sub

    Sub LockControls()
        txtCompany.ReadOnly = True
        txtContact.ReadOnly = True
        txtAddress1.ReadOnly = True
        txtAddress2.ReadOnly = True
        txtCity.ReadOnly = True
        txtState.ReadOnly = True
        txtZIP.ReadOnly = True
        txtTel.ReadOnly = True
        txtEMail.ReadOnly = True
        txtURL.ReadOnly = True
    End Sub

    Sub UnlockControls()
        txtCompany.ReadOnly = False
        txtContact.ReadOnly = False
        txtAddress1.ReadOnly = False
        txtAddress2.ReadOnly = False
        txtCity.ReadOnly = False
        txtState.ReadOnly = False
        txtZIP.ReadOnly = False
        txtTel.ReadOnly = False
        txtEMail.ReadOnly = False
        txtURL.ReadOnly = False
    End Sub

    Sub ShowButtons()
        LockControls()
        bttnAdd.Visible = True
        bttnDelete.Visible = True
        bttnEdit.Visible = True
        bttnFirst.Visible = True
        bttnLast.Visible = True
        bttnPrevious.Visible = True
        bttnNext.Visible = True
        bttnOK.Visible = False
        bttnCancel.Visible = False
    End Sub

    Sub ClearFields()
        txtCompany.Text = ""
        txtContact.Text = ""
        txtAddress1.Text = ""
        txtAddress2.Text = ""
        txtCity.Text = ""
        txtZIP.Text = ""
        txtState.Text = ""
        txtTel.Text = ""
        txtEMail.Text = ""
        txtURL.Text = ""
    End Sub

End Class
