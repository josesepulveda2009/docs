The file CONTACTS.BIN contains the sample contacts.
This file must reside in the BIN folder under the project's folder. If you delete the BIN folder, please copy the CONTACTS.BIN file into the new BIN folder that will be created when you rebuild the project.

You can also add a File Open dialog box to prompt the user for the contacts file to open. In this case, the sample CONTACTS.BIN file may reside anywhere on your hard disk.
