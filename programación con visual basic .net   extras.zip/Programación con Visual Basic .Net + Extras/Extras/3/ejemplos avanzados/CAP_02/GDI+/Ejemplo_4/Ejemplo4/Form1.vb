Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(24, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(48, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "1"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(96, 8)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(48, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "2"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(168, 8)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(48, 23)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "3"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(240, 8)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(48, 23)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "4"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(312, 318)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button4, Me.Button3, Me.Button2, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Gradiente Diagonal hacia adelante
        Dim Forma As New Rectangle(New Point(0, 0), Me.ClientSize)
        Dim Gradiente As New Drawing2D.LinearGradientBrush(Forma, Color.Yellow, Color.DarkOrange, Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal)
        Me.CreateGraphics.FillEllipse(Gradiente, Forma)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Gradiente Diagonal hacia atr�s
        Dim Forma As New Rectangle(New Point(0, 0), Me.ClientSize)
        Dim Gradiente As New Drawing2D.LinearGradientBrush(Forma, Color.Aqua, Color.DarkBlue, Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal)
        Me.CreateGraphics.FillEllipse(Gradiente, Forma)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Gradiente Vertical
        Dim Forma As New Rectangle(New Point(0, 0), Me.ClientSize)
        Dim Gradiente As New Drawing2D.LinearGradientBrush(Forma, Color.White, Color.Black, Drawing.Drawing2D.LinearGradientMode.Vertical)
        Me.CreateGraphics.FillEllipse(Gradiente, Forma)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        'Gradiente Horizontal
        Dim Forma As New Rectangle(New Point(0, 0), Me.ClientSize)
        Dim Gradiente As New Drawing2D.LinearGradientBrush(Forma, Color.Bisque, Color.DarkOrchid, Drawing.Drawing2D.LinearGradientMode.Horizontal)
        Me.CreateGraphics.FillEllipse(Gradiente, Forma)
    End Sub
End Class
