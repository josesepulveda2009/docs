Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(504, 390)
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region


    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim Grafico As Graphics = e.Graphics

        'Representaci�n de un gr�fico de rect�ngulos
        Grafico.DrawRectangle(New Pen(Color.DarkBlue, 3), New Rectangle(10, 10, 100, 50))
        Grafico.DrawRectangle(New Pen(Color.White, 1), New Rectangle(10, 10, 100, 50))
        Grafico.FillRectangle(New SolidBrush(Color.Firebrick), New Rectangle(12, 12, 60, 47))
        Grafico.FillRectangle(New SolidBrush(Color.BlanchedAlmond), New Rectangle(69, 12, 40, 47))

        'Representaci�n de puntos cerrando figura
        Dim Puntos(4) As Point
        Puntos(0).X = 130 : Puntos(0).Y = 10
        Puntos(1).X = 230 : Puntos(1).Y = 10
        Puntos(2).X = 230 : Puntos(2).Y = 60
        Puntos(3).X = 130 : Puntos(3).Y = 60
        Puntos(4).X = 130 : Puntos(4).Y = 10
        Grafico.DrawLines(New Pen(Color.DarkBlue), Puntos)

        'Declaraci�n de Lapiz
        Dim Lapiz As New Pen(Color.DarkBlue, 5)

        'Extremo redondeado grande y Flecha
        Lapiz.StartCap = Drawing.Drawing2D.LineCap.RoundAnchor
        Lapiz.EndCap = Drawing.Drawing2D.LineCap.ArrowAnchor
        Grafico.DrawLine(Lapiz, 10, 80, 110, 80)

        'Redondeado y Flecha
        Lapiz.StartCap = Drawing.Drawing2D.LineCap.Round
        Lapiz.EndCap = Drawing.Drawing2D.LineCap.ArrowAnchor
        Grafico.DrawLine(Lapiz, 10, 110, 110, 110)

        'Diamante y Tri�ngulo
        Lapiz.StartCap = Drawing.Drawing2D.LineCap.DiamondAnchor
        Lapiz.EndCap = Drawing.Drawing2D.LineCap.Triangle
        Grafico.DrawLine(Lapiz, 10, 140, 110, 140)

        'Cerrando l�neas
        Lapiz.StartCap = Drawing.Drawing2D.LineCap.ArrowAnchor
        Lapiz.EndCap = Drawing.Drawing2D.LineCap.ArrowAnchor
        Grafico.DrawLine(Lapiz, 10, 170, 110, 170)
        Grafico.DrawLine(Lapiz, 10, 170, 10, 200)
        Grafico.DrawLine(Lapiz, 10, 200, 110, 200)
        Grafico.DrawLine(Lapiz, 110, 200, 110, 170)

        'Dibujando y uniendo l�neas en figuras no cerradas
        Dim Camino As New Drawing.Drawing2D.GraphicsPath()
        Camino.StartFigure()
        Camino.AddLine(New Point(110, 230), New Point(10, 230))
        Camino.AddLine(New Point(10, 240), New Point(10, 280))
        Camino.AddLine(New Point(20, 260), New Point(80, 280))
        Grafico.DrawPath(New Pen(Color.DarkGoldenrod, 3), Camino)

        'Dibujando un rect�ngulo con textura y con l�neas discontinuas personalizadas
        Dim Valores As Single() = {5, 1}
        Dim Imagen As New Bitmap("C:\LIBRO\CAP_02\GDI+\Ejemplo_1\Ejemplo1\Textura.jpg")
        Dim Cepillo As New TextureBrush(Imagen)
        Dim TexturaPincel As New Pen(Cepillo, 5)
        TexturaPincel.DashPattern = Valores
        Grafico.DrawRectangle(TexturaPincel, 130, 70, 100, 50)

        'Dibujando un rect�ngulo con l�neas discontinuas no personalizadas
        TexturaPincel = New Pen(Color.DarkBlue, 3)
        TexturaPincel.DashStyle = Drawing.Drawing2D.DashStyle.Dot
        Grafico.DrawRectangle(TexturaPincel, 130, 130, 100, 50)
    End Sub
End Class
