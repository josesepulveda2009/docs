Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Location = New System.Drawing.Point(8, 40)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(496, 272)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'ComboBox1
        '
        Me.ComboBox1.Location = New System.Drawing.Point(8, 8)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(176, 21)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.Text = "ComboBox1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ClientSize = New System.Drawing.Size(512, 382)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ComboBox1, Me.PictureBox1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.Items.Clear()
        ComboBox1.Text = ""
        ComboBox1.Items.Add("Dibujar texto simple I")
        ComboBox1.Items.Add("Dibujar texto simple II")
        ComboBox1.Items.Add("Dibujar texto con textura")
        ComboBox1.Items.Add("Dibujar texto en un �rea")
        ComboBox1.Items.Add("Dibujar im�genes")
        ComboBox1.Items.Add("Dibujar texto girado")
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        PictureBox1.CreateGraphics.Clear(Color.Blue)
        PictureBox1.Refresh()
        Dim MiFuente As Font
        MiFuente = New Font("Verdana", 36)
        Select Case ComboBox1.Text
            Case "Dibujar texto simple I"
                With PictureBox1.CreateGraphics
                    'Dibujar texto simple I
                    'Declaramos un color para la brocha
                    Dim Brocha As New SolidBrush(Color.FromArgb(128, 0, 128, 255))
                    .DrawString("Texto con GDI+", New Font("Verdana", 32, FontStyle.Bold, GraphicsUnit.Pixel), Brocha, 12, 8)
                    'Asignamos otro color para la brocha
                    Brocha = New SolidBrush(Color.DarkBlue)
                    'Declaramos una posici�n
                    Dim Inicio As New PointF(10, 10)
                    'Declaramos una fuente de letra y sus propiedades
                    Dim Fuente As New Font("Verdana", 32, FontStyle.Bold, GraphicsUnit.Pixel)
                    'ObjGrafico.DrawString("Texto con GDI+", Fuente, Brocha, Inicio)
                    .DrawString("Texto con GDI+", Fuente, Brocha, Inicio)
                End With
            Case "Dibujar texto simple II"
                With PictureBox1.CreateGraphics
                    'Dibujando Texto simple II
                    MiFuente = New Font("Verdana", 24, FontStyle.Bold)
                    .FillRectangle(New SolidBrush(Color.White), ClientRectangle)
                    .DrawString("Texto con GDI+", MiFuente, New SolidBrush(Color.BlueViolet), 10, 10)
                End With
            Case "Dibujar texto con textura"
                With PictureBox1.CreateGraphics
                    'Dibujando Texto con textura
                    Dim BrochaSombra As New SolidBrush(Color.FromArgb(85, Color.DarkBlue))
                    Dim BrochaPrincipal As New TextureBrush(New Bitmap("C:\LIBRO\CAP_02\GDI+\Ejemplo_3\Ejemplo3\Textura2.jpg"))
                    Dim TexturaDeFondo As New TextureBrush(New Bitmap("C:\LIBRO\CAP_02\GDI+\Ejemplo_3\Ejemplo3\Textura3.jpg"))
                    .TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAlias
                    .FillRectangle(TexturaDeFondo, ClientRectangle)
                    .FillRectangle(New SolidBrush(Color.FromArgb(180, Color.White)), ClientRectangle)
                    .DrawString("GDI+ con textura", MiFuente, BrochaSombra, 15, 55)
                    .DrawString("GDI+ con textura", MiFuente, BrochaPrincipal, 10, 50)
                End With
            Case "Dibujar texto en un �rea"
                With PictureBox1.CreateGraphics
                    'Dibujando Texto dentro de un �rea
                    Dim strTexto As String
                    strTexto = "Texto de prueba que nos permite comprobar " & "como escribir un texto dentro de un �rea de rect�ngulo." & vbCrLf & "Ejemplo desarrollado usando las t�cnicas de GDI+." & ControlChars.CrLf
                    Dim Rectangulo As New RectangleF(20, 20, 200, 160)
                    .TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAlias
                    .FillRectangle(New SolidBrush(Color.White), ClientRectangle)
                    MiFuente = New Font("Verdana", 12)
                    .FillRectangle(New SolidBrush(Color.White), ClientRectangle)
                    .DrawString(strTexto, MiFuente, New SolidBrush(Color.FromArgb(125, Color.Red)), Rectangulo)
                End With
            Case "Dibujar im�genes"
                'Dibujando Im�genes
                With PictureBox1.CreateGraphics
                    .FillRectangle(New SolidBrush(Color.White), ClientRectangle)
                    .FillRectangle(New SolidBrush(Color.White), ClientRectangle)
                    .DrawImage(New Bitmap("C:\LIBRO\CAP_02\GDI+\Ejemplo_3\Ejemplo3\Textura1.jpg"), 10, 140, 100, 100)
                    .DrawString("Pintando texto", New Font("Arial", 12), New SolidBrush(Color.FromArgb(150, Color.Blue)), 120, 140)
                End With
            Case "Dibujar texto girado"
                'Dibujando texto girado
                With PictureBox1.CreateGraphics
                    MiFuente = New Font("Verdana", 24, FontStyle.Bold)
                    .FillRectangle(New SolidBrush(Color.White), ClientRectangle)
                    .RotateTransform(45.0F)
                    .DrawString("Texto con GDI+", MiFuente, New SolidBrush(Color.BlueViolet), 150, -100)
                End With
        End Select
    End Sub
End Class
