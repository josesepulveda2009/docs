Imports System.Math

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(520, 390)
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region


    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim Grafico As Graphics = e.Graphics

        'Dibujando una gr�fica simple
        'cambiando la inclinaci�n de la curva
        Dim Puntos As Point() = {New Point(10, Sin(1) * 100), New Point(60, Sin(0) * 100), New Point(110, Sin(1) * 100), New Point(160, Sin(0) * 100), New Point(210, Sin(1) * 100)}
        Grafico.DrawCurve(New Pen(Color.DarkOrange, 2), Puntos, 0.0F)
        Grafico.DrawCurve(New Pen(Color.Orchid, 2), Puntos, 0.5F)
        Grafico.DrawCurve(New Pen(Color.OrangeRed, 2), Puntos, 1.0F)

        'Dibujando una gr�fica simple cerrada
        Dim Puntos_2 As Point() = {New Point(10, 100), New Point(60, 140), New Point(110, 170), New Point(160, 140), New Point(210, 100)}
        Grafico.DrawClosedCurve(New Pen(Color.DarkOrange, 2), Puntos_2)

        'Dibujando una gr�fica de B�zier
        Dim pi1 As New Point(10, 200)
        Dim pc1 As New Point(110, 270)
        Dim pc2 As New Point(160, 190)
        Dim pf2 As New Point(210, 200)
        Grafico.DrawBezier(New Pen(Color.DarkBlue, 2), pi1, pc1, pc2, pf2)

        'Dibujando un arco (en este caso cerrado) 
        'marcando sus dimensiones en �l
        Dim Camino As New Drawing2D.GraphicsPath()
        Camino.AddArc(40, 50, 30, 30, 0, 360)
        Grafico.DrawPath(New Pen(Color.Blue, 2), Camino)

        'Dibujando una figura no cerrada y
        'rellenando su interior 
        Camino.AddArc(240, 10, 75, 75, 0, 180)
        Grafico.FillPath(New SolidBrush(Color.Red), Camino)
        Grafico.DrawPath(New Pen(Color.DarkRed, 2), Camino)

        'Dibujando una tarta en pantalla
        Grafico.DrawPie(New Pen(Color.Blue), (Me.Width \ 2), (Me.Height \ 2), 100.0F, 100.0F, 0.0F, 45.0F)
        Grafico.FillPie(New SolidBrush(Color.Blue), (Me.Width \ 2), (Me.Height \ 2), 100.0F, 100.0F, 0.0F, 45.0F)
        Grafico.DrawPie(New Pen(Color.Cyan), (Me.Width \ 2), (Me.Height \ 2), 100.0F, 100.0F, 45.0F, 45.0F)
        Grafico.FillPie(New SolidBrush(Color.Cyan), (Me.Width \ 2), (Me.Height \ 2), 100.0F, 100.0F, 45.0F, 45.0F)
        Grafico.DrawPie(New Pen(Color.Red), (Me.Width \ 2), (Me.Height \ 2), 100.0F, 100.0F, 90.0F, 270.0F)
        Grafico.FillPie(New SolidBrush(Color.Red), (Me.Width \ 2), (Me.Height \ 2), 100.0F, 100.0F, 90.0F, 270.0F)
    End Sub

End Class
