Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(16, 24)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Play"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(16, 64)
        Me.Button2.Name = "Button2"
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Stop"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(656, 382)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button2, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    'Declaraci�n de las variables de aplicaci�n
    Dim DX_Ref As New DxVBLib.DirectX7()
    Dim DX_DML As DxVBLib.DirectMusicLoader
    Dim DX_DMP As DxVBLib.DirectMusicPerformance
    Dim DX_DMS As DxVBLib.DirectMusicSegment
    Dim DX_DMSS As DxVBLib.DirectMusicSegmentState

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Inicializaci�n de las variables de aplicaci�n
        DX_DML = DX_Ref.DirectMusicLoaderCreate
        DX_DMP = DX_Ref.DirectMusicPerformanceCreate
        DX_DMP.Init(Nothing, Handle.ToInt32)
        DX_DMP.SetPort(-1, 1)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Bot�n de ejecuci�n del fichero de sonido
        'PLAY
        DX_DMS = DX_DML.LoadSegment(System.Windows.Forms.Application.StartupPath & "\Yerterday.mid")
        DX_DMS.SetStandardMidiFile()
        DX_DMP.SetMasterAutoDownload(True)
        DX_DMS.Download(DX_DMP)
        DX_DMSS = DX_DMP.PlaySegment(DX_DMS, 0, 0)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Bot�n para detener el fichero de sonido
        'STOP
        DX_DMP.Stop(DX_DMS, DX_DMSS, 0, 0)
        DX_DMS.Unload(DX_DMP)
    End Sub
End Class
