Public Class MobileWebForm1
    Inherits System.Web.UI.MobileControls.MobilePage
    Protected WithEvents Label1 As System.Web.UI.MobileControls.Label
    Protected WithEvents SelectionList1 As System.Web.UI.MobileControls.SelectionList
    Protected WithEvents Command1 As System.Web.UI.MobileControls.Command
    Protected WithEvents Label2 As System.Web.UI.MobileControls.Label
    Protected WithEvents Form1 As System.Web.UI.MobileControls.Form

#Region " Web Form Designer Generated Code "
    
    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    
    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub
    
#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            'Inicializamos el control DropDownList con los d�as del mes de Diciembre
            Dim I As Byte
            For I = 1 To 31
                SelectionList1.Items.Add(I)
            Next
        End If
    End Sub

    Private Sub Command1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command1.Click
        'Declaramos el Servicio Web XML
        Dim MiServicioWeb As New localhost.Service1()
        'Llamamos al Servicio Web XML
        Label2.Text = MiServicioWeb.Santoral(12, SelectionList1.Selection.Text)
    End Sub
End Class
