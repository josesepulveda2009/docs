Public Class Santos

    Dim Diciembre() As String = {"I de Adviento", "Santa Aurelia", "San Francisco Javier", "San Juan Damasceno", "Beato Felipe Renaldi", "D�a de la Constituci�n", "San Ambrosio", "II de Adviento", "Santa Eulalia de M�rida", "Santa Eulalia de M�rida", "San D�maso", "Santa Juana Francisca de Chantal", "Santa Luc�a", "San Juan de la Cruz", "III de Adviento", "Santa Albina", "San L�zaro", "Nuestra Se�ora de la Esperanza", "San Dar�o", "Santo Domingo de Silos", "San Pedro Canisio", "IV de Adviento", "San Juan de Ketty", "San Delf�n", "Natividad del Se�or", "San Esteban", "San Juan Evangelista", "Santos Inocentes", "Sagrada Familia", "San Sabino", "San Silvestre"}
    Const strMsgError As String = "-NO DEFINIDO-"

    'Funci�n para determinar el santo de una fecha dada (Mes, Dia)
    Public Function Fechas(ByVal Mes As Byte, ByVal Dia As Byte) As String
        Select Case Mes
            Case 12
                'MES DE DICIEMBRE
                Fechas = Buscar(Mes, Dia)
            Case Else
                'NO SE HA INSERTADO EL MES CORRECTO
                Fechas = strMsgError
        End Select
    End Function

    'Funci�n para Buscar el Santoral de un mes determinado
    Private Function Buscar(ByVal Mes As Byte, ByVal Dia As Byte) As String
        Try
            Buscar = Diciembre(Dia - 1)
        Catch
            Buscar = strMsgError
        End Try
    End Function

End Class
