Imports System.Resources

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(176, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Crear Fichero de Recursos"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(8, 40)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(176, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Acceder al Fichero de Recursos"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 80)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Label2"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 144)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Label3"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Label4"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 208)
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Label5"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label5, Me.Label4, Me.Label3, Me.Label2, Me.Label1, Me.Button2, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Inicializamos los controles Label para dejarlos en blanco
        Label1.Text = ""
        Label2.Text = ""
        Label3.Text = ""
        Label4.Text = ""
        Label5.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Llamamos a la funci�n para crear el fichero de recursos
        Crear_Recursos()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Declaramos el objeto para leer el fichero de recursos
        Dim MiRecurso As ResourceReader
        Try
            MiRecurso = New ResourceReader("MiFichero.resources")
        Catch
            MessageBox.Show("Error en la lectura de los datos del fichero de recursos." & vbCrLf & "Aseg�rese de que el fichero de recursos existe o sino, gen�relo.", "Recursos Din�micos", MessageBoxButtons.OK, MessageBoxIcon.Stop)
            Exit Sub
        End Try
        'Declaramos el diccionario para recorrer las filas del fichero de recursos
        Dim Dicccionario As IDictionaryEnumerator = MiRecurso.GetEnumerator()
        'Recorre el fichero de recursos y recupera el par de valores de cada fila
        While Dicccionario.MoveNext()
            Select Case Dicccionario.Key
                Case "Valor1"
                    Label1.Text = Dicccionario.Value
                Case "Valor2"
                    Label2.Text = Dicccionario.Value
                Case "Valor3"
                    Label3.Text = Dicccionario.Value
                Case "Valor4"
                    Label4.Text = Dicccionario.Value
                Case "Valor5"
                    Label5.Text = Dicccionario.Value
            End Select
        End While
        'Cerramos el objeto
        MiRecurso.Close()
    End Sub

    'Funci�n para crear el fichero de recursos
    Private Function Crear_Recursos()
        'Iniciamos la caracter�stica Randomize
        Randomize()
        'Declaramos la variable y recogemos un valor aleatorio
        Dim bteI As Byte
        bteI = (Rnd() * 100) + 1
        'Declaramos el objeto para escribir el fichero de recursos
        'Dim ResWriter As ResXResourceWriter
        Dim ResWriter As IResourceWriter
        'Indicamos el nombre del fichero de recursos a utilizar
        'ResWriter = New ResXResourceWriter("MiFichero.resources")
        ResWriter = New ResourceWriter("MiFichero.resources")
        'Escribimos las variables y valores del fichero de recursos
        ResWriter.AddResource("Valor1", (bteI * 2).ToString)
        ResWriter.AddResource("Valor2", (bteI * 3).ToString)
        ResWriter.AddResource("Valor3", (bteI * 4).ToString)
        ResWriter.AddResource("Valor4", (bteI * 5).ToString)
        ResWriter.AddResource("Valor5", (bteI * 6).ToString)
        'Cerramos el objeto
        ResWriter.Close()
        'Informamos de que se ha generado el fichero de recursos
        MessageBox.Show("Se ha generado el fichero de recursos satisfactoriamente", "Recursos Din�micos", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Function
End Class
