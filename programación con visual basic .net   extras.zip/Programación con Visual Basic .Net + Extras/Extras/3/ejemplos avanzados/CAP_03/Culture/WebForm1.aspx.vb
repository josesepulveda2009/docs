Imports System.Globalization

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents RadioButtonList1 As System.Web.UI.WebControls.RadioButtonList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            Label1.Text = ""
            With RadioButtonList1
                .Items.Add("Alem�n")
                .Items.Item(0).Value = "0"
                .Items.Item(0).Selected = True
                .Items.Add("Espa�ol")
                .Items.Item(1).Value = "1"
                .Items.Add("Ingl�s")
                .Items.Item(2).Value = "2"
            End With
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Select Case RadioButtonList1.SelectedItem.Value
            Case 0
                Me.UICulture = "de-DE"
            Case 1
                Me.UICulture = "es-ES"
            Case 2
                Me.UICulture = "en-US"
        End Select
        Label1.Text = "<font face='Verdana' color='DarkRed'><b>" & CultureInfo.CurrentUICulture.Name & "</b></font>" & "<font face='Verdana' color='DarkBlue'><b>" & Now & "</b></font>"
    End Sub
End Class
