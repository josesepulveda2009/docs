Imports System.Data
Imports System.Data.SqlClient

Public Class Detalle
    Inherits System.Web.UI.Page
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Image2 As System.Web.UI.WebControls.Image
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim strMarca As String = Request.QueryString("mk")
        Image1.ImageUrl = "Images/bg_" & strMarca & ".jpg"
        Cargar_Datos(strMarca)
    End Sub

    Private Sub Cargar_Datos(ByVal strCodigo As String)
        Dim DS As DataSet
        Dim MyConnection As SqlConnection
        Dim MyCommand As SqlDataAdapter

        MyConnection = New SqlConnection("server=PAPEL\NetSDK;database=PORTAL;Trusted_Connection=yes")
        MyCommand = New SqlDataAdapter("Select * FROM INFORMACION Where Marca_id='" & strCodigo & "'", MyConnection)

        DS = New DataSet()
        MyCommand.Fill(DS, "Informacion")

        'Label1.Text = DS.Tables(0).Rows(0).Item(1)
        Label1.Text = DS.Tables("Informacion").Rows(0).Item(1)
    End Sub
End Class
