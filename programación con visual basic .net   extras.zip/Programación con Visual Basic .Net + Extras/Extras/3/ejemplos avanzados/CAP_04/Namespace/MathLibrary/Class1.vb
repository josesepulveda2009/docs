Namespace LibreriaMatematica
    'Nombre de espacio: LibreriaMatematica

    Public Class OperacionesSimples
        'Clase OperacionesSimples del nombre de espacio declarado

        'Funci�n que resuelve la suma entre dos variables
        Public Shared Function Suma(ByVal X As Long, ByVal Y As Long) As Long
            Return X + Y
        End Function

        'Funci�n que resuelve la resta entre dos variables
        Public Shared Function Resta(ByVal X As Long, ByVal Y As Long) As Long
            Return X - Y
        End Function

        'Funci�n que resuelve la divisi�n entre dos variables
        Public Shared Function Division(ByVal X As Long, ByVal Y As Long) As Long
            Return X / Y
        End Function

        'Funci�n que resuelve el producto entre dos variables
        Public Shared Function Producto(ByVal X As Long, ByVal Y As Long) As Long
            Return X * Y
        End Function
    End Class
End Namespace
