Public Class MiWord
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MnuArchivo As System.Windows.Forms.MenuItem
    Friend WithEvents MnuNuevo As System.Windows.Forms.MenuItem
    Friend WithEvents MnuCerrar As System.Windows.Forms.MenuItem
    Friend WithEvents MnuSalir As System.Windows.Forms.MenuItem
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents MnuVentana As System.Windows.Forms.MenuItem
    Friend WithEvents MnuCascada As System.Windows.Forms.MenuItem
    Friend WithEvents MnuHorizontal As System.Windows.Forms.MenuItem
    Friend WithEvents MnuVertical As System.Windows.Forms.MenuItem
    Friend WithEvents MnuEdicion As System.Windows.Forms.MenuItem
    Friend WithEvents MnuCopiar As System.Windows.Forms.MenuItem
    Friend WithEvents MnuPegar As System.Windows.Forms.MenuItem
    Friend WithEvents MnuDeshacer As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MnuEliminar As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MnuSelTodo As System.Windows.Forms.MenuItem
    Friend WithEvents MnuAbrir As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents MnuAcerca As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.MnuArchivo = New System.Windows.Forms.MenuItem()
        Me.MnuNuevo = New System.Windows.Forms.MenuItem()
        Me.MnuAbrir = New System.Windows.Forms.MenuItem()
        Me.MnuCerrar = New System.Windows.Forms.MenuItem()
        Me.MenuItem4 = New System.Windows.Forms.MenuItem()
        Me.MnuSalir = New System.Windows.Forms.MenuItem()
        Me.MnuEdicion = New System.Windows.Forms.MenuItem()
        Me.MnuDeshacer = New System.Windows.Forms.MenuItem()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MnuCopiar = New System.Windows.Forms.MenuItem()
        Me.MnuPegar = New System.Windows.Forms.MenuItem()
        Me.MnuEliminar = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.MnuSelTodo = New System.Windows.Forms.MenuItem()
        Me.MnuVentana = New System.Windows.Forms.MenuItem()
        Me.MnuCascada = New System.Windows.Forms.MenuItem()
        Me.MnuHorizontal = New System.Windows.Forms.MenuItem()
        Me.MnuVertical = New System.Windows.Forms.MenuItem()
        Me.StatusBar1 = New System.Windows.Forms.StatusBar()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.MnuAcerca = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MnuArchivo, Me.MnuEdicion, Me.MnuVentana, Me.MnuAcerca})
        '
        'MnuArchivo
        '
        Me.MnuArchivo.Index = 0
        Me.MnuArchivo.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MnuNuevo, Me.MnuAbrir, Me.MnuCerrar, Me.MenuItem4, Me.MnuSalir})
        Me.MnuArchivo.Text = "&Archivo"
        '
        'MnuNuevo
        '
        Me.MnuNuevo.Index = 0
        Me.MnuNuevo.Text = "&Nuevo"
        '
        'MnuAbrir
        '
        Me.MnuAbrir.Index = 1
        Me.MnuAbrir.Text = "&Abrir"
        '
        'MnuCerrar
        '
        Me.MnuCerrar.Index = 2
        Me.MnuCerrar.Text = "&Cerrar"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 3
        Me.MenuItem4.Text = "-"
        '
        'MnuSalir
        '
        Me.MnuSalir.Index = 4
        Me.MnuSalir.Text = "&Salir"
        '
        'MnuEdicion
        '
        Me.MnuEdicion.Index = 1
        Me.MnuEdicion.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MnuDeshacer, Me.MenuItem1, Me.MnuCopiar, Me.MnuPegar, Me.MnuEliminar, Me.MenuItem3, Me.MnuSelTodo})
        Me.MnuEdicion.Text = "&Edici�n"
        '
        'MnuDeshacer
        '
        Me.MnuDeshacer.Index = 0
        Me.MnuDeshacer.Text = "&Deshacer"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 1
        Me.MenuItem1.Text = "-"
        '
        'MnuCopiar
        '
        Me.MnuCopiar.Index = 2
        Me.MnuCopiar.Text = "&Copiar"
        '
        'MnuPegar
        '
        Me.MnuPegar.Index = 3
        Me.MnuPegar.Text = "&Pegar"
        '
        'MnuEliminar
        '
        Me.MnuEliminar.Index = 4
        Me.MnuEliminar.Text = "&Eliminar"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 5
        Me.MenuItem3.Text = "-"
        '
        'MnuSelTodo
        '
        Me.MnuSelTodo.Index = 6
        Me.MnuSelTodo.Text = "&Seleccionar todo"
        '
        'MnuVentana
        '
        Me.MnuVentana.Index = 2
        Me.MnuVentana.MdiList = True
        Me.MnuVentana.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MnuCascada, Me.MnuHorizontal, Me.MnuVertical})
        Me.MnuVentana.Text = "&Ventana"
        '
        'MnuCascada
        '
        Me.MnuCascada.Index = 0
        Me.MnuCascada.Text = "&Cascada"
        '
        'MnuHorizontal
        '
        Me.MnuHorizontal.Index = 1
        Me.MnuHorizontal.Text = "&Horizontal"
        '
        'MnuVertical
        '
        Me.MnuVertical.Index = 2
        Me.MnuVertical.Text = "&Vertical"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 224)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(292, 22)
        Me.StatusBar1.TabIndex = 1
        '
        'MnuAcerca
        '
        Me.MnuAcerca.Index = 3
        Me.MnuAcerca.Text = "A&cerca de"
        '
        'MiWord
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 246)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.StatusBar1})
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "MiWord"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub MiWord_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "Mi Editor Word"
    End Sub

    Private Sub MnuNuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuNuevo.Click
        Static intContador As Integer
        Dim Frm As New MiForm()
        Frm.MdiParent = Me
        Frm.Text = "SinNombre" & intContador
        Frm.Show()
        StatusBar1.Text = Frm.Text
        intContador = intContador + 1
    End Sub

    Private Sub MnuCerrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuCerrar.Click
        Dim Frm As MiForm = Me.ActiveMdiChild
        Try
            Frm.Close()
        Catch
            Exit Try
        End Try
    End Sub

    Private Sub MnuCascada_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuCascada.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub MnuHorizontal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuHorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub MnuVertical_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuVertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub MnuDeshacer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuDeshacer.Click
        Dim Frm As MiForm = Me.ActiveMdiChild
        If (Not Frm Is Nothing) Then
            Try
                Dim txtRichTextBox As RichTextBox = CType(Frm.ActiveControl, RichTextBox)
                If (Not txtRichTextBox Is Nothing) Then
                    txtRichTextBox.Undo()
                End If
            Catch
                Exit Try
            End Try
        End If
    End Sub

    Private Sub MnuCopiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuCopiar.Click
        Dim Frm As MiForm = Me.ActiveMdiChild
        If (Not Frm Is Nothing) Then
            Try
                Dim txtRichTextBox As RichTextBox = CType(Frm.ActiveControl, RichTextBox)
                If (Not txtRichTextBox Is Nothing) Then
                    Clipboard.SetDataObject(txtRichTextBox.SelectedText)
                End If
            Catch
                Exit Try
            End Try
        End If
    End Sub

    Private Sub MnuPegar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuPegar.Click
        Dim Frm As MiForm = Me.ActiveMdiChild
        If (Not Frm Is Nothing) Then
            Try
                Dim txtRichTextBox As RichTextBox = CType(Frm.ActiveControl, RichTextBox)
                If (Not txtRichTextBox Is Nothing) Then
                    Dim data As IDataObject = Clipboard.GetDataObject()
                    If (data.GetDataPresent(DataFormats.Text)) Then
                        txtRichTextBox.SelectedText = data.GetData(DataFormats.Text).ToString()
                    End If
                End If
            Catch
                Exit Try
            End Try
        End If
    End Sub

    Private Sub MnuEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuEliminar.Click
        Dim Frm As MiForm = Me.ActiveMdiChild
        If (Not Frm Is Nothing) Then
            Try
                Dim txtRichTextBox As RichTextBox = CType(Frm.ActiveControl, RichTextBox)
                If (Not txtRichTextBox Is Nothing) Then
                    txtRichTextBox.Cut()
                End If
            Catch
                Exit Try
            End Try
        End If
    End Sub

    Private Sub MnuSelTodo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuSelTodo.Click
        Dim Frm As MiForm = Me.ActiveMdiChild
        If (Not Frm Is Nothing) Then
            Try
                Dim txtRichTextBox As RichTextBox = CType(Frm.ActiveControl, RichTextBox)
                If (Not txtRichTextBox Is Nothing) Then
                    txtRichTextBox.SelectAll()
                End If
            Catch
                Exit Try
            End Try
        End If
    End Sub

    Private Sub MnuAbrir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuAbrir.Click
        With OpenFileDialog1
            'Indicamos un directorio inicial (que no es necesario)
            .InitialDirectory = "C:\"
            'Indicamos el tipo de archivos que pueden ser abiertos
            .Filter = "Documentos Rtf (*.rtf)|*.rtf|Ficheros de Texto (*.txt)|*.txt"
            'Indicamos el tipo de fichero a visualizar por defecto (txt)
            .FilterIndex = 2
            'Abrimos el di�logo y comprobamos que se ha abierto un documento
            If .ShowDialog() = DialogResult.OK Then
                'Se ha pulsado OK => Se ha abierto un documento
                Try
                    'Intentamos abrir el documento
                    Dim Frm As New MiForm()
                    Frm.MdiParent = Me
                    Frm.Text = "SinNombre"
                    Select Case .FilterIndex
                        Case 1
                            'Cargamos el fichero Rtf
                            Frm.RichTextBox1.LoadFile(.FileName, RichTextBoxStreamType.RichText)
                        Case 2
                            'Cargamos el fichero Txt
                            Frm.RichTextBox1.LoadFile(.FileName, RichTextBoxStreamType.PlainText)
                    End Select
                    Frm.Text = .FileName
                    Frm.Show()
                Catch Fallo As ArgumentException
                    'Si hay un fallo, mostramos un mensaje de error
                    MessageBox.Show("El documento que est� intentando abrir " & _
                        "no est� en el formato correcto o est� corrupto.", _
                        "Error de apertura", _
                        MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        End With

    End Sub

    Private Sub MDIChildActivated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.MdiChildActivate
        If (Me.ActiveMdiChild Is Nothing) Then
            StatusBar1.Text = ""
        Else
            StatusBar1.Text = Me.ActiveMdiChild.Text
        End If
    End Sub

    'Opci�n del men� para mostrar la informaci�n Acerca De
    Private Sub MnuAcerca_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuAcerca.Click
        Dim Frm As New AcercaDe()
        Frm.ShowDialog(Me)
        Frm.Dispose()
    End Sub

    Private Sub MnuSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuSalir.Click
        Me.Close()
    End Sub
End Class
