Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = -1
        Me.CrystalReportViewer1.DisplayGroupTree = False
        Me.CrystalReportViewer1.DisplayToolbar = False
        Me.CrystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.ReportSource = Nothing
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(448, 329)
        Me.CrystalReportViewer1.TabIndex = 0
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3})
        Me.MenuItem1.Text = "&Archivo"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "&Exportar"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "&Imprimir"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 329)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.CrystalReportViewer1})
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Asignamos el reporte al control de visualizaci�n
        CrystalReportViewer1.ReportSource = "C:\LIBRO\CAP_09\Reports\WindowsApp1\Reporte1.rpt"
    End Sub

    'OPCI�N EXPORTAR
    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        'Declaramos el reporte del informe
        Dim Informe As New Reporte1()
        'Declaramos las opciones en la clase del objeto de reporte
        Dim OpcionesDestino As New CrystalDecisions.Shared.DiskFileDestinationOptions()
        'Indicamos que extraeremos el informe al formato PDF
        Informe.ExportOptions.ExportFormatType = CrystalDecisions.[Shared].ExportFormatType.PortableDocFormat
        'Indicamos que extraeremos el informe en el disco
        Informe.ExportOptions.ExportDestinationType = CrystalDecisions.[Shared].ExportDestinationType.DiskFile
        'Definimos la unidad, el camino y el nombre del archivo a exportar
        OpcionesDestino.DiskFileName = "C:\Informe.pdf"
        'Volcamos las condiciones de opciones de exportaci�n
        Informe.ExportOptions.DestinationOptions = OpcionesDestino
        'Exportamos el informe
        Informe.Export()
        'Mostramos un mensaje en pantalla indicando que se ha exportado el informe
        MessageBox.Show("Informe exportado correctamente.", "Informe", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    'OPCI�N IMPRIMIR
    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        'Declaramos el reporte del informe
        Dim Informe As New Reporte1()
        'Declaramos las opciones de los m�rgenes del reporte
        Dim Margenes As CrystalDecisions.Shared.PageMargins
        'Obtener la estructura PageMargins y establecer los m�rgenes del informe
        Margenes = Informe.PrintOptions.PageMargins
        'Establecemos los m�rgenes en la p�gina
        With Margenes
            .bottomMargin = 200
            .leftMargin = 200
            .rightMargin = 200
            .topMargin = 200
        End With
        'Aplicamos los m�rgenes a la p�gina.
        Informe.PrintOptions.ApplyPageMargins(Margenes)
        'Imprimimos el informe con el par�metro startPageN y endPageN a 0
        Informe.PrintToPrinter(1, False, 0, 0)
        'Mostramos un mensaje en pantalla indicando que se ha impreso el informe
        MessageBox.Show("Informe impreso correctamente.", "Informe", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
