Public Class MiControlPrueba
    Inherits System.Windows.Forms.UserControl

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()
    End Sub

    'UserControl1 reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents VScrollBar1 As System.Windows.Forms.VScrollBar
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.VScrollBar1 = New System.Windows.Forms.VScrollBar()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'VScrollBar1
        '
        Me.VScrollBar1.LargeChange = 1
        Me.VScrollBar1.Location = New System.Drawing.Point(8, 8)
        Me.VScrollBar1.Name = "VScrollBar1"
        Me.VScrollBar1.Size = New System.Drawing.Size(17, 48)
        Me.VScrollBar1.TabIndex = 0
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(32, 8)
        Me.TextBox1.MaxLength = 8
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(56, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = ""
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(32, 40)
        Me.TextBox2.MaxLength = 8
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(56, 20)
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.Text = ""
        '
        'MiControlPrueba
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox2, Me.TextBox1, Me.VScrollBar1})
        Me.Name = "MiControlPrueba"
        Me.Size = New System.Drawing.Size(96, 64)
        Me.ResumeLayout(False)

    End Sub

#End Region

    'Declaramos la variable para almacenar el valor del borde del control
    Private BordeControl As BorderStyle = BorderStyle.None

    Private Sub MiControlPrueba_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Calcular_Valores()
    End Sub

    Private Sub VScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles VScrollBar1.Scroll
        Calcular_Valores()
    End Sub

    Private Sub Calcular_Valores()
        TextBox1.Text = VScrollBar1.Value
        TextBox2.Text = System.Math.Sqrt(VScrollBar1.Value)
    End Sub

    'Al crear la propiedad, generamos una serie de caracter�sticas de la 
    'propiedad que se establecer�n como ayuda al desarrollador
    <System.ComponentModel.Category("Personalizacion"), _
    System.ComponentModel.Description("Establece el borde del control"), _
    System.ComponentModel.DefaultValue(Windows.Forms.BorderStyle.None)> _
    Public Property MiBorde() As Windows.Forms.BorderStyle
        Get
            Return BordeControl
        End Get
        Set(ByVal Value As Windows.Forms.BorderStyle)
            BordeControl = Value
            'Forzamos que el control se vuelva a generar (redibujar)
            'nuevamente para establecer los valores adecuadamente
            Me.RecreateHandle()
        End Set
    End Property

    'Ocultaremos la propiedad en la ventana de propiedades 
    'El valor False establece que no aparezca en la ventana de propiedades
    'El valor True establece que aparezca en la ventana de propiedades, pero
    'en modo de s�lo lectura
    <System.ComponentModel.Browsable(False)> _
    Public Shadows ReadOnly Property AutoScroll() As Boolean
        Get
        End Get
    End Property

    'Creamos los par�metros nuevamente, recuperando los valores modificados
    'y redibujando de esta manera, el control correctamente
    Protected Overrides ReadOnly Property CreateParams() As CreateParams
        Get
            Dim Parametros As CreateParams = MyBase.CreateParams
            Select Case BordeControl
                Case BorderStyle.FixedSingle
                    Parametros.Style = Parametros.Style Or &H800000
                Case BorderStyle.Fixed3D
                    Parametros.ExStyle = Parametros.ExStyle Or &H20000
            End Select
            Return Parametros
        End Get
    End Property

    'A�adiendo m�todo de ir al principio
    Public Sub Inicio()
        VScrollBar1.Value = 0
        Calcular_Valores()
    End Sub

    'A�adiendo m�todo de ir al final
    Public Sub Fin()
        VScrollBar1.Value = 100
        Calcular_Valores()
    End Sub

    'A�adiendo m�todo de ir al medio
    Public Sub Medio()
        VScrollBar1.Value = 50
        Calcular_Valores()
    End Sub

    'A�adiendo m�todo de ir a un valor dado "goto"
    Public Sub ValorPropio(ByVal Valor As Byte)
        VScrollBar1.Value = Valor
        Calcular_Valores()
    End Sub

    'Declaramos un evento p�blico (para ser accedido desde nuestro control)
    Public Event MiEvento As EventHandler

    Public Sub OnMiEvento(ByVal e As System.EventArgs, ByVal MiValor As Byte)
        VScrollBar1.Value = MiValor
        Calcular_Valores()
        MessageBox.Show("Evento lanzado")
        RaiseEvent MiEvento(Me, e)
        'En muchas ocasiones no debemos lanzar Invalidate como ahora
        'pero lo indicamos aqu� para que veamos cuando deber�a ser
        'lanzado o en que posici�n debe ser llamado
        'Invalidate()
    End Sub

End Class
