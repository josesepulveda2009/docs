Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents MiControlPrueba1 As ControlPrueba.MiControlPrueba
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MiControlPrueba1 = New ControlPrueba.MiControlPrueba()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MiControlPrueba1
        '
        Me.MiControlPrueba1.Location = New System.Drawing.Point(8, 8)
        Me.MiControlPrueba1.MiBorde = System.Windows.Forms.BorderStyle.None
        Me.MiControlPrueba1.Name = "MiControlPrueba1"
        Me.MiControlPrueba1.Size = New System.Drawing.Size(96, 64)
        Me.MiControlPrueba1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Ejecutar"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1, Me.RadioButton4, Me.RadioButton3, Me.RadioButton2, Me.RadioButton1, Me.Button1})
        Me.GroupBox1.Location = New System.Drawing.Point(8, 128)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 128)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(112, 88)
        Me.TextBox1.MaxLength = 3
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(40, 20)
        Me.TextBox1.TabIndex = 6
        Me.TextBox1.Text = ""
        '
        'RadioButton4
        '
        Me.RadioButton4.Location = New System.Drawing.Point(160, 88)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.TabIndex = 5
        Me.RadioButton4.Text = "Valor Propio"
        '
        'RadioButton3
        '
        Me.RadioButton3.Location = New System.Drawing.Point(160, 64)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.TabIndex = 4
        Me.RadioButton3.Text = "Mitad"
        '
        'RadioButton2
        '
        Me.RadioButton2.Location = New System.Drawing.Point(160, 40)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.TabIndex = 3
        Me.RadioButton2.Text = "Fin"
        '
        'RadioButton1
        '
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(160, 16)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.TabIndex = 2
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Inicio"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.MiControlPrueba1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If RadioButton1.Checked = True Then
            MiControlPrueba1.Inicio()
        ElseIf RadioButton2.Checked = True Then
            MiControlPrueba1.Fin()
        ElseIf RadioButton3.Checked = True Then
            MiControlPrueba1.Medio()
        Else
            If TextBox1.Text > 100 Then TextBox1.Text = 100
            If TextBox1.Text < 0 Then TextBox1.Text = 0
            MiControlPrueba1.ValorPropio(TextBox1.Text)
        End If
        MiControlPrueba1.OnMiEvento(e, 45)
    End Sub
End Class
