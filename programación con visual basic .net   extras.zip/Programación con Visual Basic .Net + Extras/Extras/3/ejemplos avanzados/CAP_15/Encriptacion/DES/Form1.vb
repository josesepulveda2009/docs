Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(104, 32)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Encriptar"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(8, 56)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(104, 32)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Desencriptar"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(8, 128)
        Me.TextBox2.MaxLength = 8
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 104)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "CLAVE"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(128, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "TEXTO"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(128, 32)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(152, 120)
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.Text = ""
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.RadioButton2, Me.RadioButton1})
        Me.GroupBox1.Location = New System.Drawing.Point(8, 160)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(112, 100)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(16, 24)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "UTF7"
        '
        'RadioButton2
        '
        Me.RadioButton2.Checked = True
        Me.RadioButton2.Location = New System.Drawing.Point(16, 56)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "UTF8"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.TextBox1, Me.Label2, Me.Label1, Me.TextBox2, Me.Button2, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    'Utilizamos un par de claves privadas
    Private Clave_Privada() As Byte = {&H0, &H1, &H12, &H23, &H34, &H45, &HAA, &HAB}
    Private Clave_DES() As Byte = {}


    'Bot�n que llama a la funci�n de encriptar
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If RadioButton1.Checked = True Then
            'UTF7
            TextBox1.Text = Enc_A_Base64(TextBox1.Text, TextBox2.Text, 0)
        Else
            'UTF8
            TextBox1.Text = Enc_A_Base64(TextBox1.Text, TextBox2.Text, 1)
        End If
    End Sub


    'Bot�n que llama a la funci�n de desencriptar
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If RadioButton1.Checked = True Then
            'UTF7
            TextBox1.Text = Desenc_Desde_Base64(TextBox1.Text, TextBox2.Text, 0)
        Else
            'UTF8
            TextBox1.Text = Desenc_Desde_Base64(TextBox1.Text, TextBox2.Text, 1)
        End If
    End Sub


    'Funci�n de encriptaci�n de datos
    Private Function Enc_A_Base64(ByVal stringToEncrypt As String, ByVal SEncryptionKey As String, ByVal bteValor As Byte) As String
        Dim bteArrEntrada() As Byte
        Try
            If bteValor = 0 Then
                'UTF7
                Clave_DES = System.Text.Encoding.UTF7.GetBytes(SEncryptionKey)
                'Convertimos la cadena a un array de bytes
                bteArrEntrada = Encoding.UTF7.GetBytes(stringToEncrypt)
            Else
                'UTF8
                Clave_DES = System.Text.Encoding.UTF8.GetBytes(SEncryptionKey)
                'Convertimos la cadena a un array de bytes
                bteArrEntrada = Encoding.UTF8.GetBytes(stringToEncrypt)
            End If
            Dim DES As New DESCryptoServiceProvider()
            'Comenzamos con la encriptaci�n del Array
            'Perteneciente al nombre de espacio System.IO
            Dim IO_MS As New MemoryStream()
            'Perteneciente al nombre de espacio System.Security.Cryptography
            Dim Cryp_CS As New CryptoStream(IO_MS, DES.CreateEncryptor(Clave_DES, Clave_Privada), CryptoStreamMode.Write)
            Cryp_CS.Write(bteArrEntrada, 0, bteArrEntrada.Length)
            Cryp_CS.FlushFinalBlock()
            'Devolvemos el array convertido a cadena encriptada
            Enc_A_Base64 = Convert.ToBase64String(IO_MS.ToArray())
        Catch e As Exception
            'Devolvemos la excepci�n ocurrida si sucede
            Enc_A_Base64 = e.Message
        End Try
    End Function


    'Funci�n de desencriptaci�n de datos
    Private Function Desenc_Desde_Base64(ByVal stringToDecrypt As String, ByVal sEncryptionKey As String, ByVal bteValor As Byte) As String
        Dim bteArrEntrada(stringToDecrypt.Length) As Byte
        'Decodificamos a una cadena de texto encriptada unencoded, ya que tenemos la cadena de texto en Base64
        bteArrEntrada = Convert.FromBase64String(stringToDecrypt)
        Dim Codificado As Encoding

        Try
            If bteValor = 0 Then
                'UTF7
                Clave_DES = System.Text.Encoding.UTF7.GetBytes(sEncryptionKey)
                Codificado = System.Text.Encoding.UTF7
            Else
                'UTF8
                Clave_DES = System.Text.Encoding.UTF8.GetBytes(sEncryptionKey)
                Codificado = System.Text.Encoding.UTF8
            End If
            Dim DES As New DESCryptoServiceProvider()
            'Comenzamos con la desencriptaci�n del Array
            'Perteneciente al nombre de espacio System.IO
            Dim IO_MS As New MemoryStream()
            'Perteneciente al nombre de espacio System.Security.Cryptography
            Dim Cryp_CS As New CryptoStream(IO_MS, DES.CreateDecryptor(Clave_DES, Clave_Privada), CryptoStreamMode.Write)
            Cryp_CS.Write(bteArrEntrada, 0, bteArrEntrada.Length)
            Cryp_CS.FlushFinalBlock()
            'Devolvemos el array convertido a cadena desencriptada
            Desenc_Desde_Base64 = Codificado.GetString(IO_MS.ToArray())
        Catch e As Exception
            'Devolvemos la excepci�n ocurrida si sucede
            Desenc_Desde_Base64 = e.Message
        End Try
    End Function
End Class
