Imports System.IO
Imports System.Security.Cryptography
Imports System.Text.Encoding

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(128, 24)
        Me.TextBox1.MaxLength = 12
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 24)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Encriptar"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(216, 23)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.Button1, Me.TextBox1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Button1.Text = "Encriptar" Then
            EncBase64(TextBox1.Text)
        ElseIf Button1.Text = "Desencriptar" Then
            DesencBase64(Label1.Text)
        End If
    End Sub

    'Funci�n para encriptar una cadena en Base64
    Private Function EncBase64(ByVal strTexto As String)
        'Nos aseguramos de poner el control Label sin texto
        'Una forma de inicializar los contenidos de las variables
        Label1.Text = ""
        'Perteneciente al nombre de espacio System.Text.Encoding
        'Tambi�n ser�a v�lida la declaraci�n:
        'Dim arrBteEntrada() As Byte = System.Text.Encoding.ASCII.GetBytes(strTexto)
        'Si queremos utilizar el nombre de espacio directamente sin 
        'importarlo a la aplicaci�n
        Dim arrBteEntrada() As Byte = ASCII.GetBytes(strTexto)
        'Perteneciente al nombre de espacio System.IO
        Dim IO_MS As New MemoryStream()
        'Perteneciente al nombre de espacio System.Security.Cryptography
        Dim Cryp_B64T As New ToBase64Transform()
        'Perteneciente al nombre de espacio System.Security.Cryptography
        Dim Cryp_CS As New CryptoStream(IO_MS, Cryp_B64T, CryptoStreamMode.Write)
        Cryp_CS.Write(arrBteEntrada, 0, arrBteEntrada.Length)
        Cryp_CS.FlushFinalBlock()
        Dim arrBteSalida() As Byte = IO_MS.GetBuffer()
        'Perteneciente al nombre de espacio System.Text.Encoding
        'Extraemos los datos encriptados en Base64
        Label1.Text = ASCII.GetString(arrBteSalida, 0, arrBteSalida.Length)
        Button1.Text = "Desencriptar"
    End Function

    'Funci�n para desencriptar una cadena en Base64
    Private Function DesencBase64(ByVal strTexto As String)
        'Nos aseguramos de inicializar los contenidos de los controles
        TextBox1.Text = Label1.Text
        Label1.Text = ""
        'Perteneciente al nombre de espacio System.Text.Encoding
        'Tambi�n ser�a v�lida la declaraci�n:
        'Dim arrBteEntrada() As Byte = System.Text.Encoding.ASCII.GetBytes(strTexto)
        'Si queremos utilizar el nombre de espacio directamente sin 
        'importarlo a la aplicaci�n
        Dim arrBteEntrada() As Byte = ASCII.GetBytes(strTexto)
        'Perteneciente al nombre de espacio System.IO
        Dim IO_MS As New MemoryStream()
        'Perteneciente al nombre de espacio System.Security.Cryptography
        Dim Cryp_B64T As New FromBase64Transform(FromBase64TransformMode.IgnoreWhiteSpaces)
        'Perteneciente al nombre de espacio System.Security.Cryptography
        Dim Cryp_CS As New CryptoStream(IO_MS, Cryp_B64T, CryptoStreamMode.Write)
        Cryp_CS.Write(arrBteEntrada, 0, arrBteEntrada.Length)
        Cryp_CS.FlushFinalBlock()
        Dim arrBteSalida() As Byte = IO_MS.GetBuffer()
        'Perteneciente al nombre de espacio System.Text.Encoding
        'Extraemos los datos encriptados en Base64
        Label1.Text = ASCII.GetString(arrBteSalida, 0, arrBteSalida.Length)
        Button1.Text = "Encriptar"
    End Function
End Class
