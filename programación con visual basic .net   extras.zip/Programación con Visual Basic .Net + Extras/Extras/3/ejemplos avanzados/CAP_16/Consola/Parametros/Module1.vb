Module Module1

    Sub Main()
        If Environment.GetCommandLineArgs.Length > 1 Then
            Console.WriteLine("S�lo se toma en cuenta el primer par�metro")
            Console.WriteLine("El par�metro es: {0}", Environment.GetCommandLineArgs(1))
        Else
            Console.WriteLine("No hay par�metros.")
            Console.WriteLine("El primer par�metro es el ejecutable: {0}", Environment.GetCommandLineArgs(0))
        End If
    End Sub

End Module
