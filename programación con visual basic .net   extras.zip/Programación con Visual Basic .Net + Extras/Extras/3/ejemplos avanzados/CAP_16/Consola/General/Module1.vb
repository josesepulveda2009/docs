Module Module1

    'Creamos la estructura para utilizarla en nuestra aplicaci�n
    Private Structure Apuestas
        Public Ap1 As Byte
        Public Ap2 As Byte
        Public Ap3 As Byte
        Public Ap4 As Byte
        Public Ap5 As Byte

        Public Sub New(ByVal Numero1 As Byte, ByVal Numero2 As Byte, ByVal Numero3 As Byte, ByVal Numero4 As Byte, ByVal Numero5 As Byte)
            Ap1 = Numero1
            Ap2 = Numero2
            Ap3 = Numero3
            Ap4 = Numero4
            Ap5 = Numero5
        End Sub

        Public Sub Mostrar_Apuestas()
            Console.WriteLine("{0}, {1}, {2}, {3}, {4}", Ap1, Ap2, Ap3, Ap4, Ap5)
        End Sub
    End Structure

    'Estructura principal que se ejecuta al principio
    Sub Main()
        Dim Opcion As Byte
        Dim Apuesta As Byte
        Dim Valor As Byte

        'Variable para almacenar las partidas jugadas
        'M�ximo: 5 partidas por ejecuci�n de la aplicaci�n
        Dim Partidas As Byte = 0
        'Inicializamos la funci�n random
        Randomize()

        'Inicializamos el array de datos que determinar�n las respuestas
        'err�neas y respuestas acertadas, de manera tal, que las 
        'respuestas correctas tendr�n un 1 y las err�neas un 0
        Dim MiArr(5) As Byte

        'Declaramos las variables booleanas para determinar la
        'ejecuci�n de la aplicaci�n o la finalizaci�n de �sta
        Dim boolValor As Boolean = False
        Dim boolJuego As Boolean = False

        'Establecemos el bucle dentro del cu�l, ejecutaremos
        'el c�digo de nuestra aplicaci�n
        Do While boolValor = False And Partidas < 5
            'Llamamos a la funci�n del Menu de Opciones
            Menu_Opciones()
            Try
                Opcion = Console.ReadLine
                If Opcion = 1 Then
                    Partidas = Partidas + 1
                    boolJuego = False
                    Valor = (Rnd() * 10) + 1
                    Do While boolJuego = False
                        'Jugar
                        Menu_Juego()
                        Try
                            Apuesta = Console.ReadLine
                            If Apuesta = Valor Then
                                Console.WriteLine("Ha ganado")
                                Console.WriteLine()
                                MiArr(Partidas - 1) = 1
                            Else
                                Console.WriteLine("Ha perdido")
                                Console.WriteLine()
                                MiArr(Partidas - 1) = 0
                            End If
                            boolJuego = True
                        Catch
                            Console.WriteLine("Error en la ejecuci�n de la aplicaci�n")
                        End Try
                    Loop
                Else
                    'Salir
                    boolValor = True
                End If
            Catch
                Console.WriteLine("Error en la ejecuci�n de la aplicaci�n")
            End Try
        Loop
        'Mostramos estad�sticas
        Console.WriteLine("Partidas {0}", Partidas)
        Dim Estadistica As Apuestas = New Apuestas(MiArr(0), MiArr(1), MiArr(2), MiArr(3), MiArr(4)) 'Apuestas(0, 0, 0, 0, 0)
        Estadistica.Mostrar_Apuestas()
    End Sub

    Private Sub Menu_Opciones()
        'Menu de Opciones
        Console.WriteLine("Seleccione una de las opciones del men�:")
        Console.WriteLine("1 - Jugar")
        Console.WriteLine("2 - Salir")
        Console.WriteLine(".........")
        Console.WriteLine()
    End Sub

    Private Sub Menu_Juego()
        'Menu del Juego
        Console.WriteLine("Elija un n�mero del 0 al 9, yo ya he pensado en el m�o:")
        Console.WriteLine(".........")
        Console.WriteLine()
    End Sub
End Module
