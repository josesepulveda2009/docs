Public Class Matematicas
    Inherits ComponentModel.Component

    'Funci�n del componente que nos devuelve la suma de dos n�meros
    Public Function Suma(ByVal Valor1 As Integer, ByVal Valor2 As Integer) As Integer
        Suma = Valor1 + Valor2
    End Function

    'Funci�n del componente que nos devuelve el producto de dos n�meros
    Public Function Producto(ByVal Valor1 As Integer, ByVal Valor2 As Integer) As Integer
        Producto = Valor1 * Valor2
    End Function

End Class
