Public Class Calculo
    Inherits ComponentModel.Component

    Private Numero1 As Integer = 0
    Private Numero2 As Integer = 0
    Private Cantidad_Total As Integer = 0

    'Propiedad p�blica y por tanto visible 
    'en la ventana de Propiedades
    Public Property Valor1() As Integer
        Get
            Return Numero1
        End Get
        Set(ByVal Value As Integer)
            Numero1 = Value
            Cantidad_Total = Numero1 + Numero2
        End Set
    End Property

    'Propiedad p�blica y por tanto visible 
    'en la ventana de Propiedades
    Public Property Valor2() As Integer
        Get
            Return Numero2
        End Get
        Set(ByVal Value As Integer)
            Numero2 = Value
            Cantidad_Total = Numero1 + Numero2
        End Set
    End Property

    'Propiedad p�blica y por tanto visible 
    'en la ventana de Propiedades
    'Es una propiedad de SOLO LECTURA
    Public ReadOnly Property Resultado() As Integer
        Get
            Return Cantidad_Total
        End Get
    End Property
End Class
