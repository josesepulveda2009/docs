Imports System.ServiceProcess
Imports System.IO

Public Class Service1
    Inherits System.ServiceProcess.ServiceBase

#Region " C�digo generado por el Dise�ador de componentes "

    Public Sub New()
        MyBase.New()

        ' El Dise�ador de componentes requiere esta llamada.
        InitializeComponent()

        ' Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'UserService reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ' El punto de entrada principal para el proceso
    <MTAThread()> _
    Shared Sub Main()
        Dim ServicesToRun() As System.ServiceProcess.ServiceBase

        ' Se puede ejecutar en el mismo proceso m�s de un servicio NT. Para agregar
        ' otro servicio a este proceso, cambie la siguiente l�nea a fin de
        ' crear otro objeto de servicio. Por ejemplo,
        '
        '   ServicesToRun = New System.ServiceProcess.ServiceBase () {New Service1, New MySecondUserService}
        '
        ServicesToRun = New System.ServiceProcess.ServiceBase() {New Service1()}

        System.ServiceProcess.ServiceBase.Run(ServicesToRun)
    End Sub

    'Requerido por el Dise�ador de componentes
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de componentes requiere el siguiente procedimiento
    'Se puede modificar utilizando el Dise�ador de componentes. No lo modifique
    ' con el editor de c�digo.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 10000
        '
        'Service1
        '
        Me.ServiceName = "Service1"

    End Sub

#End Region

    Private strMiFichero As String = "C:\MiFichero.txt"

    'Evento lanzado en el comienzo del Servicio Windows
    Protected Overrides Sub OnStart(ByVal args() As String)
        ' Agregar c�digo aqu� para iniciar el servicio. Este m�todo deber�a poner en movimiento
        ' los elementos para que el servicio pueda funcionar.
        Timer1.Enabled = False
        Escribir_Log("Proceso inicia a: ")
        Timer1.Enabled = True
    End Sub

    'Evento lanzado en la parada del Servicio Windows
    Protected Overrides Sub OnStop()
        ' Agregar c�digo aqu� para realizar cualquier anulaci�n necesaria para detener el servicio.
        Timer1.Enabled = False
        Escribir_Log("Proceso detenido a: ")
    End Sub

    'Evento lanzado en el reestablecimiento del Servicio Windows
    Protected Overrides Sub OnContinue()
        Escribir_Log("Proceso reestablecido a: ")
        Timer1.Enabled = True
    End Sub

    'Evento lanzado en la pausa del Servicio Windows
    Protected Overrides Sub OnPause()
        Timer1.Enabled = False
        Escribir_Log("Proceso en pausa a: ")
    End Sub

    'M�todo para escribir el Log
    Private Sub Escribir_Log(ByVal strTexto As String)
        Dim Fichero As TextWriter = New StreamWriter(strMiFichero, True)
        Fichero.WriteLine(strTexto & Now)
        Fichero.Close()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Escribir_Log("Evento Timer a: ")
    End Sub
End Class
