Imports System.Data
Imports System.Data.SqlClient

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.TabPage1, Me.TabPage3, Me.TabPage2, Me.TabPage4})
        Me.TabControl1.HotTrack = True
        Me.TabControl1.Location = New System.Drawing.Point(8, 40)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(432, 312)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button1, Me.DataGrid1, Me.Label3, Me.ComboBox2, Me.GroupBox1, Me.Label2, Me.ComboBox1})
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(424, 286)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "B�squeda"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Bitmap)
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(296, 88)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(112, 40)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "BUSCAR"
        '
        'DataGrid1
        '
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 136)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(408, 144)
        Me.DataGrid1.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label3.Location = New System.Drawing.Point(8, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(152, 23)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Campo:"
        '
        'ComboBox2
        '
        Me.ComboBox2.Location = New System.Drawing.Point(8, 104)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(160, 21)
        Me.ComboBox2.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(8, 64)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(408, 5)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(152, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tabla:"
        '
        'ComboBox1
        '
        Me.ComboBox1.Location = New System.Drawing.Point(8, 32)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(160, 21)
        Me.ComboBox1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.AddRange(New System.Windows.Forms.Control() {Me.ComboBox5, Me.ComboBox4, Me.Button2, Me.TextBox4, Me.TextBox3, Me.TextBox2, Me.TextBox1, Me.Label8, Me.Label7, Me.Label6, Me.Label5, Me.GroupBox2, Me.ComboBox3, Me.Label4})
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(424, 286)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "A�adir"
        '
        'ComboBox5
        '
        Me.ComboBox5.Location = New System.Drawing.Point(120, 136)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(168, 21)
        Me.ComboBox5.TabIndex = 15
        Me.ComboBox5.Visible = False
        '
        'ComboBox4
        '
        Me.ComboBox4.Location = New System.Drawing.Point(120, 96)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(168, 21)
        Me.ComboBox4.TabIndex = 14
        Me.ComboBox4.Visible = False
        '
        'Button2
        '
        Me.Button2.Enabled = False
        Me.Button2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Bitmap)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(296, 88)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 40)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "A�ADIR"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(120, 200)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(168, 20)
        Me.TextBox4.TabIndex = 12
        Me.TextBox4.Text = ""
        Me.TextBox4.Visible = False
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(120, 168)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(168, 20)
        Me.TextBox3.TabIndex = 11
        Me.TextBox3.Text = ""
        Me.TextBox3.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(120, 136)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(168, 20)
        Me.TextBox2.TabIndex = 10
        Me.TextBox2.Text = ""
        Me.TextBox2.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(120, 96)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(168, 20)
        Me.TextBox1.TabIndex = 9
        Me.TextBox1.Text = ""
        Me.TextBox1.Visible = False
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(8, 200)
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Label8"
        Me.Label8.Visible = False
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(8, 168)
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Label7"
        Me.Label7.Visible = False
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(8, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Label6"
        Me.Label6.Visible = False
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 96)
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Label5"
        Me.Label5.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(8, 64)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(408, 5)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        '
        'ComboBox3
        '
        Me.ComboBox3.Items.AddRange(New Object() {"Alumnos", "Clases", "Especialistas"})
        Me.ComboBox3.Location = New System.Drawing.Point(8, 32)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(160, 21)
        Me.ComboBox3.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label4.Location = New System.Drawing.Point(8, 8)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(152, 23)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Tabla:"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox7, Me.TextBox6, Me.TextBox5, Me.Label13, Me.Label12, Me.Label11, Me.ComboBox7, Me.Label10, Me.Button3, Me.GroupBox3, Me.ComboBox6, Me.Label9})
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(424, 286)
        Me.TabPage3.TabIndex = 3
        Me.TabPage3.Text = "Eliminar"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(120, 200)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(168, 20)
        Me.TextBox7.TabIndex = 22
        Me.TextBox7.Text = ""
        Me.TextBox7.Visible = False
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(120, 168)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(168, 20)
        Me.TextBox6.TabIndex = 21
        Me.TextBox6.Text = ""
        Me.TextBox6.Visible = False
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(120, 133)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(168, 20)
        Me.TextBox5.TabIndex = 20
        Me.TextBox5.Text = ""
        Me.TextBox5.Visible = False
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(8, 200)
        Me.Label13.Name = "Label13"
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "Label13"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(8, 168)
        Me.Label12.Name = "Label12"
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Label12"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(8, 136)
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "Label11"
        '
        'ComboBox7
        '
        Me.ComboBox7.Location = New System.Drawing.Point(120, 96)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(168, 21)
        Me.ComboBox7.TabIndex = 16
        '
        'Label10
        '
        Me.Label10.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label10.Location = New System.Drawing.Point(8, 96)
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "Label10"
        '
        'Button3
        '
        Me.Button3.Enabled = False
        Me.Button3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Bitmap)
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Location = New System.Drawing.Point(296, 88)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(112, 40)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "  ELIMINAR"
        '
        'GroupBox3
        '
        Me.GroupBox3.Location = New System.Drawing.Point(8, 64)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(408, 5)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        '
        'ComboBox6
        '
        Me.ComboBox6.Items.AddRange(New Object() {"Alumnos", "Clases", "Especialistas"})
        Me.ComboBox6.Location = New System.Drawing.Point(8, 32)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(160, 21)
        Me.ComboBox6.TabIndex = 6
        '
        'Label9
        '
        Me.Label9.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label9.Location = New System.Drawing.Point(8, 8)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(152, 23)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Tabla:"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label14, Me.PictureBox1})
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(424, 286)
        Me.TabPage4.TabIndex = 2
        Me.TabPage4.Text = "Acerca de..."
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Bitmap)
        Me.PictureBox1.Location = New System.Drawing.Point(8, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.MidnightBlue
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.LightBlue
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(448, 32)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "GUARDERIA"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.ForeColor = System.Drawing.Color.Maroon
        Me.Label14.Location = New System.Drawing.Point(216, 32)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(200, 192)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Label14"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 366)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.TabControl1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

#Region "Form1_Load"
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'SELECCI�N DE DATOS
        'ComboBox1
        With ComboBox1
            .Items.Add("Alumnos")
            .Items.Add("Clases")
            .Items.Add("Especialistas")
            .SelectedText = "Alumnos"
        End With
        'ComboBox2
        Seleccion_Campos("Alumnos")
        'A�ADIR DATOS
        'ComboBox3
        'Asignamos el primer valor del control ComboBox3
        'En la propiedad Items hemos a�adido el conjunto
        'de valores a mostrar en nuestro control
        With ComboBox3
            Dim btePosicion As Integer
            btePosicion = .FindString("Alumnos")
            .SelectedIndex = btePosicion
        End With
        'ELIMINAR DATOS
        'ComboBox6
        'Asignamos el primer valor del control ComboBox6
        'En la propiedad Items hemos a�adido el conjunto
        'de valores a mostrar en nuestro control
        With ComboBox6
            Dim btePosicion As Integer
            btePosicion = .FindString("Alumnos")
            .SelectedIndex = btePosicion
        End With
        'ACERCA DE...
        Label14.Text = "Aplicaci�n para el libro:" & vbCrLf & vbCrLf & _
        "Programaci�n Avanzada con Visual Basic .NET" & _
        "escrito para la editorial Anaya Multimedia."
    End Sub
#End Region

#Region "Selecci�n de datos"
    'Selecci�n de la opci�n del ComboBox1
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        'Seleccionamos los datos del ComboBox2 dependiendo
        'de la selecci�n que hagamos en el ComboBox1
        Seleccion_Campos(ComboBox1.SelectedItem)
    End Sub

    'Bot�n para buscar los datos
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Alamacenaremos en esta variable la sentencia Select
        Dim strConsulta As String
        'Preparamos la sentencia Select
        strConsulta = " From " & ComboBox1.Text
        If ComboBox2.Text = "Todos (*)" Then
            strConsulta = "Select *" & strConsulta
        Else
            strConsulta = "Select " & ComboBox2.Text & strConsulta
        End If
        Buscar_Datos(strConsulta)
    End Sub

    'Funci�n para seleccionar los campos de la Tabla elegida
    Private Function Seleccion_Campos(ByVal strTabla As String)
        With ComboBox2
            .Text = ""
            .Items.Clear()
            Select Case strTabla
                Case "Alumnos"
                    .Items.Add("Todos (*)")
                    .Items.Add("Cod_Clase_FK")
                    .Items.Add("Cod_Alumno")
                    .Items.Add("Nombre")
                    .Items.Add("F_Nac")
                Case "Clases"
                    .Items.Add("Todos (*)")
                    .Items.Add("Cod_Clase")
                    .Items.Add("Cod_Prof")
                    .Items.Add("Tlf")
                Case "Especialistas"
                    .Items.Add("Todos (*)")
                    .Items.Add("Cod_Prof_FK")
                    .Items.Add("Nombre")
            End Select
            .SelectedText = "Todos (*)"
        End With
    End Function

    'Funci�n para buscar los datos
    Private Function Buscar_Datos(ByVal strSQL As String)
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objDataAdapter As SqlDataAdapter
        Dim objDataSet As System.Data.DataSet
        Dim objRow As DataRow
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Guarderia")
        'Establecemos la sentencia de selecci�n
        objDataAdapter = New SqlDataAdapter(strSQL, objConexion)
        'Creamos el nuevo repositorio d�nde almacenaremos los datos
        objDataSet = New System.Data.DataSet()
        'Rellenamos el repositorio
        objDataAdapter.Fill(objDataSet, "Ejemplo")
        'Volcamos en el control DataGrid el contenido del repositorio
        DataGrid1.DataSource = objDataSet
        DataGrid1.Expand(-1)
    End Function
#End Region

#Region "A�adir datos"
    'Selecci�n de la opci�n del ComboBox3
    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        'Seleccionamos las cajas de texto a a�adir
        'de la aplicaci�n
        Add_Campos(ComboBox3.SelectedItem)
        Button2.Enabled = True
    End Sub

    'Funci�n para seleccionar los campos de la Tabla elegida
    Private Function Add_Campos(ByVal strTabla As String)
        Select Case strTabla
            Case "Alumnos"
                Label5.Text = "C�d. Clase:"
                Label6.Text = "C�d. Alumno:"
                Label7.Text = "Nombre:"
                Label8.Text = "Fecha Nacimiento:"
                Label7.Visible = True : Label8.Visible = True
                ComboBox4.Visible = True : TextBox1.Visible = False
                ComboBox5.Visible = False : TextBox2.Visible = True
                TextBox3.Visible = True : TextBox4.Visible = True
                Cargar_Codigos(0)
            Case "Clases"
                Label5.Text = "C�d. Clase:"
                Label6.Text = "C�d. Profesor:"
                Label7.Text = "Tel�fono:"
                Label7.Visible = True : Label8.Visible = False
                TextBox1.Visible = True : ComboBox5.Visible = True : TextBox3.Visible = True
                TextBox2.Visible = False : TextBox4.Visible = False : ComboBox4.Visible = False
                Cargar_Codigos(1)
            Case "Especialistas"
                Label5.Text = "C�d. Profesor:"
                Label6.Text = "Nombre:"
                Label7.Visible = False : Label8.Visible = False
                TextBox1.Visible = True : TextBox2.Visible = True
                ComboBox5.Visible = False : TextBox3.Visible = False
                TextBox4.Visible = False : ComboBox4.Visible = False
        End Select
        Label5.Visible = True : Label6.Visible = True
    End Function

    'Funci�n para cargar los c�digos de clase
    Private Function Cargar_Codigos(ByVal bteAccion As Byte)
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objDataAdapter As SqlDataAdapter
        Dim objDataSet As DataSet
        Dim objRow As DataRow
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Guarderia")
        'Establecemos la sentencia de selecci�n
        If bteAccion = 0 Then
            objDataAdapter = New SqlDataAdapter("SELECT DISTINCT Cod_Clase From Clases", objConexion)
        Else
            objDataAdapter = New SqlDataAdapter("SELECT DISTINCT Cod_Prof_FK From Especialistas", objConexion)
        End If
        'Creamos el nuevo repositorio d�nde almacenaremos los datos
        objDataSet = New DataSet()
        'Rellenamos el repositorio
        objDataAdapter.Fill(objDataSet, "Codigos")
        'Otra forma de volcar datos de un DataSet directamente:
        'Volcamos el repositorio, almacenando en los controles
        'ComboBox4 � ComboBox5 el contenido de �ste
        If bteAccion = 0 Then
            ComboBox4.DataSource = objDataSet.Tables("Codigos")
            ComboBox4.DisplayMember = "Cod_Clase"
        Else
            ComboBox5.DataSource = objDataSet.Tables("Codigos")
            ComboBox5.DisplayMember = "Cod_Prof_FK"
        End If
    End Function

    'Pulsamos el bot�n A�adir
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Select Case ComboBox3.Text
            Case "Alumnos"
                Add_Valor("Insert Into Alumnos (Cod_Clase_FK, Cod_Alumno, Nombre, F_Nac) values (" & ComboBox4.Text & "," & TextBox2.Text & ",'" & TextBox3.Text & "','" & TextBox4.Text & "')")
            Case "Clases"
                Add_Valor("Insert Into Clases (Cod_Clase, Cod_Prof, Tlf) values (" & TextBox1.Text & "," & ComboBox5.Text & "," & TextBox3.Text & ")")
            Case "Especialistas"
                Add_Valor("Insert Into Especialistas (Cod_Prof_FK, Nombre) values (" & ComboBox1.Text & ",'" & TextBox2.Text & "')")
        End Select
    End Sub

    'Funci�n para a�adir valores a la base de datos
    Private Function Add_Valor(ByVal strSQL As String)
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objComando As SqlCommand
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Guarderia")
        'Abrimos la conexi�n
        objConexion.Open()
        'Asignamos la sentencia SQL a la conexi�n
        objComando = New SqlCommand(strSQL, objConexion)
        Try
            'Ejecutamos la sentencia SQL correspondiente
            objComando.ExecuteNonQuery()
            'Mensaje de datos insertados correctamente
            MessageBox.Show("Inserci�n de datos realizada correctamente", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch
            'Mensaje de datos no insertados o error en la inserci�n de datos
            MessageBox.Show("Error en la inserci�n de datos" & vbCrLf & vbCrLf & Err.Description.ToString(), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Stop)
        End Try
        'Cerramos la conexi�n
        objConexion.Close()
    End Function
#End Region

#Region "Eliminar datos"
    'Selecci�n de la opci�n del ComboBox6
    Private Sub ComboBox6_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox6.SelectedIndexChanged
        'Seleccionamos las cajas de texto a a�adir
        'de la aplicaci�n
        Delete_Campos(ComboBox6.Text)
        Button3.Enabled = True
    End Sub

    'Funci�n para seleccionar los campos de la Tabla elegida
    Private Function Delete_Campos(ByVal strTabla As String)
        Select Case strTabla
            Case "Alumnos"
                Label10.Text = "Nombre:"
                Label11.Text = "C�d. Clase:"
                Label12.Text = "C�d. Alumno:"
                Label13.Text = "Fecha Nacimiento:"
                Label12.Visible = True : Label13.Visible = True
                TextBox5.Visible = True
                TextBox6.Visible = True
                TextBox7.Visible = True
                Cargar_Datos(0)
            Case "Clases"
                Label10.Text = "C�d. Clase:"
                Label11.Text = "C�d. Profesor:"
                Label12.Text = "Tel�fono:"
                Label12.Visible = True : Label13.Visible = False
                TextBox5.Visible = True
                TextBox6.Visible = True
                TextBox7.Visible = False
                Cargar_Datos(1)
            Case "Especialistas"
                Label10.Text = "Nombre:"
                Label11.Text = "C�d. Profesor:"
                Label12.Visible = False : Label13.Visible = False
                TextBox5.Visible = True
                TextBox6.Visible = False
                TextBox7.Visible = False
                Cargar_Datos(2)
        End Select
    End Function

    'Funci�n para cargar los datos a eliminar
    Private Function Cargar_Datos(ByVal bteAccion As Byte)
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objDataAdapter As SqlDataAdapter
        Dim objDataSet As DataSet
        Dim objRow As DataRow
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Guarderia")
        'Establecemos la sentencia de selecci�n
        If bteAccion = 0 Then
            objDataAdapter = New SqlDataAdapter("SELECT Nombre From Alumnos", objConexion)
        ElseIf bteAccion = 1 Then
            objDataAdapter = New SqlDataAdapter("SELECT Cod_Clase From Clases", objConexion)
        Else
            objDataAdapter = New SqlDataAdapter("SELECT Nombre From Especialistas", objConexion)
        End If
        'Creamos el nuevo repositorio d�nde almacenaremos los datos
        objDataSet = New DataSet()
        'Rellenamos el repositorio
        objDataAdapter.Fill(objDataSet, "Datos")
        'Otra forma de volcar datos de un DataSet directamente:
        'Volcamos el repositorio, almacenando en el
        'control ComboBox7 el contenido de �ste
        ComboBox7.DataSource = objDataSet.Tables("Datos")
        If bteAccion = 1 Then
            ComboBox7.DisplayMember = "Cod_Clase"
        Else
            ComboBox7.DisplayMember = "Nombre"
        End If
        Cargar_Resto_Datos(bteAccion, ComboBox7.Text)
    End Function

    'Funci�n para cargar los datos a eliminar
    Private Function Cargar_Resto_Datos(ByVal bteAccion As Byte, ByVal strTexto As String)
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objDataAdapter As SqlDataAdapter
        Dim objDataSet As DataSet
        Dim objRow As DataRow
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Guarderia")
        'Establecemos la sentencia de selecci�n
        If bteAccion = 0 Then
            objDataAdapter = New SqlDataAdapter("SELECT * From Alumnos Where Nombre='" & strTexto & "'", objConexion)
        ElseIf bteAccion = 1 Then
            objDataAdapter = New SqlDataAdapter("SELECT * From Clases Where Cod_Clase=" & strTexto, objConexion)
        Else
            objDataAdapter = New SqlDataAdapter("SELECT * From Especialistas Where Nombre='" & strTexto & "'", objConexion)
        End If
        'Creamos el nuevo repositorio d�nde almacenaremos los datos
        objDataSet = New DataSet()
        'Rellenamos el repositorio
        objDataAdapter.Fill(objDataSet, "DetallesDatos")
        'Volcamos el repositorio, almacenando en los
        'controles TextBox correspondientes
        If bteAccion = 0 Then
            TextBox5.DataBindings.Clear()
            TextBox5.DataBindings.Add("Text", objDataSet, "DetallesDatos.Cod_Clase_FK")
            TextBox6.DataBindings.Clear()
            TextBox6.DataBindings.Add("Text", objDataSet, "DetallesDatos.Cod_Alumno")
            TextBox7.DataBindings.Clear()
            TextBox7.DataBindings.Add("Text", objDataSet, "DetallesDatos.F_Nac")
        ElseIf bteAccion = 1 Then
            TextBox5.DataBindings.Clear()
            TextBox5.DataBindings.Add("Text", objDataSet, "DetallesDatos.Cod_Prof")
            TextBox6.DataBindings.Clear()
            TextBox6.DataBindings.Add("Text", objDataSet, "DetallesDatos.Tlf")
        Else
            TextBox5.DataBindings.Clear()
            TextBox5.DataBindings.Add("Text", objDataSet, "DetallesDatos.Cod_Prof_FK")
        End If
    End Function

    'Selecci�n de los datos en el combo de selecci�n
    Private Sub ComboBox7_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox7.SelectedIndexChanged
        Select Case ComboBox6.Text
            Case "Alumnos"
                Cargar_Resto_Datos(0, ComboBox7.Text)
            Case "Clases"
                Cargar_Resto_Datos(1, ComboBox7.Text)
            Case "Especialistas"
                Cargar_Resto_Datos(2, ComboBox7.Text)
        End Select
    End Sub

    'Opci�n para eliminar datos
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Select Case ComboBox6.Text
            Case "Alumnos"
                Delete_Valor("Delete From Alumnos Where Nombre='" & ComboBox7.Text & "'")
            Case "Clases"
                Delete_Valor("Delete From Clases Where Cod_Clase=" & ComboBox7.Text)
            Case "Especialistas"
                Delete_Valor("Delete From Especialistas Where Nombre='" & ComboBox7.Text & "'")
        End Select
    End Sub

    'Funci�n para eliminar valores a la base de datos
    Private Function Delete_Valor(ByVal strSQL As String)
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objComando As SqlCommand
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Guarderia")
        'Abrimos la conexi�n
        objConexion.Open()
        'Asignamos la sentencia SQL a la conexi�n
        objComando = New SqlCommand(strSQL, objConexion)
        Try
            'Ejecutamos la sentencia SQL correspondiente
            objComando.ExecuteNonQuery()
            'Mensaje de datos insertados correctamente
            MessageBox.Show("Eliminaci�n de datos realizada correctamente", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch
            'Mensaje de datos no insertados o error en la inserci�n de datos
            MessageBox.Show("Error en la eliminaci�n de datos" & vbCrLf & vbCrLf & Err.Description.ToString(), Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Stop)
        End Try
        'Cerramos la conexi�n
        objConexion.Close()
    End Function
#End Region

End Class
