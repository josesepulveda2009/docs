Imports System.Data
Imports System.Data.SqlClient

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'LinkLabel1
        '
        Me.LinkLabel1.Location = New System.Drawing.Point(8, 32)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(272, 23)
        Me.LinkLabel1.TabIndex = 0
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "LinkLabel1"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(272, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.LinkLabel1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.Text = ""
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objDataAdapter As SqlDataAdapter
        Dim objDataSet As DataSet
        Dim objRow As DataRow
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Portal")
        'Establecemos la sentencia de selecci�n
        objDataAdapter = New SqlDataAdapter("Select * From Marcas", objConexion)
        'Creamos el nuevo repositorio d�nde almacenaremos los datos
        objDataSet = New System.Data.DataSet()
        'Rellenamos el repositorio
        objDataAdapter.Fill(objDataSet, "Ejemplo")
        'A�adimos el campo de la marca del veh�culo al
        'control LinkLabel, en la propiedad Text de este control
        LinkLabel1.DataBindings.Add("Text", objDataSet, "Ejemplo.Marca_Id")
        'Almacenamos el valor del campo Web de la base de datos
        Dim strWeb As String
        strWeb = objDataSet.Tables("Ejemplo").Rows.Item(0).Item("Web").ToString
        'Modificamos una de las propiedades de presentaci�n del control
        LinkLabel1.LinkBehavior = LinkBehavior.HoverUnderline
        'A�adimos el valor recuperado del campo Web
        LinkLabel1.Links.Add(0, 25, strWeb)
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Label1.Text = e.Link.LinkData.ToString()
    End Sub
End Class
