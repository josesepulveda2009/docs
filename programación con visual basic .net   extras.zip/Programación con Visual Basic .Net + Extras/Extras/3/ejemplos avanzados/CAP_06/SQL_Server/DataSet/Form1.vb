Imports System.Data
Imports System.Data.SqlClient

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.DataGrid1 = New System.Windows.Forms.DataGrid()
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(8, 8)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox1.Size = New System.Drawing.Size(272, 120)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'DataGrid1
        '
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 136)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(272, 248)
        Me.DataGrid1.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(288, 390)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.DataGrid1, Me.TextBox1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Declaraci�n de las variables de conexi�n
        Dim objConexion As SqlConnection
        Dim objDataAdapter As SqlDataAdapter
        Dim objDataSet As System.Data.DataSet
        Dim objRow As DataRow
        'Establecemos la cadena de conexi�n con la base de datos
        objConexion = New SqlConnection("server=PAPEL\NETSDK;integrated security=SSPI;database=Portal")
        'Establecemos la sentencia de selecci�n
        objDataAdapter = New SqlDataAdapter("Select * From Marcas", objConexion)
        'Creamos el nuevo repositorio d�nde almacenaremos los datos
        objDataSet = New System.Data.DataSet()
        'Rellenamos el repositorio
        objDataAdapter.Fill(objDataSet, "Ejemplo")
        'Volcamos en el control DataGrid el contenido del repositorio
        DataGrid1.DataSource = objDataSet
        'Otra forma de recorrer el repositorio,
        'almacenando en el control TextBox el contenido de �ste
        For Each objRow In objDataSet.Tables("Ejemplo").Rows
            TextBox1.Text = TextBox1.Text & objRow("marca_id") & vbTab & objRow("Web") & vbCrLf
        Next
    End Sub
End Class
