Imports System.Xml

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " C�digo generado por el Dise�ador de Windows Forms "

    Public Sub New()
        MyBase.New()

        'El Dise�ador de Windows Forms requiere esta llamada.
        InitializeComponent()

        'Agregar cualquier inicializaci�n despu�s de la llamada a InitializeComponent()

    End Sub

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Dise�ador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Dise�ador de Windows Forms requiere el siguiente procedimiento
    'Puede modificarse utilizando el Dise�ador de Windows Forms. 
    'No lo modifique con el editor de c�digo.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(280, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Label1"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(160, 56)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Leer XML"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(8, 104)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(280, 184)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.Text = ""
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 302)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1, Me.Label1, Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label1.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Llamada a la funci�n para leer el fichero XML
        Call Leer_Fichero_XML()
    End Sub

    'Funci�n para leer el fichero XML en disco
    Private Sub Leer_Fichero_XML()
        Dim objLeerXML As New XmlTextReader("Documento.xml")
        With objLeerXML
            While .Read
                Select Case .NodeType
                    Case XmlNodeType.Element
                        TextBox1.Text = TextBox1.Text & .Name & vbCrLf
                        If .AttributeCount > 0 Then
                            While .MoveToNextAttribute
                                TextBox1.Text = TextBox1.Text & " (" & .Name & " -> " & .Value & ")" & vbCrLf
                            End While
                        End If
                    Case XmlNodeType.Text
                        TextBox1.Text = TextBox1.Text & " " & .Value & vbCrLf
                    Case XmlNodeType.Comment
                        TextBox1.Text = TextBox1.Text & " " & .Value & vbCrLf
                End Select
            End While
            'Cerramos el Documento
            .Close()
        End With
        Label1.Text = "Documento XML leido (Documento.xml)"
    End Sub
End Class
