Module Module1

    Dim strCad1 As String = "Cadena 1"
    Private strCad2 As String = "Cadena 2"

    Public Function ModGeneral() As String
        ModGeneral = ModPrincipal() & vbCrLf & strCad1 & vbCrLf & "de ejemplo"
    End Function

    Private Function ModPrincipal() As String
        ModPrincipal = strCad2 & vbCrLf & "de ejemplo"
    End Function

End Module
