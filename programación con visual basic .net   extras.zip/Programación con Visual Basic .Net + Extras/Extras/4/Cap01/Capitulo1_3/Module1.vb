'--------------------------------------------------------------------
' Cap�tulo 1 (p�gs. 51 y 52)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1

    Sub Main()
        Dim x As Integer
        Dim n As Integer
        x = Int(8.56)
        n = Fix(8.56)
        Console.WriteLine("Positivos (8.56): x = {0}, n = {1}", x, n)

        x = Int(8.2)
        n = Fix(8.2)
        Console.WriteLine("Positivos (8.2): x = {0}, n = {1}", x, n)

        x = Int(-8.56)
        n = Fix(-8.56)
        Console.WriteLine("Negativos (-8.56): x = {0}, n = {1}", x, n)

        x = Int(-8.2)
        n = Fix(-8.2)
        Console.WriteLine("Negativos (-8.2): x = {0}, n = {1}", x, n)

        Console.ReadLine()
    End Sub

End Module
