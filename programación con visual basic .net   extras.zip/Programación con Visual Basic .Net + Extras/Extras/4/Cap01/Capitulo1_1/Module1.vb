'--------------------------------------------------------------------
' Cap�tulo 1 (p�g. 52)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
Module Module1

    Sub Main()
        Dim n As String
        Const saludo As String = "Hola"

        ' Usando el ampersand (&)
        n = saludo & " Juan"
        Console.WriteLine(n)

        ' Usando la suma (+)
        n = saludo + " Juan"
        Console.WriteLine(n)

        Dim s As String
        s = "Hola"
        s &= " Juan"
        Console.WriteLine(s)

        s = "Hola"
        s = s & " Juan"
        Console.WriteLine(s)

        Console.ReadLine()
    End Sub

End Module
