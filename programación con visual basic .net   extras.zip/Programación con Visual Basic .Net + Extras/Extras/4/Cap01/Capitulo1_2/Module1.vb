'--------------------------------------------------------------------
' Cap�tulo 1 (p�gs. 48 a 50)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
Option Strict On
Module Module1

    Sub Main()
        Dim x As Integer

        ' Esta conversi�n s�lo funciona con Option Strict Off
        'x = Val("10 * 25")
        ' Estas tres funcionan siempre
        'x = CType(Val("10"), Integer)
        'x = CInt(Val("10"))
        'x = CInt("10")
        ' Esto no funcionar�, dar� error en tiempo de ejecuci�n
        ' ya que CInt no admite nada que no sean d�gitos
        'x = CInt("10 * 25")
        ' Esto tampoco ser�a v�lido y dar�a error en ejecuci�n
        'x = CInt("10 25")
        ' Esto devolver� 1025, el punto se ignora
        'x = CInt("10.25")
        ' Esto sin embargo devolver� 10
        'x = CInt("10,25")
        ' y esto otro devolver� 11
        'x = CInt("10,52")

        ' Esta no funcionar�, 
        ' pero el error lo dar� en tiempo de ejecuci�n
        'x = CInt("Hola")
        ' Esta funcionar� siempre 
        ' (aunque dar� cero como resultado)
        x = CInt(Val("Hola"))

        ' Esto dar� error de desbordamiento
        'x = CInt("123456789012345")
        ' y esto tambi�n:
        'x = CInt(Val("123456789012345"))
        ' incluso esto:
        'x = CType(Val("123456789012345"), Integer)

        Console.WriteLine(x)
        Console.ReadLine()
    End Sub
End Module
