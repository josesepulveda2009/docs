'------------------------------------------------------------------------------
' Cap�tulo 9 (p�gs. 207 a 209) 
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Public Interface IMordedor
    Sub Morder()
End Interface
Public Interface IPicador
    Sub Picar()
End Interface

Public MustInherit Class cAnimal
    Public MustOverride ReadOnly Property Nombre() As String
    Public MustOverride ReadOnly Property Familia() As String
    '
    Private mMovilidad As Boolean = True
    Public Overridable Property Movilidad() As Boolean
        Get
            Return mMovilidad
        End Get
        Set(ByVal Value As Boolean)
            mMovilidad = Value
        End Set
    End Property
End Class

Public Class cPerro
    Inherits cAnimal
    Implements IMordedor

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Perro"
        End Get
    End Property

    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "C�nidos"
        End Get
    End Property

    Public Sub Morder() Implements IMordedor.Morder
        Console.WriteLine("Mordedura del perro.")
    End Sub
End Class

Public Class cCocodrilo
    Inherits cAnimal
    Implements IMordedor

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Cocodrilo"
        End Get
    End Property
    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "Reptiles"
        End Get
    End Property

    Public Sub Morder() Implements IMordedor.Morder
        Console.WriteLine("Mordedura del cocodrilo.")
    End Sub
End Class

Public Class cGallina
    Inherits cAnimal
    Implements IPicador

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Gallina"
        End Get
    End Property
    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "Gallin�ceas"
        End Get
    End Property

    Public Sub Picar() Implements IPicador.Picar
        Console.WriteLine("Picadura de la gallina.")
    End Sub
End Class

Module Module1
    Sub Main()
        Dim oAni As cAnimal
        Dim oFeroz As IMordedor
        Dim oCan As New cPerro()
        Dim oCoco As New cCocodrilo()
        Dim oGalli As New cGallina()
        '
        oCan.Morder()
        oCoco.Morder()
        oGalli.Picar()
        '
        Console.WriteLine()
        oAni = oCan
        Console.WriteLine("Despu�s de oAni = oCan, oAni.Nombre = {0}", oAni.Nombre)
        Console.WriteLine("oAni.Familia = {0}, oAni.Movilidad = {1}", oAni.Familia, oAni.Movilidad)
        oFeroz = oCan
        Console.Write("Despu�s de oFeroz = oCan, oFeroz.Morder() muestra: ")
        oFeroz.Morder()
        '
        Console.WriteLine()
        oAni = oCoco
        oAni.Movilidad = False
        Console.WriteLine("Despu�s de oAni = oCoco, oAni.Nombre = {0}", oAni.Nombre)
        Console.WriteLine("oAni.Familia = {0}, oAni.Movilidad = {1}", oAni.Familia, oAni.Movilidad)
        Console.WriteLine("oCoco.Movilidad = {0}", oCoco.Movilidad)
        oFeroz = oCoco
        Console.Write("Despu�s de oFeroz = oCoco, oFeroz.Morder() muestra: ")
        oFeroz.Morder()
        '
        Console.WriteLine()
        oAni = oGalli
        Console.WriteLine("Despu�s de oAni = oGalli, oAni.Nombre = {0}", oAni.Nombre)
        Console.WriteLine("oAni.Familia = {0}, oAni.Movilidad = {1}", oAni.Familia, oAni.Movilidad)
        '
        Console.ReadLine()
    End Sub
End Module
