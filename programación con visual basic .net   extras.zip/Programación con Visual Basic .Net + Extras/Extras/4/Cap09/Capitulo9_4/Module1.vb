'------------------------------------------------------------------------------
' Cap�tulo 9 (p�gs. 216 y 217) 
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Public Interface IMordedor
    Sub Morder()
End Interface
Public Interface IPicador
    Sub Picar()
End Interface
Public Interface IClase
    ReadOnly Property Nombre() As String
    ReadOnly Property Familia() As String
End Interface
Public MustInherit Class cAnimal
    Implements IClase
    Public MustOverride ReadOnly Property Nombre() As String _
            Implements IClase.Nombre
    Public MustOverride ReadOnly Property Familia() As String _
            Implements IClase.Familia
    '
    Private mMovilidad As Boolean = True
    Public Overridable Property Movilidad() As Boolean
        Get
            Return mMovilidad
        End Get
        Set(ByVal Value As Boolean)
            mMovilidad = Value
        End Set
    End Property
End Class
Public Class cPerro
    Inherits cAnimal
    Implements IMordedor

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Perro"
        End Get
    End Property

    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "C�nidos"
        End Get
    End Property

    Public Sub Morder() Implements IMordedor.Morder
        Console.WriteLine("Mordedura del perro.")
    End Sub
End Class
Public Class cCocodrilo
    Inherits cAnimal
    Implements IMordedor

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Cocodrilo"
        End Get
    End Property
    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "Reptiles"
        End Get
    End Property

    Public Sub Morder() Implements IMordedor.Morder
        Console.WriteLine("Mordedura del cocodrilo.")
    End Sub
End Class
Public Class cGallina
    Inherits cAnimal
    Implements IPicador

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Gallina"
        End Get
    End Property
    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "Gallin�ceas"
        End Get
    End Property

    Public Sub Picar() Implements IPicador.Picar
        Console.WriteLine("Picadura de la gallina.")
    End Sub
End Class

Module Module1
    Sub Main()
        Dim oAni As cAnimal
        Dim oFeroz As IMordedor
        Dim oCan As New cPerro()
        Dim oCoco As New cCocodrilo()
        Dim oGalli As New cGallina()
        '
        Dim Animales() As cAnimal = {oCan, oCoco, oGalli, New cCocodrilo()}
        Dim i As Integer
        For i = 0 To Animales.Length - 1
            Console.WriteLine("�ndice= {0,3}, Nombre= {1}, Es mordedor= {2}", _
                    i, Animales(i).Nombre, TypeOf Animales(i) Is IMordedor)
        Next
        '
        Console.WriteLine()
        '
        For Each oAni In Animales
            Console.WriteLine("Nombre= {0}, Es mordedor= {1}", _
                    oAni.Nombre, TypeOf oAni Is IMordedor)
        Next
        '
        Console.WriteLine()
        '
        Dim j As Integer
        For Each oAni In Animales
            j = j + 1
            Console.WriteLine("j= {2}, Nombre= {0}, Es mordedor= {1}", _
                    oAni.Nombre, TypeOf oAni Is IMordedor, j)
        Next
        '
        Console.Write("Pulse Intro para terminar.")
        Console.ReadLine()
    End Sub
End Module
