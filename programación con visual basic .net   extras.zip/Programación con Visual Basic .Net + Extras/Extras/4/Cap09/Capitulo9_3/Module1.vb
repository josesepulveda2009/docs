'------------------------------------------------------------------------------
' Cap�tulo 9 (p�gs. 214 a 216) 
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Public Interface IMordedor
    Sub Morder()
End Interface
Public Interface IPicador
    Sub Picar()
End Interface

Public Interface IClase
    ReadOnly Property Nombre() As String
    ReadOnly Property Familia() As String
End Interface

Public MustInherit Class cAnimal
    Implements IClase
    '
    Public MustOverride ReadOnly Property Nombre() As String _
            Implements IClase.Nombre
    Public MustOverride ReadOnly Property Familia() As String _
            Implements IClase.Familia
    '
    Private mMovilidad As Boolean = True
    Public Overridable Property Movilidad() As Boolean
        Get
            Return mMovilidad
        End Get
        Set(ByVal Value As Boolean)
            mMovilidad = Value
        End Set
    End Property
End Class

Public Class cPerro
    Inherits cAnimal
    Implements IMordedor

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Perro"
        End Get
    End Property

    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "C�nidos"
        End Get
    End Property

    Public Sub Morder() Implements IMordedor.Morder
        Console.WriteLine("Mordedura del perro.")
    End Sub
End Class

Public Class cCocodrilo
    Inherits cAnimal
    Implements IMordedor

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Cocodrilo"
        End Get
    End Property
    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "Reptiles"
        End Get
    End Property

    Public Sub Morder() Implements IMordedor.Morder
        Console.WriteLine("Mordedura del cocodrilo.")
    End Sub
End Class

Public Class cGallina
    Inherits cAnimal
    Implements IPicador

    Public Overrides ReadOnly Property Nombre() As String
        Get
            Return "Gallina"
        End Get
    End Property
    Public Overrides ReadOnly Property Familia() As String
        Get
            Return "Gallin�ceas"
        End Get
    End Property

    Public Sub Picar() Implements IPicador.Picar
        Console.WriteLine("Picadura de la gallina.")
    End Sub
End Class

Module Module1
    Sub Main()
        Dim oAni As cAnimal
        Dim oFeroz As IMordedor
        Dim oCan As New cPerro()
        Dim oCoco As New cCocodrilo()
        Dim oGalli As New cGallina()
        '
        Console.WriteLine("TypeName(oCan) = {0}", TypeName(oCan))
        Console.WriteLine("oCan.GetType.Name = {0}", oCan.GetType.Name)
        Console.WriteLine("GetType(cPerro).Name = {0}", GetType(cPerro).Name)
        Console.WriteLine("oCan.GetType.BaseType.Name = {0}", oCan.GetType.BaseType.Name)
        Console.WriteLine("TypeOf oCan Is cAnimal = {0}", TypeOf oCan Is cAnimal)
        Console.WriteLine("TypeOf oCan Is IMordedor = {0}", TypeOf oCan Is IMordedor)
        Console.WriteLine("TypeOf oCan Is IPicador = {0}", TypeOf oCan Is IPicador)
        Console.WriteLine("TypeOf oCan Is IClase = {0}", TypeOf oCan Is IClase)
        '
        Console.WriteLine()
        MostrarInfo(oCan)
        MostrarInfo(oGalli)
        '
        Console.ReadLine()
        '
        oAni = oCan
        MostrarInfo(oAni)
        oFeroz = oCan
        MostrarInfo(oFeroz)
        '
        Console.Write("Pulse Intro para terminar.")
        Console.ReadLine()
    End Sub
    '
    Public Sub MostrarInfo(ByVal unObjeto As Object)
        Dim sNombre As String = unObjeto.GetType.Name
        '
        Console.WriteLine("La clase base de {0} es {1}", sNombre, unObjeto.GetType.BaseType.Name)
        If TypeOf unObjeto Is cAnimal Then
            Console.WriteLine("{0} el del tipo cAnimal", sNombre)
        End If
        If TypeOf unObjeto Is IMordedor Then
            Console.WriteLine("{0} implementa la interfaz IMordedor", sNombre)
        Else
            Console.WriteLine("{0} NO implementa la interfaz IMordedor", sNombre)
        End If
        If TypeOf unObjeto Is IPicador Then
            Console.WriteLine("{0} implementa la interfaz IPicador", sNombre)
        Else
            Console.WriteLine("{0} NO implementa la interfaz IPicador", sNombre)
        End If
        If TypeOf unObjeto Is IClase Then
            Console.WriteLine("{0} implementa la interfaz IClase", sNombre)
        Else
            Console.WriteLine("{0} NO implementa la interfaz IClase", sNombre)
        End If
        Console.WriteLine()
    End Sub
    '
End Module
