'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 119)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim m As Integer() = {15, 17, 39, 24, 21}
        Dim i As Integer
        Dim r() As Integer
        ' El array de destino debe estar dimensionada con espacio suficiente
        ReDim r(m.Length - 1)
        Array.Copy(m, r, m.Length)
        m(1) = 2
        For i = 0 To r.Length - 1
            Console.WriteLine("El contenido de r({0}) es: {1}, el de m({0}) es: {2}", i, r(i), m(i))
        Next
        '
        Console.ReadLine()
    End Sub
End Module
