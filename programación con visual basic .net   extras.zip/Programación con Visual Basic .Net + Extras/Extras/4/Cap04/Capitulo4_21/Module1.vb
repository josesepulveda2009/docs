'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 122)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim t(,) As Integer = {{1, 2}, {3, 4}, {5, 6}}
        Dim f, c As Integer
        '
        f = t.GetUpperBound(0)
        c = t.GetUpperBound(1)
        ' Redim Preserve s�lo permite modificar la �ltima dimensi�n
        ReDim Preserve t(f, c + 2)
        '        
        For f = 0 To t.GetUpperBound(0)
            For c = 0 To t.GetUpperBound(1)
                Console.WriteLine("t({0},{1}) contiene {2,3}", f, c, t(f, c))
            Next
        Next
        '
        Console.ReadLine()
    End Sub
End Module
