'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 119)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        '
        Dim m As Integer() = {15, 17, 39, 24, 21}
        Dim i As Integer
        '
        Dim r() As Integer
        '
        ' Hacer un "casting" o conversi�n de tipos,
        ' ya que el tipo devuelto por Clone es de tipo Object
        ' y la variable r es un array de tipo Integer ( Integer() )
        r = CType(m.Clone(), Integer())
        m(1) = 2
        Console.WriteLine()
        For i = 0 To r.Length - 1
            Console.WriteLine("El contenido de r({0}) es: {1}, el de m({0}) es: {2}", i, r(i), m(i))
        Next
        '
        '-------------------------------------------------
        ' Este es el c�digo que aparece en el libro,
        ' el cual elimina 2 elementos del array,
        ' los que est�n en la posici�n 5 y 6
        '-------------------------------------------------
        'Dim i As Integer
        ''
        'Dim r As Integer() = {15, 17, 39, 24, 21, 7, 20, 41, 97}
        'Array.Clear(r, 5, 2)
        'For i = 0 To r.Length - 1
        '    Console.WriteLine("El contenido de r({0}) es {1}", i, r(i))
        'Next
        '
        Console.ReadLine()
    End Sub
End Module
