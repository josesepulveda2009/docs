'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 108)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        ' Parte 1
        Dim Valores(5) As Integer
        Dim i, n As Integer
        '
        For i = 0 To 5
            Console.Write("Escriba un valor num�rico ")
            n = CInt(Console.ReadLine)
            Valores(i) = n
        Next
        '
        ' Parte 2
        Dim Total As Integer
        For i = 0 To 5
            Total = Total + Valores(i)
        Next
        Console.WriteLine("La suma de los valores introducidos es: " & CStr(Total))
        '
        Console.ReadLine()
    End Sub
End Module
