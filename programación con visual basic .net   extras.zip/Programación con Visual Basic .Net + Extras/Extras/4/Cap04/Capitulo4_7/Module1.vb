'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 114)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        ' Parte 1.3
        Console.WriteLine("Podemos {0} repetir {0} el mismo par�metro: {0}", 7)
        '
        Console.ReadLine()
    End Sub
End Module
