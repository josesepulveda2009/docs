'------------------------------------------------------------------------------
' Cap�tulo 4 (p�gs. 110 y 111)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim m As Integer() = {15, 17, 39, 24, 21}
        Dim i As Integer
        '
        ReDim Preserve m(10)
        m(7) = 99
        For i = 0 To 10
            Console.WriteLine(m(i))
        Next
        '
        Console.ReadLine()
    End Sub
End Module
