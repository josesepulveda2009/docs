'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 116)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim i As Integer
        '
        ' Parte 1.7
        Dim s As String() = {"Hola", "desde", "Visual", "Basic.NET"}
        For i = 0 To s.Length - 1
            Console.WriteLine("s({0}) contiene: {1,7}", i, s(i))
        Next
        '
        Console.ReadLine()
    End Sub
End Module
