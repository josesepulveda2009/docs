'------------------------------------------------------------------------------
' Cap�tulo 4 (p�gs. 111 y 112)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim s As String() = {"Esto", "es", "un", "array", "de", "tipo", "String"}
        Dim i As Integer
        '
        ReDim Preserve s(9)
        s(8) = "Elemento 8"
        '
        For i = 0 To 9
            Console.WriteLine("El contenido del elemento " & CStr(i) & " es: " & s(i))
        Next
        '
        Console.ReadLine()
    End Sub
End Module
