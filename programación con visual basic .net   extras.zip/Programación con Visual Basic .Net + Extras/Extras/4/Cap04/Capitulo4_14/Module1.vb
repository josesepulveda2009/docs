'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 118)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim m As Integer() = {15, 17, 39, 24, 21}
        Dim i As Integer
        Dim r() As Integer
        '
        r = m
        m(1) = 2
        For i = 0 To r.Length - 1
            Console.WriteLine("El contenido de r({0}) es {1}", i, r(i))
        Next
        '
        '' otra forma de hacerlo (esto no est� en el libro)
        'Dim p As Array
        'p = m
        'm(1) = 1
        'Console.WriteLine()
        'For i = 0 To p.Length - 1
        '    Console.WriteLine("El contenido de p({0}) es {1}", i, p.GetValue(i))
        'Next
        '
        Console.ReadLine()
    End Sub
End Module
