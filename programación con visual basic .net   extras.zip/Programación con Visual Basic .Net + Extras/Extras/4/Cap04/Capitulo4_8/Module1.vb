'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 115)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        ' Parte 1.4
        Dim s As String
        s = "{0}"
        s &= "Podemos usar cada par�metro{0}tantas veces{0}"
        s &= "como queramos.{0}..."
        Console.Write("{0}Usando vbCrLf: " & s, vbCrLf)
        Console.Write("{0}Usando ControlChars.CrLf: " & s, ControlChars.CrLf)
        Console.Write("{0}Usando Console.Out.NewLine: " & s, Console.Out.NewLine)
        '
        Console.ReadLine()
    End Sub
End Module
