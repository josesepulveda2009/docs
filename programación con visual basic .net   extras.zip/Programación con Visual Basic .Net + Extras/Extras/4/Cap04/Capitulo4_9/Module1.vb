'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 115)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim i As Integer
        '
        ' Parte 1.5
        For i = -109 To 111 Step 10
            Console.WriteLine("{0,4}", i)
        Next
        '
        Console.ReadLine()
    End Sub
End Module
