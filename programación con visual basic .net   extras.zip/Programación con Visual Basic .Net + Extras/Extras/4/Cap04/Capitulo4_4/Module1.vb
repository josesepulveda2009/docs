'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 113)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim m As Integer() = {15, 17, 39, 24, 21}
        Dim i As Integer
        '
        ' Parte 1.0
        For i = 0 To m.Length - 1
            Console.WriteLine("El contenido de m(i) es {0}", m(i))
        Next
        '
        Console.ReadLine()
    End Sub
End Module
