'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 120)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim t(,) As Integer
        Dim i, f, c As Integer
        '
        ReDim t(1, 2)
        ' asignar algunos valores al array
        i = 1
        For f = 0 To t.GetUpperBound(0)
            For c = 0 To t.GetUpperBound(1)
                t(f, c) = i
                i += 1
            Next
        Next
        '
        ' Mostrar el contenido del array
        For f = 0 To t.GetUpperBound(0)
            For c = 0 To t.GetUpperBound(1)
                Console.WriteLine("Contenido de t({0}, {1}) = {2}", f, c, t(f, c))
            Next
        Next
        '
        Console.ReadLine()
    End Sub
End Module
