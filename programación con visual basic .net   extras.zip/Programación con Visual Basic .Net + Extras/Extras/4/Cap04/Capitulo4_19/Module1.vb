'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 121)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim t1(,) As Integer = {{1, 2, 3}, {4, 5, 6}}
        Dim t2 As Integer(,,) = { _
                {{1, 2, 3}, {4, 5, 6}}, _
                {{7, 8, 9}, {10, 11, 12}}, _
                {{13, 14, 15}, {16, 17, 18}}, _
                {{19, 20, 21}, {22, 23, 24}} _
                }
        Dim f, c, d As Integer
        '
        Console.WriteLine("Contenido del array t1(,), con {0} dimensiones y {1} elementos", t1.Rank, t1.Length)
        For f = 0 To t1.GetUpperBound(0)
            For c = 0 To t1.GetUpperBound(1)
                Console.WriteLine("Contenido de t1({0}, {1}) = {2}", f, c, t1(f, c))
            Next
        Next
        '
        Console.ReadLine()
        Console.WriteLine("Contenido del array t2(,,), con {0} dimensiones y {1} elementos", t2.Rank, t2.Length)
        For f = 0 To t2.GetUpperBound(0)
            For c = 0 To t2.GetUpperBound(1)
                For d = 0 To t2.GetUpperBound(2)
                    Console.WriteLine("Contenido de t2({0}, {1}, {2}) = {3}", f, c, d, t2(f, c, d))
                Next
            Next
        Next
        '
        Console.ReadLine()
    End Sub
End Module
