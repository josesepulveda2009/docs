'------------------------------------------------------------------------------
' Cap�tulo 4 (p�gs. 123 y 124)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim m() As Integer
        Dim i As Integer
        '
        m = ArrayInt(10)
        For i = 0 To m.GetUpperBound(0)
            Console.WriteLine("m({0,2}) contiene {1,3}", i, m(i))
        Next
        '
        Console.WriteLine()
        '
        Dim t(,) As Integer
        Dim f, c As Integer
        t = ArrayInt2(2, 3)
        For f = 0 To t.GetUpperBound(0)
            For c = 0 To t.GetUpperBound(1)
                Console.WriteLine("t({0},{1}) contiene {2,3}", f, c, t(f, c))
            Next
        Next
        '
        Console.ReadLine()
    End Sub
    '
    Function ArrayInt(ByVal NumElementos As Integer) As Integer()
        ' Devuelve un array de tipo Integer
        ' con el n�mero de elementos indicados
        Dim unArray() As Integer
        Dim i As Integer
        '
        ReDim unArray(NumElementos)
        For i = 0 To NumElementos
            unArray(i) = i
        Next
        Return unArray
    End Function
    '
    Function ArrayInt2(ByVal filas As Integer, _
                ByVal columnas As Integer) As Integer(,)
        ' Esta funci�n devuelve un array de dos dimensiones
        Dim unArray(,) As Integer
        Dim f, c, i As Integer
        '
        ReDim unArray(filas, columnas)
        i = 0
        For f = 0 To filas
            For c = 0 To columnas
                unArray(f, c) = i
                i += 1
            Next
        Next
        Return unArray
    End Function
End Module
