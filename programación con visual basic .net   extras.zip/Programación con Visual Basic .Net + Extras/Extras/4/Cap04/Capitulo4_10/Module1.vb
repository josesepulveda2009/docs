'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 116)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        ' Parte 1.6
        Dim d As Double
        For d = 1 To 15 Step 0.75
            Console.WriteLine("{0,7:.000}", d)
        Next
        '
        Console.ReadLine()
    End Sub
End Module
