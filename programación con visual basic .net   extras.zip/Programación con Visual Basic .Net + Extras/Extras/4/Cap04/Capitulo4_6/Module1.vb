'------------------------------------------------------------------------------
' Cap�tulo 4 (p�g. 114)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim m As Integer() = {15, 17, 39, 24, 21}
        Dim i As Integer
        '
        ' Parte 1.2
        ' Para mostrar las llaves, hay que usar dos llaves:
        Console.WriteLine("Usando par�metros: {0}, para mostrar una llave {{ o }} hay que usar dos. {0}", i)
        Console.WriteLine("Si no se usan par�metros, se mostrar� lo que se escriba: {0}")
        '
        Console.ReadLine()
    End Sub
End Module
