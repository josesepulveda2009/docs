'------------------------------------------------------------------------------
' Cap�tulo 11 (varias de las pruebas entre arrays y colecciones)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        ' Variables gen�ricas que vamos a usar
        Dim i As Integer
        Dim j As Integer
        Dim s As String
        '-----------------
        ' Definir (crear)
        '-----------------
        ' Una colecci�n
        Dim col As New ArrayList()
        ' Un array
        Dim arr() As String
        'Dim arr As String()
        '
        '-------------------------
        ' A�adir nuevos elementos
        '-------------------------
        For i = 0 To 9
            s = "Elemento n�mero " & i.ToString
            ' en un array
            ReDim Preserve arr(i)
            arr(i) = s
            ' en una colecci�n
            col.Add(s)
        Next
        '
        '--------------------
        ' Buscar un elemento
        '--------------------
        s = "Elemento n�mero 3"
        '
        i = Array.IndexOf(arr, s)
        Console.WriteLine(arr(i))
        '
        i = col.IndexOf(s)
        Console.WriteLine(col(i))
        '
        Console.WriteLine()
        '
        Console.WriteLine("Los elementos del array y de la colecci�n antes de operar con ellos:")
        For i = 0 To 9
            Console.WriteLine("Elemento {0}, del array: {1}, de la colecci�n: {2}", i, arr(i), col(i))
        Next
        Console.WriteLine()
        '
        '--------------------
        ' Eliminar el �ltimo
        '--------------------
        'j = arr.Length - 1
        'ReDim Preserve arr(j - 1)
        j = arr.Length
        ReDim Preserve arr(j - 2)
        'j = arr.GetUpperBound(0)
        'j = UBound(arr)
        'ReDim Preserve arr(j - 1)
        '
        j = col.Count - 1
        col.RemoveAt(j)
        '
        Console.WriteLine("Los elementos despu�s de eliminar el �ltimo:")
        For i = 0 To arr.Length - 1
            'Console.WriteLine("Elemento {0}, del array: {1}, de la colecci�n: {2}", i, arr(i), col(i))
            Console.WriteLine("Elemento {0}, del array: {1}", i, arr(i))
        Next
        Console.WriteLine()
        '
        '---------------------
        ' Eliminar el primero
        '---------------------
        '' En un array sin cambiar el orden
        'j = arr.Length - 1
        'For i = 1 To j
        '    arr(i - 1) = arr(i)
        'Next
        'ReDim Preserve arr(j - 1)
        '
        '' En un array cambiando el orden
        'j = arr.Length - 1
        'arr(0) = arr(j)
        'ReDim Preserve arr(j - 1)
        '
        ' Usando el m�todo Copy, 
        ' pero usando el mismo array como origen y destino
        j = arr.Length - 1
        Array.Copy(arr, 1, arr, 0, j)
        ReDim Preserve arr(j - 1)
        '
        ' en una colecci�n
        col.RemoveAt(0)
        '
        '------------------------------------------------------
        ' Eliminar uno cualquiera (ni el primero ni el �ltimo)
        '------------------------------------------------------
        ' Sin cambiar el orden
        'j = arr.Length \ 2
        'For i = j + 1 To arr.Length - 1
        '    arr(i - 1) = arr(i)
        'Next
        'j = arr.Length - 1
        'ReDim Preserve arr(j - 1)
        '
        '' Cambiando el orden
        'j = arr.Length - 1
        'i = j \ 2
        'arr(i) = arr(j)
        'ReDim Preserve arr(j - 1)
        '
        ' Usando el m�todo Copy
        j = arr.Length - 1
        i = arr.Length \ 2
        Array.Copy(arr, i + 1, arr, i, j - i)
        ReDim Preserve arr(j - 1)
        '
        j = col.Count \ 2
        col.RemoveAt(j)
        '
        '-------------------------------------------------
        ' Insertar un nuevo elemento en la posici�n 5
        ' Realmente se insertar� en la sexta posici�n,
        ' ya que el primer elemento est� en la posici�n 0
        '-------------------------------------------------
        s = "Nuevo elemento en la posici�n 5"
        '
        j = arr.Length - 1
        ReDim Preserve arr(j + 1)
        For i = arr.Length - 1 To 5 Step -1
            arr(i) = arr(i - 1)
        Next
        arr(5) = s
        '
        col.Insert(5, s)
        '
        '-------------------------------------
        ' Recorrer los elementos y mostrarlos
        '-------------------------------------
        Console.WriteLine("Los elementos del array:")
        For i = 0 To arr.Length - 1
            Console.WriteLine(arr(i))
        Next
        'For Each s In arr
        '    Console.WriteLine(s)
        'Next
        '
        Console.WriteLine()
        '
        Console.WriteLine("Los elementos de la colecci�n:")
        For i = 0 To col.Count - 1
            Console.WriteLine(col(i))
        Next
        'For Each s In col
        '    Console.WriteLine(s)
        'Next
        '
        Console.ReadLine()
    End Sub
End Module
