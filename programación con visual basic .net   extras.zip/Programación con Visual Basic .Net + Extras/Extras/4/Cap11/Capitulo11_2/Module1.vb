'------------------------------------------------------------------------------
' Cap�tulo 11 (varias pruebas unas comentadas y otras no...)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Imports System.Collections.Specialized
Imports cs = System.Collections.Specialized

Structure Hola
    Public Saludo As String
End Structure
Enum Hola2
    Rojo
    Azul
End Enum

Module Module1
    Class cItem
        Public Nombre As String
    End Class
    '
    Sub Main()
        'Dim col As New System.Collections.Specialized.StringCollection()
        'Dim col As New StringCollection()
        'Dim col As New cs.StringCollection()
        '
        '
        'Dim i As Integer
        'Dim clave As String
        'Dim tEntry As DictionaryEntry
        'Dim ArrL As New ArrayList()
        'Dim Hash As New Hashtable()
        ''
        '
        ' P�gina 253
        '
        'Dim tItem As cItem
        'For i = 0 To 5
        '    clave = i.ToString("000")
        '    tItem = New cItem()
        '    tItem.Nombre = "Elemento n� " & i.ToString("000")
        '    ArrL.Add(tItem)
        '    'Hash.Add(clave, tItem)
        '    Hash.Add(clave, tItem.Nombre)
        'Next
        '
        ' P�ginas 253 y 254
        ' 
        'Console.WriteLine("El contenido del ArrayList con {0} elementos.", ArrL.Count)
        ''For Each tItem In ArrL
        ''    Console.WriteLine("Contenido: {0}", tItem.Nombre)
        ''Next
        '
        ' P�gina 254
        '
        'For i = 0 To ArrL.Count - 1
        '    'tItem = CType(ArrL.Item(i), cItem)
        '    'Console.WriteLine("Contenido: {0}", tItem.Nombre)
        '    Console.WriteLine("Contenido: {0}", CType(ArrL.Item(i), cItem).Nombre)
        'Next
        '






        ' P�gina 255
        '
        Dim i As Integer
        Dim clave As String
        Dim tEntry As DictionaryEntry
        Dim Hash As New Hashtable()
        Dim tItem As cItem
        Dim valor As String
        '
        For i = 0 To 5
            clave = i.ToString("000")
            valor = "Elemento n� " & i.ToString("000")
            Hash.Add(clave, valor)
        Next
        '
        Console.WriteLine()
        Console.WriteLine("El contenido del Hashtable con {0} elementos.", Hash.Count)
        For Each tEntry In Hash
            tItem = CType(tEntry.Value, cItem)
            Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tItem.Nombre)
        Next
        '
        Console.WriteLine()
        Console.WriteLine("Pulse una tecla para finalizar.")
        Console.ReadLine()
    End Sub
    '









    '
    ' P�gina 254 / 256
    '
    'For Each tEntry In Hash
    '    Try
    '        tItem = CType(tEntry.Value, cItem)
    '        Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tItem.Nombre)
    '    Catch
    '        Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
    '    End Try
    '    'tItem = CType(tEntry.Value, cItem)
    '    'Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tItem.Nombre)
    '    'Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tEntry.Value.Nombre)
    'Next
    '
    ' P�gina 251
    '
    Sub Main1()
        Dim i As Integer
        Dim valor, clave As String
        Dim s As String
        Dim tEntry As DictionaryEntry
        Dim ArrL As New ArrayList()
        Dim Hash As New Hashtable()
        '
        ' A�adir elementos
        For i = 0 To 5
            clave = i.ToString("000")
            valor = "Elemento n� " & i.ToString("000")
            ArrL.Add(valor)
            Hash.Add(clave, valor)
        Next
        '
        ' P�gina 252
        '
        ' Mostrar el contenido del ArrayList
        Console.WriteLine("El contenido del ArrayList con {0} elementos.", ArrL.Count)
        For Each s In ArrL
            Console.WriteLine("Contenido: {0}", s)
        Next
        '
        ' P�gina 252
        '
        'For i = 0 To ArrL.Count - 1
        '    'Console.WriteLine("Contenido: {0}", ArrL(i))
        '    Console.WriteLine("Contenido: {0}", ArrL.Item(i))
        'Next
        '
        '
        Console.WriteLine()
        '
        ' P�gina 252
        '
        ' Mostrar el contenido del Hashtable
        Console.WriteLine("El contenido del Hashtable con {0} elementos.", Hash.Count)
        For Each tEntry In Hash
            Console.WriteLine("Clave: {0}, Contenido: {1}", _
                        tEntry.Key, tEntry.Value)
        Next
        '
        Console.WriteLine()
        Console.WriteLine("Pulse una tecla para finalizar.")
        Console.ReadLine()
    End Sub
End Module
