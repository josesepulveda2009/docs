'------------------------------------------------------------------------------
' Cap�tulo 13
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------

Public Class Item
    Public Contenido As String
    '
    '--------------------------------------------------------------------------
    ' Segunda forma de usarlo (haciendo ID de solo lectura)
    '--------------------------------------------------------------------------
    Private mID As String
    'Private Shared num As Integer
    Public ReadOnly Property ID() As String
        Get
            Return mID
        End Get
    End Property
    ' S�lo se puede asignar el ID al crear la instancia,
    ' si no se indica, creamos un valor basado en el n�mero de instancias
    'Sub New()
    '    num = num + 1
    '    mID = num.ToString("00000")
    'End Sub
    Sub New(ByVal nuevoID As String)
        'Me.New()
        mID = nuevoID
    End Sub
    '
    '--------------------------------------------------------------------------
    ' Primera forma de usarlo
    '--------------------------------------------------------------------------
    'Public ID As String
    '
    '--------------------------------------------------------------------------
    ' Usando Contenido como propiedad
    '--------------------------------------------------------------------------
    'Private mContenido As String
    'Public Property Contenido() As String
    '    Get
    '        Return mContenido
    '    End Get
    '    Set(ByVal Value As String)
    '        mContenido = Value
    '    End Set
    'End Property

End Class
