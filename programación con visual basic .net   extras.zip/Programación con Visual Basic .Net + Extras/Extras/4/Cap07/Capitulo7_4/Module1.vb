'------------------------------------------------------------------------------
' Cap�tulo 7 (p�gs. 166 y 167)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim oBici As New cBicicleta()
        Console.WriteLine("Ruedas de una bicicleta = {0}", oBici.Ruedas)
        '
        Dim oTriciclo As New cTriciclo()
        Console.WriteLine("Ruedas de un triciclo = {0}", oTriciclo.Ruedas)
        '
        Console.ReadLine()
    End Sub
End Module

Public Class cVehiculo
    Protected mRuedas As Integer
    '
    Public Overridable ReadOnly Property Ruedas() As Integer
        Get
            Return mRuedas
        End Get
    End Property
End Class
Public Class cBicicleta
    Inherits cVehiculo
    '
    Public Overrides ReadOnly Property Ruedas() As Integer
        Get
            ' No es necesario usar MyBase ya que no hay conflictos de nombres
            ' por tanto, tambi�n ser�a v�lido usar: MyBase.mRuedas = 2
            mRuedas = 2
            Return mRuedas
        End Get
    End Property
End Class

Public Class cTriciclo
    Inherits cVehiculo
    '
    Public Overrides ReadOnly Property Ruedas() As Integer
        Get
            mRuedas = 3
            Return mRuedas
        End Get
    End Property
End Class
