'------------------------------------------------------------------------------
' Cap�tulo 7 (p�gs. 160 y 161)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim o1 As New cDerivada()
        '
        o1.Nombre = "Clase derivada de cBase1"
        '
        Console.WriteLine("o1.Nombre = {0}", o1.Nombre)
        '
        Console.ReadLine()
    End Sub
End Module

Friend Class cBase
    Public ID As String
    Public Nombre As String
End Class

Friend Class cDerivada
    Inherits cBase
End Class
