'------------------------------------------------------------------------------
' Cap�tulo 7 (p�gs. 162 y 163)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim o1 As New cBase2()
        Console.WriteLine("o1.Nombre = {0}, o1.ID = No accesible", o1.Nombre)
        '
        Dim o2 As New cDerivada2()
        o2.ID2 = "Hola"
        Console.WriteLine("o2.Nombre = {0}, o2.ID = {1}", o2.Nombre, o2.ID2)
        '
        Console.ReadLine()
    End Sub
End Module

Public Class cBase2
    Private mNombre As String = "cBase2"
    Private mID As String = "cBase2ID"
    '
    Public Property Nombre() As String
        Get
            Return mNombre
        End Get
        Set(ByVal Value As String)
            If Value <> "" Then
                mNombre = Value
            End If
        End Set
    End Property
    '
    Protected Property ID() As String
        Get
            Return mID
        End Get
        Set(ByVal Value As String)
            If Value.Length > 0 Then
                mID = Value
            End If
        End Set
    End Property
End Class
Public Class cDerivada2
    Inherits cBase2
    '
    Public Property ID2() As String
        Get
            Return MyBase.ID
        End Get
        Set(ByVal Value As String)
            MyBase.ID = Value
        End Set
    End Property
End Class
