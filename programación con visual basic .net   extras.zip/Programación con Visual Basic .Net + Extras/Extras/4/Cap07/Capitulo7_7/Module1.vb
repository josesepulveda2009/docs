'------------------------------------------------------------------------------
' Cap�tulo 7 (p�g. 172)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim oBici As cBicicleta
        Console.WriteLine("Antes de crear el objeto oBici")
        oBici = New cBicicleta()
        Console.WriteLine("Despu�s de crear el objeto oBici")
        Console.WriteLine("Ruedas de una bicicleta = {0}", oBici.Ruedas)
        '
        Console.WriteLine()
        '
        Console.WriteLine("Antes de declarar/crear el objeto oTriciclo")
        Console.WriteLine("Declaramos el objeto con: Dim oTriciclo As New cTriciclo()")
        Dim oTriciclo As New cTriciclo()
        Console.WriteLine("Despu�s de declarar/crear el objeto oTriciclo")
        Console.WriteLine("Ruedas de un triciclo = {0}", oTriciclo.Ruedas)
        '
        Console.ReadLine()
    End Sub
End Module

Public Class cVehiculo
    Private mRuedas As Integer
    '
    Public Overridable ReadOnly Property Ruedas() As Integer
        Get
            Return mRuedas
        End Get
    End Property
    Sub New(ByVal NumRuedas As Integer)
        Console.WriteLine("Se crea un objeto del tipo cVehiculo")
        mRuedas = NumRuedas
    End Sub
End Class

Public Class cBicicleta
    Inherits cVehiculo
    '
    Sub New()
        MyBase.New(2)
        Console.WriteLine("Se crea un objeto del tipo cBicicleta")
    End Sub
End Class

Public Class cTriciclo
    Inherits cVehiculo
    '
    Sub New()
        MyBase.New(3)
        Console.WriteLine("Se crea un objeto del tipo cTriciclo")
    End Sub
End Class
