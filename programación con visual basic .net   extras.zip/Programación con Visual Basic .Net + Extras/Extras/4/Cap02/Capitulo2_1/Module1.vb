'--------------------------------------------------------------------
' Cap�tulo 2 (p�g. 66 / 68 y 69)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
Module Module1
    Sub Main()
        Console.WriteLine("hola mundo")
        Console.ReadLine()
    End Sub
End Module
