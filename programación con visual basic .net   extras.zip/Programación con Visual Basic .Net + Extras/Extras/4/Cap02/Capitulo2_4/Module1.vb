'--------------------------------------------------------------------
' Cap�tulo 2 (p�gs. 72 y 73)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1
    Dim Nombre As String

    Sub Main()
        Console.Write("Escriba su nombre ")
        ' Leemos de la consola y lo asignamos a la variable Nombre
        Nombre = Console.ReadLine()
        ' Mostramos el saludo
        MostrarSaludo()
        ' Esperamos a que se pulse Intro
        EsperarIntro()
    End Sub

    Sub MostrarSaludo()
        Console.WriteLine("Hola " & Nombre)
    End Sub

    Sub EsperarIntro()
        Console.WriteLine("Pulse Intro")
        Console.ReadLine()
    End Sub
End Module
