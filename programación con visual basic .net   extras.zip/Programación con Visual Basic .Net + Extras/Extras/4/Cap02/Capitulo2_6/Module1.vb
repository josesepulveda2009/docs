'--------------------------------------------------------------------
' Cap�tulo 2 (p�gs. 76 y 77 / 78)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1
    Sub Main()
        Dim Nombre As String

        Console.Write("Escriba su nombre ")
        ' Leemos de la consola y lo asignamos a la variable Nombre
        Nombre = Console.ReadLine()
        ' Mostramos el tipo de saludo y el nombre
        MostrarSaludo2("Hola", Nombre)
        ' Mostramos el contenido de la variable Nombre:
        Console.WriteLine("El contenido de Nombre es: " & Nombre)
        ' Esperamos a que se pulse Intro
        EsperarIntro()
    End Sub

    Sub MostrarSaludo2(ByVal TipoSaludo As String, ByVal Nombre As String)
        Console.WriteLine(TipoSaludo & " " & Nombre)
        ' Cambiamos el contenido de la variable Nombre:
        Nombre = "Contenido nuevo asignado en Sub MostrarSaludo2"
    End Sub

    Sub EsperarIntro()
        Console.WriteLine("Pulse Intro")
        Console.ReadLine()
    End Sub
End Module
