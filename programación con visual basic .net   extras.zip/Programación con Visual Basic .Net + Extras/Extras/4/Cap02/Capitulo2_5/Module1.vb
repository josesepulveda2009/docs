'--------------------------------------------------------------------
' Cap�tulo 2 (p�g. 74)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1

    Sub Main()
        Dim Nombre As String

        Console.Write("Escriba su nombre ")
        ' Leemos de la consola y lo asignamos a la variable Nombre
        Nombre = Console.ReadLine()
        ' Mostramos el saludo
        MostrarSaludo(Nombre)
        ' Esperamos a que se pulse Intro
        EsperarIntro()
    End Sub

    Sub MostrarSaludo(ByVal Saludo As String)
        Console.WriteLine("Hola " & Saludo)
    End Sub

    Sub EsperarIntro()
        Console.WriteLine("Pulse Intro")
        Console.ReadLine()
    End Sub

End Module
