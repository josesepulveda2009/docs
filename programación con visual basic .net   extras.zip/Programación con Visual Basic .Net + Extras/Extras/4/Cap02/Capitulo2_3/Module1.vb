'--------------------------------------------------------------------
' Cap�tulo 2 (p�g. 70 / 71)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

' Pedir el nombre del usuario y mostrar un saludo
Module Module1
    Sub Main()
        Dim Nombre As String

        Console.Write("Escriba su nombre ")
        Nombre = Console.ReadLine()
        Console.WriteLine("Hola " & Nombre)
        Console.ReadLine()
    End Sub
End Module
