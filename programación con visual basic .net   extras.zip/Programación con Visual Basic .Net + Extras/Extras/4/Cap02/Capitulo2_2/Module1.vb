'--------------------------------------------------------------------
' Cap�tulo 2 (p�gs. 69 y 70)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1
    Sub Main()
        Dim Nombre As String
        Nombre = Console.ReadLine()
        Console.WriteLine("Hola " & Nombre)
        Console.ReadLine()
    End Sub
End Module
