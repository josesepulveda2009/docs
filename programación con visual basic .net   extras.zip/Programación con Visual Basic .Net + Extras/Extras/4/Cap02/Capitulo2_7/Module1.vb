'--------------------------------------------------------------------
' Cap�tulo 2 (p�g. 79)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1
    Sub Main()
        Dim Nombre As String
        Dim Saludo As String

        Console.Write("Escriba su nombre ")
        ' Leemos de la consola y lo asignamos a la variable Nombre
        Nombre = Console.ReadLine()
        ' Mostramos el tipo de saludo y el nombre
        Saludo = MostrarSaludo3("Hola", Nombre)
        ' Mostramos el contenido de la variable Saludo:
        Console.WriteLine(Saludo)
        ' Esperamos a que se pulse Intro
        EsperarIntro()
    End Sub

    Function MostrarSaludo3(ByVal elSaludo As String, ByVal elNombre As String) 'As String
        Return elSaludo & " " & elNombre
        'MostrarSaludo3 = elSaludo & " " & elNombre
    End Function

    Sub EsperarIntro()
        Console.WriteLine("Pulse Intro")
        Console.ReadLine()
    End Sub
End Module
