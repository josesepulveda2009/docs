'------------------------------------------------------------------------------
' Cap�tulo 5 (p�g. 130)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim i As Integer
        '
        Console.Write("Introduzca un n�mero ")
        Try
            i = CInt(Console.ReadLine)
        Catch
            Console.WriteLine("Se ha producido un error.")
        End Try
        Console.WriteLine("El n�mero introducido es: {0}", i)
        '
        ' Esperar a que se pulse Intro
        Console.WriteLine("{0}Pulse Intro para terminar.", vbCrLf)
        Console.ReadLine()
    End Sub
End Module
