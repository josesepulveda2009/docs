'------------------------------------------------------------------------------
' Cap�tulo 5 (p�gs. 139 y 140)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim i As Integer
        '
        Console.Write("Escriba un n�mero (0, 1 u otro valor) ")
        Try
            i = CInt(Console.ReadLine)
        Catch
            i = 0
        End Try
        '
        Try
            ProduceError(i)
        Catch e As System.ArgumentException
            Console.WriteLine("El error producido es: {0}", e.Message)
        Catch e As System.OverflowException
            Console.WriteLine("El error producido es: {0}", e.Message)
        End Try
        '
        Console.ReadLine()
    End Sub
    '
    Sub ProduceError(ByVal Tipo As Integer)
        ' Este procedimiento producir� un error
        '
        Select Case Tipo
            Case 0
                ' Cuando es cero, asignamos un error espec�fico
                Throw New System.ArgumentException()
            Case 1
                ' Cuando es uno, asignamos un error de tipo Overflow
                Throw New System.OverflowException()
            Case Else
                ' Cuando es otro valor, 
                ' producimos un error de divisi�n por cero
                Tipo = Tipo \ 0
                ' La siguiente l�nea nunca se ejecutar�
                Console.WriteLine("Despu�s de dividir por cero")
        End Select
    End Sub
End Module
