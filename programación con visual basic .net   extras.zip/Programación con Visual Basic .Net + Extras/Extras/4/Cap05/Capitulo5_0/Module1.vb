'------------------------------------------------------------------------------
' Cap�tulo 5 (p�g. 129)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------

Module Module1
    Sub Main()
        Dim i As Integer
        '
        Console.Write("Introduzca un n�mero ")
        i = CInt(Console.ReadLine)
        Console.WriteLine("El n�mero introducido es: {0}", i)
        '
        ' Esperar a que se pulse Intro
        Console.WriteLine("{0}Pulse intro para terminar.", vbCrLf)
        Console.ReadLine()
    End Sub
End Module
