'------------------------------------------------------------------------------
' Cap�tulo 5 (p�gs. 135 y 136)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Try
            ProduceError()
        Catch e As Exception
            Console.WriteLine("El error producido es: {0}", e.Message)
        End Try
        '
        Console.ReadLine()
    End Sub
    '
    Sub ProduceError()
        ' Este procedimiento producir� un error
        '
        ' Creamos un nuevo error y lo lanzamos
        Throw New Exception("Error en ProduceError")
    End Sub
End Module
