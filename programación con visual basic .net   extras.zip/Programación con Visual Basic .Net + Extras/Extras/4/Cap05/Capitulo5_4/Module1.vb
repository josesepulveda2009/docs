'------------------------------------------------------------------------------
' Cap�tulo 5 (p�g. 132)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim i As Integer
        '
        Console.Write("Introduzca un n�mero ")
        Try
            i = CInt(Console.ReadLine)
            Console.WriteLine("El n�mero introducido es: {0}", i)
        Catch e As Exception
            Console.WriteLine("Error gen�rico.{0}{1}", vbCrLf, e.Message)
        Catch e As System.InvalidCastException
            Console.WriteLine("Se esperaba un n�mero.{0}{1}", vbCrLf, e.Message)
        Catch e As System.OverflowException ' o ArithmeticException
            Console.WriteLine("El n�mero introducido es demasiado grande (Overflow){0}{1}", vbCrLf, e.Message)
        End Try
        '
        ' Esperar a que se pulse Intro
        Console.WriteLine("{0}Pulse Intro para terminar.", vbCrLf)
        Console.ReadLine()
    End Sub
End Module
