'------------------------------------------------------------------------------
' Cap�tulo 6 (p�gs. 149 y 150)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim o4 As New cPrueba4()
        o4.Nombre = "Prueba4"
        Console.WriteLine("o4.Nombre = {0}, o4.FechaCreaci�n = {1}", _
                o4.Nombre, o4.FechaCreaci�n)
        ' Asignamos una cadena vac�a a la propiedad nombre
        o4.Nombre = ""
        ' pero no se anula el valor anterior
        Console.WriteLine("Despu�s de hacer o4.Nombre = ''")
        Console.WriteLine("o4.Nombre = {0}, o4.FechaCreaci�n = {1}", _
                o4.Nombre, o4.FechaCreaci�n)
        '
        Console.ReadLine()
    End Sub
End Module

Friend Class cPrueba4
    ' Declaramos una variable con la fecha actual
    Private mFecha As Date = Now
    Private mNombre As String
    '
    Public ReadOnly Property FechaCreaci�n() As Date
        Get
            Return mFecha
        End Get
    End Property
    '
    Public Property Nombre() As String
        Get
            Return mNombre
        End Get
        Set(ByVal Value As String)
            ' S�lo aceptamos nombres que tengan un valor
            If Value <> "" Then
                mNombre = Value
            End If
        End Set
    End Property
End Class
