'------------------------------------------------------------------------------
' Cap�tulo 6 (p�g. 154)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim o1 As New cPrueba6()
        Console.WriteLine("o1.Nombre = {0}", o1.Nombre)
        '
        Dim o2 As New Prueba6.cPrueba6()
        Console.WriteLine("o2.Nombre = {0}, o2.Nombre2 = {1}", o2.Nombre, o2.Nombre2)
        '
        Console.ReadLine()
    End Sub
End Module
'
Friend Class cPrueba6
    Public Function Nombre() As String
        Return "cPrueba6"
    End Function
End Class
'
Namespace Prueba6
    Friend Class cPrueba6
        Public Function Nombre() As String
            Return "Prueba6.cPrueba6"
        End Function
        Public Function Nombre2() As String
            ' Para poder acceder a la otra clase,
            ' hay que indicar el nombre completo
            Dim o6 As New Capitulo6_6.cPrueba6()
            Return o6.Nombre
        End Function
    End Class
End Namespace
