'------------------------------------------------------------------------------
' Cap�tulo 6 (p�gs. 156 y 157)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim o1 As New cPrueba8()
        Console.WriteLine("o1.Nombre = {0}, o1.Nombre2 = {1}", o1.Nombre, o1.Nombre2)
        Console.WriteLine("o1.Nombre3 = {0}", o1.Nombre3)
        '
        ' Esto dar�a error ya que cPrueba81 no es accesible
        'Dim o2 As New cPrueba8.cPrueba81()
        '
        Console.ReadLine()
    End Sub
End Module

Friend Class cPrueba8
    ' Esta variable s�lo ser� accesible en la clase cPrueba8
    Private Valor As Integer = 15
    '
    Public Function Nombre() As String
        Return "cPrueba8"
    End Function
    Public Function Nombre2() As String
        Dim o81 As New cPrueba81()
        Return o81.Nombre
    End Function
    Public Function Nombre3() As String
        Dim o811 As New cPrueba81.cPrueba811()
        Return o811.Nombre
    End Function
    '
    ' Esta clase s�lo es accesible dentro de cPrueba8
    Private Class cPrueba81
        Public Function Nombre() As String
            Return "cPrueba8.cPrueba81"
        End Function
        Public Function Nombre2() As String
            Dim o811 As New cPrueba811()
            Return o811.Nombre
        End Function
        '
        ' Esta clase s�lo es accesible dentro de cPrueba8 y cPrueba81
        Public Class cPrueba811
            Friend Function Nombre() As String
                Return "cPrueba8.cPrueba81.cPrueba811"
            End Function
        End Class
    End Class
End Class
