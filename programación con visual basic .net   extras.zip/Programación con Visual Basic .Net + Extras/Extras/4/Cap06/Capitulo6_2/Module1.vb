'------------------------------------------------------------------------------
' Cap�tulo 6 (p�g. 146)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim i1 As Integer
        Dim i2 As Integer
        i1 = 15
        i2 = i1
        i1 = 17
        Console.WriteLine("i1 = {0}, i2 = {1}", i1, i2)
        '
        Console.WriteLine()
        '
        Dim o1 As Prueba2
        Dim o2 As Prueba2
        o1 = New Prueba2()
        o2 = New Prueba2()
        o1.Valor = 100
        o2 = o1
        o1.Valor = 200
        Console.WriteLine("o1.Valor = {0}, o2.Valor = {1}", o1.Valor, o2.Valor)
        '
        Console.ReadLine()
    End Sub
End Module

Class Prueba2
    Public Valor As Integer
End Class
