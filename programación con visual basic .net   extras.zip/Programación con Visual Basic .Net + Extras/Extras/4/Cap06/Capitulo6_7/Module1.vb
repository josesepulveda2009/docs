'------------------------------------------------------------------------------
' Cap�tulo 6 (p�gs. 155 y 156)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim o1 As New cPrueba7()
        Dim o2 As New cPrueba7.cPrueba71()
        Console.WriteLine("o1.Nombre = {0}, o2.Nombre = {1}", o1.Nombre, o2.Nombre)
        '
        Dim o3 As New Prueba7.cPrueba7()
        Dim o4 As New Prueba7.cPrueba7.cPrueba71()
        Console.WriteLine("o3.Nombre = {0}, o4.Nombre = {1}", o3.Nombre, o4.Nombre)
        '
        Console.ReadLine()
    End Sub
End Module

Friend Class cPrueba7
    Public Function Nombre() As String
        Return "cPrueba7"
    End Function
    Friend Class cPrueba71
        Public Function Nombre() As String
            Return "cPrueba7.cPrueba71"
        End Function
    End Class
End Class

Namespace Prueba7
    Friend Class cPrueba7
        Public Function Nombre() As String
            Return "Prueba7.cPrueba7"
        End Function
        Friend Class cPrueba71
            Public Function Nombre() As String
                Return "Prueba7.cPrueba7.cPrueba71"
            End Function
        End Class
    End Class
End Namespace
