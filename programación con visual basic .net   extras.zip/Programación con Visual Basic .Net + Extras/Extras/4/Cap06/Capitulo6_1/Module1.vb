'------------------------------------------------------------------------------
' Cap�tulo 6 (p�g. 145)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim oSaludo As Prueba1
        oSaludo = New Prueba1()
        '
        oSaludo.Saludo()
        '
        Console.ReadLine()
    End Sub
End Module

Class Prueba1
    Sub Saludo()
        Console.WriteLine("Saludo desde la clase Prueba1.")
    End Sub
End Class
