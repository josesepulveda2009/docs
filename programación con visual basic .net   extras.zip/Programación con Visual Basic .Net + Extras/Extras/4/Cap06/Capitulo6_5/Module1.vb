'------------------------------------------------------------------------------
' Cap�tulo 6 (p�g. 153)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim o1 As cPrueba5
        o1 = New cPrueba5()
        Console.WriteLine("o1.Nombre = {0}", o1.Nombre)
        '
        Dim o2 As Prueba5.cPrueba5
        o2 = New Prueba5.cPrueba5()
        Console.WriteLine("o2.Nombre = {0}", o2.Nombre)
        '
        Console.ReadLine()
    End Sub
End Module
'
Friend Class cPrueba5
    Public Function Nombre() As String
        Return "cPrueba5"
    End Function
End Class
'
Namespace Prueba5
    Friend Class cPrueba5
        Public Function Nombre() As String
            Return "Prueba5.cPrueba5"
        End Function
    End Class
End Namespace
