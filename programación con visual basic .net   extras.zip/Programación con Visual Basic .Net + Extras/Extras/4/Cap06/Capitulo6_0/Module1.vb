'------------------------------------------------------------------------------
' Cap�tulo 6 (p�g. 143)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim i As Integer = 150
        Dim s As String = "una cadena"
        Dim b As Boolean = True
        Dim e As Exception = New Exception("Exception")
        '
        UsaToString(i)
        UsaToString(s)
        UsaToString(b)
        UsaToString(e)
        '
        Console.ReadLine()
    End Sub
    '
    Sub UsaToString(ByVal unObjeto As Object)
        Console.WriteLine("unObjeto.ToString = {0}", unObjeto.ToString)
    End Sub
End Module
