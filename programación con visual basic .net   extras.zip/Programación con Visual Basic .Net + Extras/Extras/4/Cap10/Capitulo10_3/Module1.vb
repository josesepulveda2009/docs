'------------------------------------------------------------------------------
' Cap�tulo 10 (p�g. 224)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim oAnimal As New cAnimal()
        Dim s As String
        '
        Select Case oAnimal.ClaseAnimal
            Case cAnimal.eClases.Aves
                s = "Aves"
            Case cAnimal.eClases.Mam�feros
                s = "Mam�feros"
            Case cAnimal.eClases.Reptiles
                s = "Reptiles"
            Case Else
                s = "no tiene asignado a un valor correcto."
        End Select
        Console.WriteLine("La clase del objeto oAnimal es: {0}", s)
        '
        'oAnimal.ClaseAnimal = 25
        '



        'oAnimal.ClaseAnimal=cAnimal.eClases.Aves 







        Console.ReadLine()
    End Sub
End Module

Class cAnimal
    Enum eClases
        Aves = 1
        Mam�feros
        Reptiles
    End Enum
    Private mClase As eClases
    Public Property ClaseAnimal() As eClases
        Get
            Return mClase
        End Get
        Set(ByVal Value As eClases)
            mClase = Value
        End Set
    End Property
End Class
