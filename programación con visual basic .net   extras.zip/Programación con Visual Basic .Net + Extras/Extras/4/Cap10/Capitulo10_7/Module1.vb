'------------------------------------------------------------------------------
' Cap�tulo 10 (p�gs. 233 y 234)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Utilidades
    Public Sub EsperarIntro()
        Console.WriteLine("Pulse Intro para continuar.")
        Console.ReadLine()
    End Sub
    '
    Enum eTipoColega
        Amigo
        Conocido
    End Enum

    Structure Colega
        Public Nombre As String
        Public TipoColega As eTipoColega
        Public Shared eMail As String
        '
        Sub New(ByVal Nombre As String)
            Me.Nombre = Nombre
        End Sub
        Sub New(ByVal Nombre As String, _
                ByVal eMail As String)
            Me.Nombre = Nombre
            Me.eMail = eMail
        End Sub
        Sub New(ByVal Nombre As String, _
                ByVal TipoColega As eTipoColega)
            Me.Nombre = Nombre
            Me.TipoColega = TipoColega
        End Sub
        Sub New(ByVal Nombre As String, _
                ByVal eMail As String, _
                ByVal TipoColega As eTipoColega)
            Me.Nombre = Nombre
            Me.eMail = eMail
            Me.TipoColega = TipoColega
        End Sub
    End Structure
    '
    Public Sub MostrarColega(ByVal queColega As Colega)
        With queColega
            Console.WriteLine("Datos del colega:")
            Console.WriteLine("Nombre= {0}", .Nombre)
            Console.WriteLine("eMail = {0}", .eMail)
            Console.WriteLine("Tipo  = {0}", .TipoColega.ToString)
            Console.WriteLine()
        End With
    End Sub
End Module

Module Module1
    Sub Main()
        Dim unColega As New Colega( _
                "Guillermo", _
                "guille@costasol.net", _
                Utilidades.eTipoColega.Conocido)
        MostrarColega(unColega)
        '
        EsperarIntro()
    End Sub
End Module

