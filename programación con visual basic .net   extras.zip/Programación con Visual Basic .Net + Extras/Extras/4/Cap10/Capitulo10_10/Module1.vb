'------------------------------------------------------------------------------
' Cap�tulo 10 (p�gs. 238)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Public Class PruebaShared
    Private Shared Contador As Integer
    Private mNombre As String = "PruebaShared"
    Public Sub MostrarDatos()
        Console.WriteLine("ID: {0}, Nombre: {1}", ID, mNombre)
    End Sub
    Public Sub New()
        Contador = Contador + 1
    End Sub
    Public Sub New(ByVal Nombre As String)
        Me.New()
        mNombre = Nombre
    End Sub
    Public ReadOnly Property ID() As String
        Get
            Return "ID" & Contador.ToString("0000")
        End Get
    End Property
    Public Property Nombre() As String
        Get
            Return mNombre
        End Get
        Set(ByVal Value As String)
            mNombre = Value
        End Set
    End Property
End Class
Module Module1
    Sub Main()
        Dim oPrueba As New PruebaShared()
        oPrueba.Nombre = "oPrueba"
        Dim oPrueba2 As New PruebaShared()
        oPrueba2.Nombre = "oPrueba2"
        Dim oPrueba3 As New PruebaShared("oPrueba3")
        '
        Console.Write("oPrueba3.MostrarDatos: ")
        oPrueba3.MostrarDatos()
        Console.Write("oPrueba2.MostrarDatos: ")
        oPrueba2.MostrarDatos()
        Console.Write("oPrueba.MostrarDatos: ")
        oPrueba.MostrarDatos()
        '
        Console.ReadLine()
    End Sub
End Module
