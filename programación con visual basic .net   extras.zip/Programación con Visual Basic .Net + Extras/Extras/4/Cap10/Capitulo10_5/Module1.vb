'------------------------------------------------------------------------------
' Cap�tulo 10 (p�gs. 228 y 229)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Interface IColega
    Property A�oNacimiento() As Integer
    Property Nombre() As String
End Interface

Structure Colega
    Implements IColega
    Private mA�oNacimiento As Integer
    Private mNombre As String
    Public eMail As String
    Property A�oNacimiento() As Integer _
                Implements IColega.A�oNacimiento
        Get
            Return mA�oNacimiento
        End Get
        Set(ByVal Value As Integer)
            mA�oNacimiento = Value
        End Set
    End Property
    Property Nombre() As String _
                Implements IColega.Nombre
        Get
            Return mNombre
        End Get
        Set(ByVal Value As String)
            mNombre = Value
        End Set
    End Property
End Structure

Module Module1
    Sub Main()
        Dim unColega As Colega
        Dim oColega As IColega
        '
        unColega.Nombre = "Guille"
        Console.WriteLine("unColega.Nombre = {0}", unColega.Nombre)
        oColega = unColega
        oColega.Nombre = "Juan"
        Console.WriteLine("oColega.Nombre = {0}", oColega.Nombre)
        Console.WriteLine("unColega.Nombre = {0}", unColega.Nombre)
        '
        Console.WriteLine()
        '
        Dim otro As Colega
        otro = unColega
        otro.Nombre = "Pepe"
        '
        Console.WriteLine("otro.Nombre = {0}", otro.Nombre)
        Console.WriteLine("unColega.Nombre = {0}", unColega.Nombre)
        '
        Console.ReadLine()
    End Sub
End Module
