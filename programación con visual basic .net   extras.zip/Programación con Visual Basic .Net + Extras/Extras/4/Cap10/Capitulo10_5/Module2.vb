'------------------------------------------------------------------------------
' Cap�tulo 10 (p�g. 227)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------

Namespace Prueba2

    Structure Colega
        Public A�oNacimiento As Integer
        Public Nombre As String
        Public eMail As String
    End Structure

    Module Module1
        Sub Main()
            Dim unColega As Colega
            unColega.Nombre = "Guillermo"
            Console.WriteLine("unColega.Nombre = {0}", unColega.Nombre)
            '
            Dim otro As Colega
            otro = unColega
            unColega.Nombre = "Pepe"
            Console.WriteLine("unColega.Nombre = {0}", unColega.Nombre)
            Console.WriteLine("otro.Nombre = {0}", otro.Nombre)
            '
            Console.ReadLine()
        End Sub
    End Module

End Namespace