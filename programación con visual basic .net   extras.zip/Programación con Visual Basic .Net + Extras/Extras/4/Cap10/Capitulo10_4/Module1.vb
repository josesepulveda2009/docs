'------------------------------------------------------------------------------
' Cap�tulo 10 (p�gs. 225 y 226)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim oAnimal As New cAnimal()
        Dim s As String
        '
        oAnimal.ClaseAnimal = cAnimal.eClases.Mam�feros
        Console.WriteLine("La clase del objeto oAnimal es: {0}", oAnimal.ClaseAnimal)
        '
        's = oAnimal.ClaseAnimal
        s = CStr(oAnimal.ClaseAnimal)
        Console.WriteLine("La clase del objeto oAnimal es: {0}", s)
        '
        s = oAnimal.ClaseAnimal.ToString
        Console.WriteLine("oAnimal.ClaseAnimal.ToString = {0}", s)
        '
        Console.WriteLine("oAnimal.ToString = {0}", oAnimal.ToString)
        '
        Console.WriteLine("{0}", cAnimal.eClases.Aves.ToString)
        '
        Console.WriteLine()
        Select Case oAnimal.ClaseAnimal
            Case cAnimal.eClases.Aves
                s = CStr(cAnimal.eClases.Aves)
                s = cAnimal.eClases.Aves.ToString
            Case cAnimal.eClases.Mam�feros
                s = CStr(cAnimal.eClases.Mam�feros)
                s = cAnimal.eClases.Mam�feros.ToString
            Case cAnimal.eClases.Reptiles
                s = CStr(cAnimal.eClases.Reptiles)
                s = cAnimal.eClases.Reptiles.ToString
        End Select
        Console.WriteLine("La clase del objeto oAnimal es: {0}", s)
        '
        Console.WriteLine()
        Select Case oAnimal.ClaseAnimal
            Case cAnimal.eClases.Aves
                s = cAnimal.eClases.Aves.GetName(GetType(cAnimal.eClases), cAnimal.eClases.Aves)
            Case cAnimal.eClases.Mam�feros
                s = cAnimal.eClases.Mam�feros.GetName(GetType(cAnimal.eClases), cAnimal.eClases.Mam�feros)
            Case cAnimal.eClases.Reptiles
                s = cAnimal.eClases.Reptiles.GetName(GetType(cAnimal.eClases), cAnimal.eClases.Reptiles)
        End Select
        Console.WriteLine("La clase del objeto oAnimal es: {0}", s)
        '
        Console.ReadLine()
    End Sub
End Module

Class cAnimal
    Enum eClases
        Aves
        Mam�feros
        Reptiles
    End Enum
    Private mClase As eClases
    Public Property ClaseAnimal() As eClases
        Get
            Return mClase
        End Get
        Set(ByVal Value As eClases)
            mClase = Value
        End Set
    End Property
End Class
