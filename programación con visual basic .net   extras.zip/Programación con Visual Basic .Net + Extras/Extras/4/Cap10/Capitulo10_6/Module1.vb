'------------------------------------------------------------------------------
' Cap�tulo 10 (p�gs. 230 a 232)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Interface IColega
    Property A�oNacimiento() As Integer
    Property Nombre() As String
End Interface

Structure Colega
    Implements IColega
    '
    Enum eTipoColega
        Amigo
        Conocido
    End Enum
    Public TipoColega As eTipoColega
    '
    Private mA�oNacimiento As Integer
    Private mNombre As String
    Public eMail As String
    '
    Public Sub New(ByVal Nombre As String)
        mNombre = Nombre
    End Sub
    Public Property A�oNacimiento() As Integer Implements IColega.A�oNacimiento
        Get
            Return mA�oNacimiento
        End Get
        Set(ByVal Value As Integer)
            mA�oNacimiento = Value
        End Set
    End Property
    Public Property Nombre() As String Implements IColega.Nombre
        Get
            Return mNombre
        End Get
        Set(ByVal Value As String)
            mNombre = Value
        End Set
    End Property
End Structure

Module Module1
    Sub Main()
        Dim unColega As Colega
        Dim oColega As IColega
        '
        unColega.Nombre = "Guille"
        Console.WriteLine("unColega.Nombre = {0}", unColega.Nombre)
        oColega = unColega
        Console.WriteLine("oColega.Nombre = {0}", oColega.Nombre)
        '
        Console.WriteLine()
        '
        Dim otroColega As Colega
        otroColega = unColega
        otroColega.Nombre = "Pepe"
        '
        Console.WriteLine("otroColega.Nombre = {0}", otroColega.Nombre)
        Console.WriteLine("unColega.Nombre = {0}", unColega.Nombre)
        '
        Console.WriteLine()
        '
        Dim Colega3 As New Colega("Miguel")
        Console.WriteLine("Colega3.Nombre = {0}", Colega3.Nombre)
        '
        Dim Colega4 As New Colega()
        Console.WriteLine("Colega4.Nombre = {0}", Colega4.Nombre)
        '
        Console.WriteLine()
        '
        Dim Colega5 As New Colega("Juan")
        Colega5.TipoColega = Colega.eTipoColega.Conocido
        '
        With Colega5
            .TipoColega = Colega.eTipoColega.Conocido
            Console.WriteLine("Colega5.Nombre = {0}, .TipoColega = {1}", _
                    .Nombre, .TipoColega.ToString)
        End With
        '
        Console.WriteLine()
        '
        Dim Colegas(5) As Colega
        Colegas(0) = unColega
        Colegas(1).Nombre = "Antonio"
        '
        Console.WriteLine()
        '
        Dim Colegas2() As Colega = { _
                    unColega, _
                    New Colega("Eduardo"), _
                    New Colega()}
        Dim i As Integer
        For i = 0 To Colegas2.Length - 1
            Console.WriteLine("�ndice = {0,4} Nombre = {1}", i, Colegas2(i).Nombre)
        Next
        '
        Console.ReadLine()
    End Sub
End Module
