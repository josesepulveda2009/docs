'------------------------------------------------------------------------------
' Cap�tulo 10 (p�gs. 220 a 222)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On



Enum eSiNo As Byte
    No
    Si
End Enum




Enum eSiNo2
    No = 1
    Si
End Enum

Enum eRGB
    Rojo = 8
    Verde = 16
    Azul = 32
End Enum

'Enum eRGB As Byte
'    Rojo = 8
'    Verde = 16
'    Azul = 32
'End Enum

'Enum eSiNo As Byte
'    No
'    Si
'End Enum


Module Module1
    Sub Main()
        Dim Resultado As eSiNo
        Resultado = eSiNo.Si
        '
        Console.WriteLine("El valor de Resultado es: {0}, CInt(Resultado) = {1}", Resultado, CInt(Resultado))
        '
        Console.ReadLine()
    End Sub
End Module

Class cAnimal
    Enum eClases
        Aves
        Mam�feros
        Reptiles
    End Enum
    Private mClase As eClases
    Public Property ClaseAnimal() As eClases
        Get
            Return mClase
        End Get
        Set(ByVal Value As eClases)
            mClase = Value
        End Set
    End Property
End Class
