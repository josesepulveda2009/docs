'------------------------------------------------------------------------------
' Cap�tulo 10 (p�gs. 234 a 236)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Public Class PruebaShared
    Private Shared mNombre As String = "PruebaShared"
    Public Shared Sub MostrarDatos()
        Console.WriteLine("Nombre: {0}", mNombre)
    End Sub
    Public Property Nombre() As String
        Get
            Return mNombre
        End Get
        Set(ByVal Value As String)
            mNombre = Value
        End Set
    End Property
End Class
Module Module1
    Sub Main()
        PruebaShared.MostrarDatos()
        '
        Dim oPrueba As New PruebaShared()
        oPrueba.Nombre = "oPrueba"
        oPrueba.MostrarDatos()
        PruebaShared.MostrarDatos()
        '
        Console.WriteLine()
        '
        Dim oPrueba2 As New PruebaShared()
        oPrueba2.Nombre = "oPrueba2"
        Console.Write("oPrueba2.MostrarDatos: ")
        oPrueba2.MostrarDatos()
        Console.Write("oPrueba.MostrarDatos: ")
        oPrueba.MostrarDatos()
        '
        Console.ReadLine()
    End Sub
End Module
