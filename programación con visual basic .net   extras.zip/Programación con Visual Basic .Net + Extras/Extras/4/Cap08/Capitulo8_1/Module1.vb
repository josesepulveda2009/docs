'------------------------------------------------------------------------------
' Cap�tulo 8 (p�gs. 177 y 178)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        Dim oBase As New cBase()
        oBase.Nombre = "Guillermo Som"
        oBase.FechaNacimiento = #6/7/1957#
        Console.WriteLine("Los datos de oBase:{0}", vbCrLf)
        oBase.MostrarDatos()
        oBase.MostrarDatos(0)
        oBase.MostrarDatos(1)
        '
        Console.WriteLine()
        '
        Dim oDerivada As New cDerivada()
        With oDerivada
            .Nombre = "David"
            .FechaNacimiento = #11/16/1979 1:15:00 PM#
            Console.WriteLine("Los datos de oDerivada:{0}", vbCrLf)
            .MostrarDatos()
            .MostrarDatos(0)
            .MostrarDatos(1)
            .MostrarDatos("dd/MM/yyyy")
        End With
        '
        Console.ReadLine()
    End Sub
End Module

Public Class cBase
    Public Nombre As String
    Public FechaNacimiento As Date
    '
    Public Sub MostrarDatos()
        Console.WriteLine("          Nombre: {0}", Nombre)
        Console.WriteLine("Fecha Nacimiento: {0}", FechaNacimiento)
        Console.WriteLine()
    End Sub
    Public Sub MostrarDatos(ByVal DatoAMostrar As Integer)
        Select Case DatoAMostrar
            Case 0
                Console.WriteLine("          Nombre: {0}", Nombre)
            Case 1
                Console.WriteLine("Fecha Nacimiento: {0}", FechaNacimiento)
        End Select
        Console.WriteLine()
    End Sub
End Class

Public Class cDerivada
    Inherits cBase
    '
    Public Overloads Sub MostrarDatos(ByVal FormatoFecha As String)
        Console.WriteLine("          Nombre: {0}", Nombre)
        Console.WriteLine("Fecha Nacimiento: {0}", Format(FechaNacimiento, FormatoFecha))
        Console.WriteLine()
    End Sub
End Class