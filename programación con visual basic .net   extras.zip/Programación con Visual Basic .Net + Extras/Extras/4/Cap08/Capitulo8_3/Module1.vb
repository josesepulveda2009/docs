'------------------------------------------------------------------------------
' Cap�tulo 8 (p�g. 193)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Public Contador As Integer
    '
    Sub Main()
        Dim oBase As New cBase("Guillermo Som", #6/7/1957 8:00:00 AM#)
        oBase.MostrarDatos()
        Console.WriteLine("oBase.ID = {0}", oBase.ID)
        '
        Dim oDerivada As New cDerivada()
        With oDerivada
            .Nombre = "Guillermo"
            .FechaNacimiento = #11/17/1983 1:15:00 AM#
            .MostrarDatos("dd/MM/yyyy")
            Console.WriteLine("oDerivada.ID = {0}", .ID)
        End With
        '
        Dim oDerivada2 As New cDerivada("David", #11/16/1979 1:15:00 PM#)
        oDerivada2.MostrarDatos()
        Console.WriteLine("oDerivada2.ID = {0}", oDerivada2.ID)
        '
        Console.ReadLine()
    End Sub
End Module

Public Class cBase
    Public Nombre As String
    Public FechaNacimiento As Date
    Private mID As String
    '
    Public Sub New()
        Contador += 1
        mID = "ID de cBase: " & Module1.Contador.ToString
        ' Otra forma de hacerlo...
        'mID = "ID" & Format(Module1.Contador, "0000")
    End Sub
    Public Sub New(ByVal NuevoNombre As String)
        Me.New()
        Nombre = NuevoNombre
    End Sub
    Public Sub New(ByVal NuevoNombre As String, ByVal NuevaFechaNacimiento As Date)
        Me.New()
        Nombre = NuevoNombre
        FechaNacimiento = NuevaFechaNacimiento
    End Sub
    '
    Public Overridable ReadOnly Property ID() As String
        Get
            Return mID
        End Get
    End Property
    '
    Public Sub MostrarDatos()
        Console.WriteLine("          Nombre: {0}", Nombre)
        Console.WriteLine("Fecha Nacimiento: {0}", FechaNacimiento)
        Console.WriteLine()
    End Sub
    Public Sub MostrarDatos(ByVal DatoAMostrar As Integer)
        Select Case DatoAMostrar
            Case 0
                Console.WriteLine("          Nombre: {0}", Nombre)
            Case 1
                Console.WriteLine("Fecha Nacimiento: {0}", FechaNacimiento)
        End Select
        Console.WriteLine()
    End Sub
End Class

Public Class cDerivada
    Inherits cBase
    '
    Public Sub New()
        MyBase.New()
    End Sub
    Public Sub New(ByVal NuevoNombre As String)
        MyBase.New(NuevoNombre)
    End Sub
    Public Sub New(ByVal NuevoNombre As String, ByVal NuevaFechaNacimiento As Date)
        MyBase.New(NuevoNombre, NuevaFechaNacimiento)
    End Sub

    Public Overloads Sub MostrarDatos(ByVal FormatoFecha As String)
        Console.WriteLine("          Nombre: {0}", Nombre)
        Console.WriteLine("Fecha Nacimiento: {0}", Format(FechaNacimiento, FormatoFecha))
        Console.WriteLine()
    End Sub
End Class