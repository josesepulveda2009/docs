'------------------------------------------------------------------------------
' Cap�tulo 8 (p�g. 197)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    Sub Main()
        MuchosParametros("Par�metros String", "el segundo", "tercero")
        Console.WriteLine()
        MuchosParametros("Par�metros", 1, 654, 75, 8, 958)
        Console.WriteLine()
        MuchosParametros(4, 75, 8, 958)
        '
        Console.ReadLine()
    End Sub
    '
    Sub MuchosParametros(ByVal ParamArray Parametros() As Object)
        Dim i As Integer
        Console.WriteLine("MuchosParametros de tipo Object")
        For i = 0 To Parametros.Length - 1
            Console.WriteLine("i = {0}, Parametros({0}) = {1}", i, Parametros(i))
        Next
    End Sub
    Sub MuchosParametros(ByVal ParamArray Parametros() As String)
        Dim i As Integer
        Console.WriteLine("MuchosParametros de tipo String")
        For i = 0 To Parametros.Length - 1
            Console.WriteLine("i = {0}, Parametros({0}) = {1}", i, Parametros(i))
        Next
    End Sub
    Sub MuchosParametros(ByVal ParamArray Parametros() As Integer)
        Dim i As Integer
        Console.WriteLine("MuchosParametros de tipo Integer")
        For i = 0 To Parametros.Length - 1
            Console.WriteLine("i = {0}, Parametros({0}) = {1}", i, Parametros(i))
        Next
    End Sub
End Module
