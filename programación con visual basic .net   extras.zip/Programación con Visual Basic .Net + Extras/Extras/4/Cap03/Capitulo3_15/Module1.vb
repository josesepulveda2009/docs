'--------------------------------------------------------------------
' Cap�tulo 3 (p�g. 102)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
Option Strict On
Module Module1

    Sub Main()
        Dim i As Integer
        Dim n As Integer
        '
        Console.Write("Escriba un n�mero ")
        n = CInt(Console.ReadLine)
        '
        For i = 1 To n Step 2
            Console.WriteLine("i vale: " & CStr(i))
        Next
        '
        'For i = n To 1 Step -1
        '    Console.WriteLine("i vale: " & CStr(i))
        'Next
        '
        ' Esperar a que se pulse Intro
        Console.Write("Pulse la tecla Intro para terminar.")
        Console.ReadLine()
    End Sub

End Module
