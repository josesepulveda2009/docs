'--------------------------------------------------------------------
' Cap�tulo 3 (p�gs. 93 y 94)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
'Option Strict On
Module Module1

    Sub Main()
        Dim x As Integer = 10
        Dim j As Integer = 12
        '
        Console.WriteLine("x = {0}, j = {1}", x, j)
        Console.WriteLine()
        Console.WriteLine("x And 7 = {0}", x And 7)
        Console.WriteLine("x Or  7 = {0}", x Or 7)
        Console.WriteLine("x Xor 7 = {0}", x Xor 7)
        Console.WriteLine()
        Console.WriteLine("x AndAlso 7 = {0}", x AndAlso 7)
        Console.WriteLine("x OrElse  7 = {0}", x OrElse 7)
        '
        If x = 10 Then
            If j > 7 Then
                '...
            End If
        End If
        '
        Console.ReadLine()
    End Sub

End Module
