'--------------------------------------------------------------------
' Cap�tulo 3 (p�g. 90)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
'Option Strict On
Module Module1

    Sub Main()
        Dim x As Integer = 10
        Dim j As Integer = 12
        '
        Console.WriteLine("x = {0}, j = {1}", x, j)
        If x = 10 And j > 7 Then
            Console.Write("Si")
        Else
            Console.Write("No")
        End If
        Console.WriteLine(" se cumple esta comparaci�n: If x = 10 And j > 7 Then")
        ' Mostramos el valor resultante de mostrar la expresi�n
        Console.WriteLine("x = 10 And j > 7 = {0}", (x = 10 And j > 7))
        '
        Console.WriteLine()
        '
        If x = 10 AndAlso j > 7 Then
            Console.Write("Si")
        Else
            Console.Write("No")
        End If
        Console.WriteLine(" se cumple esta comparaci�n: If x = 10 AndAlso j > 7 Then")
        Console.WriteLine("x = 10 AndAlso j > 7 = {0}", (x = 10 AndAlso j > 7))
        '
        Console.WriteLine()
        '
        If x = 10 Xor j > 7 Then
            Console.Write("Si")
        Else
            Console.Write("No")
        End If
        Console.WriteLine(" se cumple esta comparaci�n: If x = 10 Xor j > 7 Then")
        Console.WriteLine("x = 10 Xor j > 7 = {0}", (x = 10 Xor j > 7))
        '
        Console.ReadLine()
    End Sub

End Module
