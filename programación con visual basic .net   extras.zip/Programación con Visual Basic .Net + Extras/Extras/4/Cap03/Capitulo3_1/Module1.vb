'--------------------------------------------------------------------
' Cap�tulo 3 (p�g. 85)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1

    Sub Main()
        Dim Nombre As String
        ' Pedir el nombre y almacenarlo en la variable Nombre
        Console.Write("Por favor escriba su nombre ")
        Nombre = Console.ReadLine
        ' Mostrar el saludo
        Console.WriteLine("Hola " & Nombre & ", bienvenido a MI VB.NET")
        ' El c�digo seguir�a aqu�...
        '...
        ' Esperar a que se pulse Intro
        Console.Write("Pulse la tecla Intro para terminar.")
        Console.ReadLine()
    End Sub

End Module
