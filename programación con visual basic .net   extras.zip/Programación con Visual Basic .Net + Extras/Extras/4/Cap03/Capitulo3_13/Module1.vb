'--------------------------------------------------------------------
' Cap�tulo 3 (p�g. 100)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
Option Strict On
Module Module1

    Sub Main()
        Dim i As Integer
        Dim n As Integer
        '
        Console.Write("Escriba un n�mero ")
        n = CInt(Console.ReadLine)

        For i = 1 To n
            Console.WriteLine("i vale: " & CStr(i))
        Next
        '
        ' Esperar a que se pulse Intro
        Console.Write("Pulse la tecla Intro para terminar.")
        Console.ReadLine()
    End Sub

End Module
