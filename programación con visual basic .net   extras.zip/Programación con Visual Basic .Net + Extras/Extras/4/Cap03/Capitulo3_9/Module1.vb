'--------------------------------------------------------------------
' Cap�tulo 3 (p�gs. 95 y 96)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1

    Sub Main()
        Dim Nombre As String
        ' Pedir el nombre y almacenarlo en la variable Nombre
        Console.Write("Por favor escriba su nombre ")
        Nombre = Console.ReadLine
        '
        ' Si el contenido de Nombre es una cadena vac�a,
        ' mostrar un saludo m�s simple.
        Select Case Nombre
            Case "adios", "Adios", "ADIOS"
                ' Mostrar el saludo cuando escribe adios
                Console.WriteLine("Hasta la pr�xima.")
            Case Is <> ""
                ' Mostrar el saludo con el nombre indicado
                Console.WriteLine("Hola " & Nombre & ", bienvenido a MI VB.NET")
            Case Else
                ' Mostrar un saludo simple
                Console.WriteLine("Hola, bienvenido a MI VB.NET")
        End Select
        '
        ' Esperar a que se pulse Intro
        Console.Write("Pulse la tecla Intro para terminar.")
        Console.ReadLine()
    End Sub

End Module
