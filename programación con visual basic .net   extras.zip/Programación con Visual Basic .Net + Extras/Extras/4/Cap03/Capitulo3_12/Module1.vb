'--------------------------------------------------------------------
' Cap�tulo 3 (p�g. 99)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1
    Sub Main()
        Dim i As Integer
        '
        For i = 1 To 10
            Console.WriteLine("i vale: " & CStr(i))
        Next
        '
        ' Esperar a que se pulse Intro
        Console.Write("Pulse la tecla Intro para terminar.")
        Console.ReadLine()
    End Sub
End Module
