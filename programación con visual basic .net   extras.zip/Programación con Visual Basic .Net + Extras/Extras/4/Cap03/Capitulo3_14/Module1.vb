'--------------------------------------------------------------------
' Cap�tulo 3 (p�gs. 100 y 101)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------
Option Strict On
Module Module1
    Sub Main()
        Dim i As Integer
        Dim n As Integer
        '
        Console.Write("Escriba un n�mero ")
        n = CInt(Console.ReadLine)
        '
        ' Bucle desde 1 hasta n usando Do...Loop
        Console.WriteLine("Usando un bucle Do...Loop")
        i = 1
        Do While i <= n
            Console.WriteLine("i vale: " & CStr(i))
            i += 1
        Loop
        '
        ' Bucle desde 1 hasta n usando While...End While
        Console.WriteLine("Usando un bucle While...End While")
        i = 1
        While i <= n
            Console.WriteLine("i vale: " & CStr(i))
            i += 1
        End While
        '
        ' Esperar a que se pulse Intro
        Console.Write("Pulse la tecla Intro para terminar.")
        Console.ReadLine()
    End Sub
End Module
