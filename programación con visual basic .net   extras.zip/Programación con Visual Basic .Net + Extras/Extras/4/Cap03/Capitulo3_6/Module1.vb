'--------------------------------------------------------------------
' Cap�tulo 3 (p�g. 92)
'
' Manual Imprescindible de Visual Basic.NET
'
' �Guillermo 'guille' Som, 2002
'--------------------------------------------------------------------

Module Module1

    Sub Main()
        Dim Nombre As String
        ' Pedir el nombre y almacenarlo en la variable Nombre
        Console.Write("Por favor escriba su nombre ")
        Nombre = Console.ReadLine
        '
        ' Si el contenido de Nombre es una cadena vac�a,
        ' mostrar un saludo m�s simple.
        If Nombre = "adios" Then
            ' Mostrar el saludo cuando escribe adios
            Console.WriteLine("Hasta la pr�xima.")
        Else
            If Nombre = "" Then
                ' Mostrar un saludo simple
                Console.WriteLine("Hola, bienvenido a MI VB.NET")
            Else
                ' Mostrar el saludo con el nombre indicado
                Console.WriteLine("Hola " & Nombre & ", bienvenido a MI VB.NET")
            End If
        End If
        '
        ' Esperar a que se pulse Intro
        Console.Write("Pulse la tecla Intro para terminar.")
        Console.ReadLine()
    End Sub

End Module
