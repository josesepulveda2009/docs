'------------------------------------------------------------------------------
' Listado 13.2
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module2
    '
    Sub Main()
        Dim oColHT As New Hashtable()
        Col_IDictionary(oColHT)
        'Mostrar(oColHT)
        Mostrar1(oColHT.Values)
        '
        'Dim oColSC As New System.Collections.Specialized.StringCollection()
        'Console.WriteLine()
        'Console.WriteLine("Pruebas con una clase del tipo StringCollection")
        'Col_IList(oColSC)
        'Console.WriteLine("El contenido de una colecci�n StringCollection")
        'Mostrar(oColSC)
        ''
        'Dim oColAL As New ArrayList()
        'Console.WriteLine()
        'Console.WriteLine("Pruebas con una clase del tipo ArrayList")
        'Col_IList(oColAL)
        'Console.WriteLine("El contenido de una colecci�n ArrayList")
        'Mostrar(oColAL)
        '
        'Dim s As String = "MI VB.NET"
        'Console.WriteLine()
        'Console.WriteLine("El contenido de un String")
        'Mostrar(s)
        ''
        ''Dim a() As String = {"Manual", "Imprescindible", "de", "VB.NET"}
        'Dim a() As Integer = {1, 13, 45, 22, 99}
        'Console.WriteLine()
        'Console.WriteLine("El contenido de un Array")
        'Mostrar(a)
        ''
        'Dim oColSt As New Stack()
        'Col_Stack(oColSt)
        'Console.WriteLine()
        'Console.WriteLine("El contenido de una colecci�n Stack")
        'Mostrar(oColSt)
        '
        Console.ReadLine()
    End Sub
    '
    Sub Mostrar(ByVal Lista As IEnumerable)
        Dim tEnum As IEnumerator
        tEnum = Lista.GetEnumerator()
        Dim tEntry As DictionaryEntry
        Console.WriteLine()
        While tEnum.MoveNext()
            Try
                tEntry = CType(tEnum.Current, DictionaryEntry)
                Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
            Catch
                Console.WriteLine("Contenido: {0}", tEnum.Current)
            End Try
        End While
        Console.WriteLine()
    End Sub
    Sub Mostrar2(ByVal Lista As IEnumerable)
        Dim tEnum As IEnumerator
        tEnum = Lista.GetEnumerator()
        Dim tEntry As DictionaryEntry
        Dim UsaDictionaryEntry As Boolean
        ' Comprobamos si el tipo de la colecci�n es DictionaryEntry
        tEnum.MoveNext()
        Try
            ' Si no es del tipo DictionaryEntry,
            ' producir� una excepci�n del tipo InvalidCastException.
            tEntry = CType(tEnum.Current, DictionaryEntry)
            ' Si es del tipo DictionaryEntry, seguir� por aqu�
            UsaDictionaryEntry = True
        Catch e As InvalidCastException
            UsaDictionaryEntry = False
        Catch e As Exception
            Console.WriteLine(e.Message)
            Exit Sub
        Finally
            ' En cualquier caso, que empiece por el primer elemento
            tEnum.Reset()
        End Try
        Console.WriteLine()
        While tEnum.MoveNext()
            If UsaDictionaryEntry Then
                tEntry = CType(tEnum.Current, DictionaryEntry)
                Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
            Else
                Console.WriteLine("Contenido: {0}", tEnum.Current)
            End If
        End While
        Console.WriteLine()
    End Sub
    '
    ' P�gina 267
    '
    Sub Mostrar1(ByVal Lista As IEnumerable)
        Dim tEnum As IEnumerator
        tEnum = Lista.GetEnumerator()
        Console.WriteLine()
        While tEnum.MoveNext()
            Console.WriteLine("Contenido: {0}", tEnum.Current)
        End While
        Console.WriteLine()
    End Sub
    'Sub Mostrar(ByVal Lista As IEnumerator)
    '    Console.WriteLine()
    '    While Lista.MoveNext()
    '        Console.WriteLine("Contenido: {0}", Lista.Current)
    '    End While
    '    Console.WriteLine()
    'End Sub
    '
    Sub Col_Stack(ByVal oCol As Stack)
        Dim i As Integer
        Dim s, ID As String
        '
        For i = 1 To 5
            ID = i.ToString("0000")
            oCol.Push(ID)
        Next
        '
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        For Each s In oCol
            Console.WriteLine("Contenido: {0}", s)
        Next
        Console.WriteLine()
        oCol.Pop()
        For Each s In oCol
            Console.WriteLine("Contenido: {0}", s)
        Next
        '
        Console.ReadLine()
    End Sub
    '
    ' Colecciones del tipo IDictionary
    Sub Col_HD()
        Dim oCol As New System.Collections.Specialized.HybridDictionary()
        Col_IDictionary(oCol)
    End Sub
    Sub Col_LD()
        Dim oCol As New System.Collections.Specialized.ListDictionary()
        Col_IDictionary(oCol)
    End Sub
    Sub Col_SL()
        Dim oCol As New SortedList()
        'Col_IDictionary(oCol)
        Dim i As Integer
        Dim s, ID As String
        'Dim tEntry As DictionaryEntry
        '
        For i = 1 To 5
            ID = (10 * i).ToString("0000")
            s = "Elemento " & ID
            oCol.Add(ID, s)
        Next
        For i = 0 To oCol.Count - 1
            Console.WriteLine("Clave: {0}, Valor: {1}", oCol.GetKey(i), oCol.GetByIndex(i))
        Next
        Console.WriteLine()
        'oCol.RemoveAt(3)
        ID = 28.ToString("0000")
        s = "Elemento " & ID
        oCol.Add(ID, s)
        oCol.RemoveAt(3)
        For i = 0 To oCol.Count - 1
            Console.WriteLine("Clave: {0}, Valor: {1}", oCol.GetKey(i), oCol.GetByIndex(i))
        Next
        '
        Console.ReadLine()
    End Sub
    Sub Col_HT()
        Dim oCol As New Hashtable()
        Col_IDictionary(oCol)
    End Sub
    Sub Col_IDictionary(ByVal oCol As IDictionary)
        Dim i As Integer
        Dim s, ID As String
        Dim tEntry As DictionaryEntry
        '
        For i = 1 To 5
            ID = i.ToString("0000")
            s = "Elemento " & ID
            oCol.Add(ID, s)
        Next
        ' Comprobar si existe un elemento
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        'MostrarElementos(oCol)
        Console.WriteLine()
        'MostrarForEach(tEntry, oCol)
        ' Mostrar todos los elementos
        For Each tEntry In oCol
            Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        Next
        '
        ' Acceder a un elemento
        Console.WriteLine()
        ID = "0003"
        s = CType(oCol.Item(ID), String)
        Console.WriteLine("ID: {0}, Contenido: {1}", ID, s)
        '
        ' Eliminar un elemento
        oCol.Remove(ID)
        '
        Console.WriteLine()
        Console.WriteLine("Despu�s de eliminar el elemento {0}", ID)
        'MostrarForEach(tEntry, oCol)
        For Each tEntry In oCol
            Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        Next
        '
        Console.ReadLine()
    End Sub
    '
    ' Colecciones del tipo IList
    Sub Col_SC()
        Dim oCol As New System.Collections.Specialized.StringCollection()
        Console.WriteLine("Pruebas con una clase del tipo StringCollection")
        Col_IList(oCol)
    End Sub
    Sub Col_AL()
        Dim oCol As New ArrayList()
        Console.WriteLine("Pruebas con una clase del tipo ArrayList")
        Col_IList(oCol)
    End Sub
    Sub Col_IList(ByVal oCol As IList)
        Dim i As Integer
        Dim s, ID As String
        '
        For i = 1 To 5
            ID = i.ToString("0000")
            oCol.Add(ID)
        Next
        '
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        i = oCol.IndexOf(ID)
        Console.WriteLine("El �ndice del elemento {0} es {1}", ID, i)
        '
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        For i = 0 To oCol.Count - 1
            Console.WriteLine("Contenido: {0}", oCol(i))
        Next
        'MostrarElementos(oCol)
        Console.WriteLine()
        oCol.RemoveAt(3)
        oCol.Remove("0004")
        oCol.Insert(2, "0010")
        'MostrarForEach(s, oCol)
        For Each s In oCol
            Console.WriteLine("Contenido: {0}", s)
        Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub Col_SD()
        Dim oCol As New System.Collections.Specialized.StringDictionary()
        Dim i As Integer
        Dim s, ID As String
        Dim tEntry As DictionaryEntry
        '
        For i = 1 To 5
            ID = i.ToString("0000")
            s = "Elemento n�mero: " & ID
            oCol.Add(ID, s)
        Next
        '
        ID = "0003"
        If oCol.ContainsKey(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        ID = "0099"
        If oCol.ContainsKey(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        Console.WriteLine()
        For Each tEntry In oCol
            Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        Next
        '
        oCol.Remove("0004")
        '
        'MostrarElementos(oCol)
        'MostrarForEach(tEntry, oCol)
        Console.WriteLine()
        For Each tEntry In oCol
            Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub Main1()
        ' Estas usar�n MostrarElementos(IList)
        'MainArrayList()
        'MainStringCollection()
        '
        ' Estas usar�n MostrarElementos(IDictionary)
        'MainHashtable()
        'MainSortedList()
        'MainListDictionary()
        'MainHybridDictionary()
        '
        ' Estas usar�n MostrarElementos(IEnumerable y DictionaryEntry)
        'MainStringDictionary()
        '
        ' Estas usar�n MostrarElementos(ICollection)
        ' tambi�n funcionar�n con MostrarElementos(IEnumerable)
        'MainQueue()
        'MainStack()
        '
        'Console.WriteLine()
        'Console.WriteLine("Pulse una tecla para finalizar.")
        'Console.ReadLine()
    End Sub
    '
    ' Procedimiento para mostrar el contenido de una colecci�n
    ' se declaran varios con distintos par�metros,
    ' para abarcar todas las posibilidades.
    'Sub MostrarElementos(ByVal Lista As IList)
    '    Dim tEnumerator As IEnumerator = Lista.GetEnumerator()
    '    Console.WriteLine()
    '    Console.WriteLine("Lista (IList) de elementos de usando IEnumerator:")
    '    While tEnumerator.MoveNext()
    '        Console.WriteLine("Contenido: {0}", tEnumerator.Current)
    '    End While
    'End Sub
    'Sub MostrarElementos(ByVal Lista As IDictionary)
    '    Dim tEnumerator As IEnumerator = Lista.GetEnumerator()
    '    Dim tEntry As DictionaryEntry
    '    Console.WriteLine()
    '    Console.WriteLine("Lista (IDictionary) de elementos de usando IEnumerator:")
    '    While tEnumerator.MoveNext()
    '        tEntry = CType(tEnumerator.Current, DictionaryEntry)
    '        Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
    '    End While
    'End Sub
    Sub MostrarElementos(ByVal Lista As IEnumerable)
        Dim tEnumerator As IEnumerator = Lista.GetEnumerator()
        Dim tEntry As DictionaryEntry
        Dim UsaDictionaryEntry As Boolean = False
        ' Comprobamos si el tipo de la colecci�n es DictionaryEntry
        tEnumerator.MoveNext()
        Try
            ' Si no es del tipo DictionaryEntry,
            ' producir� una excepci�n del tipo InvalidCastException.
            tEntry = CType(tEnumerator.Current, DictionaryEntry)
            ' Si es del tipo DictionaryEntry, seguir� por aqu�
            UsaDictionaryEntry = True
            Console.WriteLine("Lista (IEnumerable y DictionaryEntry) de elementos de usando IEnumerator:")
        Catch e As InvalidCastException
            UsaDictionaryEntry = False
            Console.WriteLine("Lista (IEnumerable) de elementos de usando IEnumerator:")
        Catch e As Exception
            Console.WriteLine(e.Message)
            Exit Sub
        Finally
            ' En cualquier caso, que empiece por el primer elemento
            tEnumerator.Reset()
        End Try
        Console.WriteLine()
        While tEnumerator.MoveNext()
            If UsaDictionaryEntry Then
                tEntry = CType(tEnumerator.Current, DictionaryEntry)
                Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
            Else
                Console.WriteLine("Contenido: {0}", tEnumerator.Current)
            End If
        End While
    End Sub
    'Sub MostrarElementos(ByVal Lista As ICollection)
    '    Dim tEnumerator As IEnumerator = Lista.GetEnumerator()
    '    Console.WriteLine()
    '    Console.WriteLine("Lista (ICollection) de elementos de usando IEnumerator:")
    '    While tEnumerator.MoveNext()
    '        Console.WriteLine("Contenido: {0}", tEnumerator.Current)
    '    End While
    'End Sub
    '
    ' Mostrar elementos usando For Each con elementos gen�ricos
    Sub MostrarForEach(ByVal Elemento As Object, ByVal Lista As IEnumerable)
        Console.WriteLine()
        Console.WriteLine("Lista (Object) de elementos de usando For Each:")
        For Each Elemento In Lista
            Console.WriteLine("Contenido: {0}", Elemento)
        Next
    End Sub
    ' Mostrar elementos usando For Each con elementos del tipo DictionaryEntry
    Sub MostrarForEach(ByVal Elemento As DictionaryEntry, ByVal Lista As IEnumerable)
        Console.WriteLine()
        Console.WriteLine("Lista (DictionaryEntry) de elementos de usando For Each:")
        For Each Elemento In Lista
            Console.WriteLine("Clave: {0}, Contenido: {1}", Elemento.Key, Elemento.Value)
        Next
    End Sub
    '
    Sub MainArrayList()
        Dim oCol As New ArrayList()
        Dim i As Integer
        Dim s, ID As String
        '
        For i = 1 To 5
            ID = i.ToString("0000")
            oCol.Add(ID)
        Next
        '
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        i = oCol.IndexOf(ID)
        Console.WriteLine("El �ndice del elemento {0} es {1}", ID, i)
        '
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        'Console.WriteLine()
        oCol.RemoveAt(3)
        oCol.Remove("0004")
        oCol.Insert(2, "0010")
        MostrarForEach(s, oCol)
        'For Each s In oCol
        '    Console.WriteLine("Contenido: {0}", s)
        'Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainHashtable()
        Dim oCol As New Hashtable()
        Dim i As Integer
        Dim s, ID As String
        Dim tEntry As DictionaryEntry
        '
        For i = 0 To 5
            ID = i.ToString("0000")
            s = "Elemento " & ID
            oCol.Add(ID, s)
        Next
        ' Comprobar si existe un elemento
        ID = "0003"
        If oCol.ContainsKey(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        'Console.WriteLine()
        'MostrarForEach(tEntry, oCol)
        '' Mostrar todos los elementos
        'For Each tEntry In oCol
        '    Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        'Next
        '
        ' Acceder a un elemento
        Console.WriteLine()
        ID = "0003"
        s = CType(oCol.Item(ID), String)
        Console.WriteLine("ID: {0}, Contenido: {1}", ID, s)
        '
        ' Eliminar un elemento
        oCol.Remove(ID)
        '
        ' Mostrar todos los elementos
        Console.WriteLine()
        Console.WriteLine("Despu�s de eliminar el elemento {0}", ID)
        MostrarForEach(tEntry, oCol)
        'For Each tEntry In oCol
        '    Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        'Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainSortedList()
        Dim oCol As New SortedList()
        Dim i As Integer
        Dim s, ID As String
        Dim tEntry As DictionaryEntry
        '
        For i = 0 To 5
            ID = i.ToString("0000")
            s = "Elemento " & ID
            oCol.Add(ID, s)
        Next
        '
        ID = "0003"
        If oCol.ContainsKey(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        MostrarForEach(tEntry, oCol)
        'Console.WriteLine()
        'For Each tEntry In oCol
        '    Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        'Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainStringDictionary()
        ' Para usar StringDictionary hay que importar:
        ' Imports System.Collections.Specialized
        Dim oCol As New System.Collections.Specialized.StringDictionary()
        Dim i As Integer
        Dim s, ID As String
        Dim tEntry As DictionaryEntry
        '
        For i = 0 To 5
            ID = i.ToString("0000")
            s = "Elemento n�mero: " & ID
            oCol.Add(ID, s)
        Next
        '
        ID = "0003"
        If oCol.ContainsKey(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        ID = "0099"
        If oCol.ContainsKey(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        MostrarForEach(tEntry, oCol)
        'Console.WriteLine()
        'For Each tEntry In oCol
        '    Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        'Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainStringCollection()
        ' Para usar StringCollection hay que importar:
        ' Imports System.Collections.Specialized
        Dim oCol As New System.Collections.Specialized.StringCollection()
        Dim i As Integer
        Dim s, ID As String
        '
        For i = 1 To 5
            ID = i.ToString("0000")
            oCol.Add(ID)
        Next
        '
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        i = oCol.IndexOf(ID)
        Console.WriteLine("El �ndice del elemento {0} es {1}", ID, i)
        '
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        oCol.RemoveAt(3)
        oCol.Remove("0004")
        oCol.Insert(2, "0010")
        MostrarForEach(s, oCol)
        'Console.WriteLine()
        'For Each s In oCol
        '    Console.WriteLine("Contenido: {0}", s)
        'Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainListDictionary()
        ' Para usar ListDictionary hay que importar:
        ' Imports System.Collections.Specialized
        Dim oCol As New System.Collections.Specialized.ListDictionary()
        Dim i As Integer
        Dim s, ID As String
        Dim tEntry As DictionaryEntry
        '
        For i = 0 To 5
            ID = i.ToString("0000")
            s = "Elemento n�mero: " & ID
            oCol.Add(ID, s)
        Next
        '
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        MostrarForEach(tEntry, oCol)
        'Console.WriteLine()
        'For Each tEntry In oCol
        '    Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        'Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainHybridDictionary()
        ' Para usar HybridDictionary hay que importar:
        ' Imports System.Collections.Specialized
        Dim oCol As New System.Collections.Specialized.HybridDictionary()
        Dim i As Integer
        Dim s, ID As String
        Dim tEntry As DictionaryEntry
        '
        For i = 0 To 5
            ID = i.ToString("0000")
            s = "Elemento n�mero: " & ID
            oCol.Add(ID, s)
        Next
        '
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        MostrarForEach(tEntry, oCol)
        'Console.WriteLine()
        'For Each tEntry In oCol
        '    Console.WriteLine("ID: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        'Next
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainQueue()
        Dim oCol As New Queue()
        Dim i As Integer
        Dim s, ID As String
        '
        For i = 0 To 5
            ID = i.ToString("0000")
            oCol.Enqueue(ID)
        Next
        '
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        MostrarForEach(s, oCol)
        'Console.WriteLine()
        'For Each s In oCol
        '    Console.WriteLine("Contenido: {0}", s)
        'Next
        '
        ' Eliminar un elemento
        s = CType(oCol.Dequeue, String)
        Console.WriteLine("El elemento eliminado es: {0}", s)
        '
        Console.ReadLine()
    End Sub
    '
    Sub MainStack()
        Dim oCol As New Stack()
        Dim i As Integer
        Dim s, ID As String
        '
        ' A�adir elementos a la colecci�n
        For i = 0 To 5
            ID = i.ToString("0000")
            oCol.Push(ID)
        Next
        '
        ' Comprobar si contiene un elemento
        ID = "0003"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        ID = "0099"
        If oCol.Contains(ID) Then
            Console.WriteLine("SI existe el elemento {0}", ID)
        Else
            Console.WriteLine("NO existe el elemento {0}", ID)
        End If
        '
        MostrarElementos(oCol)
        MostrarForEach(s, oCol)
        'Console.WriteLine()
        '' Recorrer todos los elementos
        'For Each s In oCol
        '    Console.WriteLine("Contenido: {0}", s)
        'Next
        '
        ' Acceder a un elemento (accede al que est� arriba de la pila)
        s = CStr(oCol.Peek)
        Console.WriteLine("El elemento accedido es: {0}", s)
        '
        ' Eliminar un elemento (elimina el �ltimo a�adido)
        s = CType(oCol.Pop(), String)
        Console.WriteLine("El elemento eliminado es: {0}", s)
        '
        Console.ReadLine()
    End Sub
End Module
