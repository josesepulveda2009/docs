'------------------------------------------------------------------------------
' Cap�tulo 12 (p�g. 270)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1

    Sub Main()
        Dim a() As Integer = {1, 99, 13, 45, 22}
        Mostrar(a)
        Console.WriteLine()
        '
        Dim s As String = "MI VB.NET"
        Mostrar(s)
        Console.WriteLine()
        '
        Dim aL As New ArrayList()
        Dim i As Integer
        '
        For i = 1 To 5
            aL.Add(i.ToString)
        Next
        Mostrar(aL)
        Console.WriteLine()
        '
        Dim aH As New Hashtable()
        For i = 1 To 5
            aH.Add(i.ToString, "Elemento " & i.ToString)
        Next
        Mostrar(aH)
        Console.WriteLine()
        '
        Console.ReadLine()
        '
    End Sub
    '
    ' Procedimientos para mostrar el contenido de una colecci�n.
    ' Se declaran varios con distintos par�metros,
    ' para abarcar todas las posibilidades.
    Sub Mostrar(ByVal Lista As IList)
        Dim tEnum As IEnumerator = Lista.GetEnumerator()
        '
        While tEnum.MoveNext()
            Console.WriteLine("Contenido: {0}", tEnum.Current)
        End While
    End Sub
    '
    Sub Mostrar(ByVal Lista As IDictionary)
        Dim tEnum As IEnumerator = Lista.GetEnumerator()
        Dim tEntry As DictionaryEntry
        '
        While tEnum.MoveNext()
            tEntry = CType(tEnum.Current, DictionaryEntry)
            Console.WriteLine("Clave: {0}, Contenido: {1}", tEntry.Key, tEntry.Value)
        End While
    End Sub
    '
    Sub Mostrar(ByVal Lista As ICollection)
        Dim tEnum As IEnumerator = Lista.GetEnumerator()
        '
        While tEnum.MoveNext()
            Console.WriteLine("Contenido: {0}", tEnum.Current)
        End While
    End Sub
    '
    Sub Mostrar(ByVal Lista As IEnumerable)
        Dim tEnum As IEnumerator = Lista.GetEnumerator()
        '
        While tEnum.MoveNext()
            Console.WriteLine("Contenido: {0}", tEnum.Current)
        End While
    End Sub
    '
End Module
