'------------------------------------------------------------------------------
' Cap�tulo 12 (p�g. 270)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    '
    Sub Main()
        Dim a() As Integer = {1, 99, 13, 45, 22}
        Mostrar(a)
        Console.WriteLine()
        '
        Dim s As String = "MI VB.NET"
        Mostrar(s)
        Console.WriteLine()
        '
        Console.ReadLine()
    End Sub
    '
    Sub Mostrar(ByVal Lista As IEnumerable)
        Dim tEntry As DictionaryEntry
        Dim tEnum As IEnumerator
        '
        tEnum = Lista.GetEnumerator()
        '
        While tEnum.MoveNext()
            Try
                tEntry = CType(tEnum.Current, DictionaryEntry)
                Console.WriteLine("Clave: {0}, Valor: {1}", tEntry.Key, tEntry.Value)
            Catch
                Console.WriteLine("Contenido: {0}", tEnum.Current)
            End Try
        End While
    End Sub
End Module
