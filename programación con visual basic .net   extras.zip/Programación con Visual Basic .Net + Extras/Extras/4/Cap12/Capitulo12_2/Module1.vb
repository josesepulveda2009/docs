'------------------------------------------------------------------------------
' Cap�tulo 12 (p�gs. 263 a 265)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    '
    Sub Main()
        ' Cualquiera de estas declaraciones ser�a v�lida para esta prueba
        Dim oCol As New Hashtable()
        'Dim oCol As New Specialized.HybridDictionary()
        'Dim oCol As New Specialized.ListDictionary()
        'Dim oCol As New SortedList()
        '
        Dim i As Integer
        Dim clave As String
        Dim valor As String
        '
        For i = 1 To 5
            clave = i.ToString("0000")
            valor = "Elemento " & i.ToString
            oCol.Add(clave, valor)
        Next
        '
        clave = "0003"
        oCol.Remove(clave)
        Console.WriteLine("Se ha eliminado el elemento {0}", clave)
        Console.WriteLine()
        '
        ' Comprobar si existe un elemento
        If oCol.Contains(clave) Then
            ' Si lo contiene
            Console.WriteLine("El elemento {0}, SI est� en la colecci�n", clave)
        Else
            ' No lo contiene
            Console.WriteLine("El elemento {0}, NO est� en la colecci�n", clave)
        End If
        '
        clave = "0002"
        Console.WriteLine("El elemento {0} contiene {1}", clave, oCol.Item(clave))
        oCol(clave) = "Nuevo contenido con la clave " & clave
        Console.WriteLine("El elemento {0} ahora contiene {1}", clave, oCol(clave))
        '
        For Each clave In oCol.Keys
            Console.WriteLine("{0} {1}", clave, oCol(clave))
        Next
        For Each valor In oCol.Values
            Console.WriteLine(valor)
        Next
        '
        Console.ReadLine()
    End Sub
End Module
