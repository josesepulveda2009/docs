'------------------------------------------------------------------------------
' Cap�tulo 12 (p�gs. 259 a 261)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    '
    Sub Main()
        ' Cualquiera de estas declaraciones ser�a v�lida para esta prueba
        Dim oCol As New ArrayList()
        'Dim oCol As New Specialized.StringCollection()
        '
        Dim i As Integer
        Dim valor As String
        '
        ' A�adir nuevos elementos
        For i = 1 To 5
            oCol.Add(i.ToString("0000"))
        Next
        '
        ' Comprobar si existe un elemento
        valor = "0003"
        Console.Write("Usando Contains: ")
        If oCol.Contains(valor) Then
            ' Si lo contiene
            Console.WriteLine("El elemento {0}, SI est� en la colecci�n", valor)
        Else
            ' No lo contiene
            Console.WriteLine("El elemento {0}, NO est� en la colecci�n", valor)
        End If
        '
        i = oCol.IndexOf(valor)
        Console.Write("Usando IndexOf: ")
        If i = -1 Then
            ' No lo contiene
            Console.WriteLine("El elemento {0}, NO est� en la colecci�n", valor)
        Else
            ' Si lo contiene
            Console.WriteLine("El elemento {0} tiene el �ndice {1}", valor, i)
        End If
        '
        ' Eliminar un elemento, indicando el contenido
        oCol.Remove(valor)
        ' Eliminar un elemento, indicando el �ndice (o posici�n)
        oCol.RemoveAt(1)
        '
        For i = 0 To oCol.Count - 1
            Console.WriteLine(oCol(i))
        Next
        Console.WriteLine()
        '
        valor = "0009"
        oCol.Insert(1, valor)
        '
        Console.WriteLine("El elemento en la posici�n 3 es: {0}", oCol.Item(3))
        oCol(2) = "Nuevo contenido de la posici�n 2"
        Console.WriteLine("El elemento en la posici�n 2 es: {0}", oCol(2))
        '
        For Each valor In oCol
            Console.WriteLine(valor)
        Next
        Console.WriteLine()
        '
        Console.ReadLine()
    End Sub

End Module
