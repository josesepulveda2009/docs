'------------------------------------------------------------------------------
' Cap�tulo 12 (p�g. 269)
'
' Manual Imprescindible de Visual Basic .NET
'
' �Guillermo 'Guille' Som, 2002
'------------------------------------------------------------------------------
Option Strict On

Module Module1
    '
    Sub Main()
        Dim a() As Integer = {1, 99, 13, 45, 22}
        Mostrar(a)
        Console.WriteLine()
        '
        Dim s As String = "MI VB.NET"
        Mostrar(s)
        Console.WriteLine()
        '
        Console.ReadLine()
    End Sub
    '
    Sub Mostrar(ByVal Lista As IEnumerable)
        Dim tEntry As DictionaryEntry
        Dim UsaDicEntry As Boolean
        Dim tEnum As IEnumerator
        '
        tEnum = Lista.GetEnumerator()
        ' Comprobamos si el tipo de la colecci�n es DictionaryEntry
        tEnum.MoveNext()
        Try
            ' Si no es del tipo DictionaryEntry,
            ' producir� una excepci�n del tipo InvalidCastException.
            tEntry = CType(tEnum.Current, DictionaryEntry)
            ' Si es del tipo DictionaryEntry, seguir� por aqu�
            UsaDicEntry = True
        Catch
            UsaDicEntry = False
        End Try
        ' Posicionar el enumerador al principio
        tEnum.Reset()
        '
        While tEnum.MoveNext()
            If UsaDicEntry Then
                tEntry = CType(tEnum.Current, DictionaryEntry)
                Console.WriteLine("Contenido: {0}", tEntry.Value)
            Else
                Console.WriteLine("Contenido: {0}", tEnum.Current)
            End If
        End While
    End Sub
End Module
