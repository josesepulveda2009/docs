Public Class DataForm1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
  Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
  Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
  Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
  Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
  Friend WithEvents objMiDataSet As Navegacion.MiDataSet
  Friend WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
  Friend WithEvents OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter
  Friend WithEvents btnLoad As System.Windows.Forms.Button
  Friend WithEvents btnUpdate As System.Windows.Forms.Button
  Friend WithEvents btnCancelAll As System.Windows.Forms.Button
  Friend WithEvents mfp_lblau_id As System.Windows.Forms.Label
  Friend WithEvents mfp_lblau_lname As System.Windows.Forms.Label
  Friend WithEvents mfp_lblau_fname As System.Windows.Forms.Label
  Friend WithEvents mfp_lblphone As System.Windows.Forms.Label
  Friend WithEvents mfp_lbladdress As System.Windows.Forms.Label
  Friend WithEvents mfp_editau_id As System.Windows.Forms.TextBox
  Friend WithEvents mfp_editau_lname As System.Windows.Forms.TextBox
  Friend WithEvents mfp_editau_fname As System.Windows.Forms.TextBox
  Friend WithEvents mfp_editphone As System.Windows.Forms.TextBox
  Friend WithEvents mfp_editaddress As System.Windows.Forms.TextBox
  Friend WithEvents mfp_lblcity As System.Windows.Forms.Label
  Friend WithEvents mfp_lblstate As System.Windows.Forms.Label
  Friend WithEvents mfp_lblzip As System.Windows.Forms.Label
  Friend WithEvents mfp_lblcontract As System.Windows.Forms.Label
  Friend WithEvents mfp_editcity As System.Windows.Forms.TextBox
  Friend WithEvents mfp_editstate As System.Windows.Forms.TextBox
  Friend WithEvents mfp_editzip As System.Windows.Forms.TextBox
  Friend WithEvents mfp_editcontract As System.Windows.Forms.CheckBox
  Friend WithEvents mfp_btnNavFirst As System.Windows.Forms.Button
  Friend WithEvents mfp_btnNavPrev As System.Windows.Forms.Button
  Friend WithEvents mfp_lblNavLocation As System.Windows.Forms.Label
  Friend WithEvents mfp_btnNavNext As System.Windows.Forms.Button
  Friend WithEvents mfp_btnNavLast As System.Windows.Forms.Button
  Friend WithEvents mfp_btnAdd As System.Windows.Forms.Button
  Friend WithEvents mfp_btnDelete As System.Windows.Forms.Button
  Friend WithEvents mfp_btnCancel As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
    Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
    Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
    Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
    Me.objMiDataSet = New Navegacion.MiDataSet()
    Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
    Me.OleDbDataAdapter1 = New System.Data.OleDb.OleDbDataAdapter()
    Me.btnLoad = New System.Windows.Forms.Button()
    Me.btnUpdate = New System.Windows.Forms.Button()
    Me.btnCancelAll = New System.Windows.Forms.Button()
    Me.mfp_lblau_id = New System.Windows.Forms.Label()
    Me.mfp_lblau_lname = New System.Windows.Forms.Label()
    Me.mfp_lblau_fname = New System.Windows.Forms.Label()
    Me.mfp_lblphone = New System.Windows.Forms.Label()
    Me.mfp_lbladdress = New System.Windows.Forms.Label()
    Me.mfp_editau_id = New System.Windows.Forms.TextBox()
    Me.mfp_editau_lname = New System.Windows.Forms.TextBox()
    Me.mfp_editau_fname = New System.Windows.Forms.TextBox()
    Me.mfp_editphone = New System.Windows.Forms.TextBox()
    Me.mfp_editaddress = New System.Windows.Forms.TextBox()
    Me.mfp_lblcity = New System.Windows.Forms.Label()
    Me.mfp_lblstate = New System.Windows.Forms.Label()
    Me.mfp_lblzip = New System.Windows.Forms.Label()
    Me.mfp_lblcontract = New System.Windows.Forms.Label()
    Me.mfp_editcity = New System.Windows.Forms.TextBox()
    Me.mfp_editstate = New System.Windows.Forms.TextBox()
    Me.mfp_editzip = New System.Windows.Forms.TextBox()
    Me.mfp_editcontract = New System.Windows.Forms.CheckBox()
    Me.mfp_btnNavFirst = New System.Windows.Forms.Button()
    Me.mfp_btnNavPrev = New System.Windows.Forms.Button()
    Me.mfp_lblNavLocation = New System.Windows.Forms.Label()
    Me.mfp_btnNavNext = New System.Windows.Forms.Button()
    Me.mfp_btnNavLast = New System.Windows.Forms.Button()
    Me.mfp_btnAdd = New System.Windows.Forms.Button()
    Me.mfp_btnDelete = New System.Windows.Forms.Button()
    Me.mfp_btnCancel = New System.Windows.Forms.Button()
    CType(Me.objMiDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'OleDbSelectCommand1
    '
    Me.OleDbSelectCommand1.CommandText = "SELECT au_id, au_lname, au_fname, phone, address, city, state, zip, contract FROM" & _
    " authors"
    Me.OleDbSelectCommand1.Connection = Me.OleDbConnection1
    '
    'OleDbInsertCommand1
    '
    Me.OleDbInsertCommand1.CommandText = "INSERT INTO authors(au_id, au_lname, au_fname, phone, address, city, state, zip, " & _
    "contract) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?); SELECT au_id, au_lname, au_fname, " & _
    "phone, address, city, state, zip, contract FROM authors WHERE (au_id = ?)"
    Me.OleDbInsertCommand1.Connection = Me.OleDbConnection1
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_id", System.Data.OleDb.OleDbType.Char, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_id", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_lname", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_lname", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_fname", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_fname", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("phone", System.Data.OleDb.OleDbType.Char, 12, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "phone", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("address", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "address", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("city", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "city", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("state", System.Data.OleDb.OleDbType.Char, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "state", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("zip", System.Data.OleDb.OleDbType.Char, 5, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "zip", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("contract", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "contract", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Select_au_id", System.Data.OleDb.OleDbType.Char, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_id", System.Data.DataRowVersion.Current, Nothing))
    '
    'OleDbUpdateCommand1
    '
    Me.OleDbUpdateCommand1.CommandText = "UPDATE authors SET au_id = ?, au_lname = ?, au_fname = ?, phone = ?, address = ?," & _
    " city = ?, state = ?, zip = ?, contract = ? WHERE (au_id = ?) AND (address = ? O" & _
    "R ? IS NULL AND address IS NULL) AND (au_fname = ?) AND (au_lname = ?) AND (city" & _
    " = ? OR ? IS NULL AND city IS NULL) AND (contract = ?) AND (phone = ?) AND (stat" & _
    "e = ? OR ? IS NULL AND state IS NULL) AND (zip = ? OR ? IS NULL AND zip IS NULL)" & _
    "; SELECT au_id, au_lname, au_fname, phone, address, city, state, zip, contract F" & _
    "ROM authors WHERE (au_id = ?)"
    Me.OleDbUpdateCommand1.Connection = Me.OleDbConnection1
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_id", System.Data.OleDb.OleDbType.Char, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_id", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_lname", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_lname", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_fname", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_fname", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("phone", System.Data.OleDb.OleDbType.Char, 12, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "phone", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("address", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "address", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("city", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "city", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("state", System.Data.OleDb.OleDbType.Char, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "state", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("zip", System.Data.OleDb.OleDbType.Char, 5, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "zip", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("contract", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "contract", System.Data.DataRowVersion.Current, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_au_id", System.Data.OleDb.OleDbType.Char, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_id", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_address", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "address", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_address1", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "address", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_au_fname", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_fname", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_au_lname", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_lname", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_city", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "city", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_city1", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "city", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_contract", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "contract", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_phone", System.Data.OleDb.OleDbType.Char, 12, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "phone", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_state", System.Data.OleDb.OleDbType.Char, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "state", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_state1", System.Data.OleDb.OleDbType.Char, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "state", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_zip", System.Data.OleDb.OleDbType.Char, 5, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "zip", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_zip1", System.Data.OleDb.OleDbType.Char, 5, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "zip", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Select_au_id", System.Data.OleDb.OleDbType.Char, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_id", System.Data.DataRowVersion.Current, Nothing))
    '
    'OleDbDeleteCommand1
    '
    Me.OleDbDeleteCommand1.CommandText = "DELETE FROM authors WHERE (au_id = ?) AND (address = ? OR ? IS NULL AND address I" & _
    "S NULL) AND (au_fname = ?) AND (au_lname = ?) AND (city = ? OR ? IS NULL AND cit" & _
    "y IS NULL) AND (contract = ?) AND (phone = ?) AND (state = ? OR ? IS NULL AND st" & _
    "ate IS NULL) AND (zip = ? OR ? IS NULL AND zip IS NULL)"
    Me.OleDbDeleteCommand1.Connection = Me.OleDbConnection1
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_id", System.Data.OleDb.OleDbType.Char, 11, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_id", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("address", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "address", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("address1", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "address", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_fname", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_fname", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("au_lname", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "au_lname", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("city", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "city", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("city1", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "city", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("contract", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "contract", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("phone", System.Data.OleDb.OleDbType.Char, 12, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "phone", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("state", System.Data.OleDb.OleDbType.Char, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "state", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("state1", System.Data.OleDb.OleDbType.Char, 2, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "state", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("zip", System.Data.OleDb.OleDbType.Char, 5, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "zip", System.Data.DataRowVersion.Original, Nothing))
    Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("zip1", System.Data.OleDb.OleDbType.Char, 5, System.Data.ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "zip", System.Data.DataRowVersion.Original, Nothing))
    '
    'objMiDataSet
    '
    Me.objMiDataSet.DataSetName = "MiDataSet"
    Me.objMiDataSet.Locale = New System.Globalization.CultureInfo("es-ES")
    Me.objMiDataSet.Namespace = "http://www.tempuri.org/MiDataSet.xsd"
    '
    'OleDbConnection1
    '
    Me.OleDbConnection1.ConnectionString = "Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;Initial " & _
    "Catalog=pubs;Data Source=INSPIRON;Use Procedure for Prepare=1;Auto Translate=Tru" & _
    "e;Packet Size=4096;Workstation ID=INSPIRON;Use Encryption for Data=False;Tag wit" & _
    "h column collation when possible=False"
    '
    'OleDbDataAdapter1
    '
    Me.OleDbDataAdapter1.DeleteCommand = Me.OleDbDeleteCommand1
    Me.OleDbDataAdapter1.InsertCommand = Me.OleDbInsertCommand1
    Me.OleDbDataAdapter1.SelectCommand = Me.OleDbSelectCommand1
    Me.OleDbDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "authors", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("au_id", "au_id"), New System.Data.Common.DataColumnMapping("au_lname", "au_lname"), New System.Data.Common.DataColumnMapping("au_fname", "au_fname"), New System.Data.Common.DataColumnMapping("phone", "phone"), New System.Data.Common.DataColumnMapping("address", "address"), New System.Data.Common.DataColumnMapping("city", "city"), New System.Data.Common.DataColumnMapping("state", "state"), New System.Data.Common.DataColumnMapping("zip", "zip"), New System.Data.Common.DataColumnMapping("contract", "contract")})})
    Me.OleDbDataAdapter1.UpdateCommand = Me.OleDbUpdateCommand1
    '
    'btnLoad
    '
    Me.btnLoad.Location = New System.Drawing.Point(10, 10)
    Me.btnLoad.Name = "btnLoad"
    Me.btnLoad.Size = New System.Drawing.Size(91, 23)
    Me.btnLoad.TabIndex = 0
    Me.btnLoad.Text = "Ca&rgar"
    '
    'btnUpdate
    '
    Me.btnUpdate.Location = New System.Drawing.Point(349, 10)
    Me.btnUpdate.Name = "btnUpdate"
    Me.btnUpdate.Size = New System.Drawing.Size(91, 23)
    Me.btnUpdate.TabIndex = 1
    Me.btnUpdate.Text = "Act&ualizar"
    '
    'btnCancelAll
    '
    Me.btnCancelAll.Location = New System.Drawing.Point(349, 43)
    Me.btnCancelAll.Name = "btnCancelAll"
    Me.btnCancelAll.Size = New System.Drawing.Size(91, 23)
    Me.btnCancelAll.TabIndex = 2
    Me.btnCancelAll.Text = "Ca&ncelar todo"
    '
    'mfp_lblau_id
    '
    Me.mfp_lblau_id.Location = New System.Drawing.Point(10, 76)
    Me.mfp_lblau_id.Name = "mfp_lblau_id"
    Me.mfp_lblau_id.TabIndex = 3
    Me.mfp_lblau_id.Text = "au_id"
    '
    'mfp_lblau_lname
    '
    Me.mfp_lblau_lname.Location = New System.Drawing.Point(10, 109)
    Me.mfp_lblau_lname.Name = "mfp_lblau_lname"
    Me.mfp_lblau_lname.TabIndex = 4
    Me.mfp_lblau_lname.Text = "au_lname"
    '
    'mfp_lblau_fname
    '
    Me.mfp_lblau_fname.Location = New System.Drawing.Point(10, 142)
    Me.mfp_lblau_fname.Name = "mfp_lblau_fname"
    Me.mfp_lblau_fname.TabIndex = 5
    Me.mfp_lblau_fname.Text = "au_fname"
    '
    'mfp_lblphone
    '
    Me.mfp_lblphone.Location = New System.Drawing.Point(10, 175)
    Me.mfp_lblphone.Name = "mfp_lblphone"
    Me.mfp_lblphone.TabIndex = 6
    Me.mfp_lblphone.Text = "phone"
    '
    'mfp_lbladdress
    '
    Me.mfp_lbladdress.Location = New System.Drawing.Point(10, 208)
    Me.mfp_lbladdress.Name = "mfp_lbladdress"
    Me.mfp_lbladdress.TabIndex = 7
    Me.mfp_lbladdress.Text = "address"
    '
    'mfp_editau_id
    '
    Me.mfp_editau_id.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.au_id"))
    Me.mfp_editau_id.Location = New System.Drawing.Point(120, 76)
    Me.mfp_editau_id.Name = "mfp_editau_id"
    Me.mfp_editau_id.TabIndex = 8
    Me.mfp_editau_id.Text = ""
    '
    'mfp_editau_lname
    '
    Me.mfp_editau_lname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.au_lname"))
    Me.mfp_editau_lname.Location = New System.Drawing.Point(120, 109)
    Me.mfp_editau_lname.Name = "mfp_editau_lname"
    Me.mfp_editau_lname.TabIndex = 9
    Me.mfp_editau_lname.Text = ""
    '
    'mfp_editau_fname
    '
    Me.mfp_editau_fname.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.au_fname"))
    Me.mfp_editau_fname.Location = New System.Drawing.Point(120, 142)
    Me.mfp_editau_fname.Name = "mfp_editau_fname"
    Me.mfp_editau_fname.TabIndex = 10
    Me.mfp_editau_fname.Text = ""
    '
    'mfp_editphone
    '
    Me.mfp_editphone.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.phone"))
    Me.mfp_editphone.Location = New System.Drawing.Point(120, 175)
    Me.mfp_editphone.Name = "mfp_editphone"
    Me.mfp_editphone.TabIndex = 11
    Me.mfp_editphone.Text = ""
    '
    'mfp_editaddress
    '
    Me.mfp_editaddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.address"))
    Me.mfp_editaddress.Location = New System.Drawing.Point(120, 208)
    Me.mfp_editaddress.Name = "mfp_editaddress"
    Me.mfp_editaddress.TabIndex = 12
    Me.mfp_editaddress.Text = ""
    '
    'mfp_lblcity
    '
    Me.mfp_lblcity.Location = New System.Drawing.Point(230, 76)
    Me.mfp_lblcity.Name = "mfp_lblcity"
    Me.mfp_lblcity.TabIndex = 13
    Me.mfp_lblcity.Text = "city"
    '
    'mfp_lblstate
    '
    Me.mfp_lblstate.Location = New System.Drawing.Point(230, 109)
    Me.mfp_lblstate.Name = "mfp_lblstate"
    Me.mfp_lblstate.TabIndex = 14
    Me.mfp_lblstate.Text = "state"
    '
    'mfp_lblzip
    '
    Me.mfp_lblzip.Location = New System.Drawing.Point(230, 142)
    Me.mfp_lblzip.Name = "mfp_lblzip"
    Me.mfp_lblzip.TabIndex = 15
    Me.mfp_lblzip.Text = "zip"
    '
    'mfp_lblcontract
    '
    Me.mfp_lblcontract.Location = New System.Drawing.Point(230, 175)
    Me.mfp_lblcontract.Name = "mfp_lblcontract"
    Me.mfp_lblcontract.TabIndex = 16
    Me.mfp_lblcontract.Text = "contract"
    '
    'mfp_editcity
    '
    Me.mfp_editcity.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.city"))
    Me.mfp_editcity.Location = New System.Drawing.Point(340, 76)
    Me.mfp_editcity.Name = "mfp_editcity"
    Me.mfp_editcity.TabIndex = 17
    Me.mfp_editcity.Text = ""
    '
    'mfp_editstate
    '
    Me.mfp_editstate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.state"))
    Me.mfp_editstate.Location = New System.Drawing.Point(340, 109)
    Me.mfp_editstate.Name = "mfp_editstate"
    Me.mfp_editstate.TabIndex = 18
    Me.mfp_editstate.Text = ""
    '
    'mfp_editzip
    '
    Me.mfp_editzip.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.objMiDataSet, "authors.zip"))
    Me.mfp_editzip.Location = New System.Drawing.Point(340, 142)
    Me.mfp_editzip.Name = "mfp_editzip"
    Me.mfp_editzip.TabIndex = 19
    Me.mfp_editzip.Text = ""
    '
    'mfp_editcontract
    '
    Me.mfp_editcontract.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.objMiDataSet, "authors.contract"))
    Me.mfp_editcontract.Location = New System.Drawing.Point(340, 175)
    Me.mfp_editcontract.Name = "mfp_editcontract"
    Me.mfp_editcontract.Size = New System.Drawing.Size(100, 24)
    Me.mfp_editcontract.TabIndex = 20
    '
    'mfp_btnNavFirst
    '
    Me.mfp_btnNavFirst.Location = New System.Drawing.Point(195, 241)
    Me.mfp_btnNavFirst.Name = "mfp_btnNavFirst"
    Me.mfp_btnNavFirst.Size = New System.Drawing.Size(40, 23)
    Me.mfp_btnNavFirst.TabIndex = 21
    Me.mfp_btnNavFirst.Text = "<<"
    '
    'mfp_btnNavPrev
    '
    Me.mfp_btnNavPrev.Location = New System.Drawing.Point(235, 241)
    Me.mfp_btnNavPrev.Name = "mfp_btnNavPrev"
    Me.mfp_btnNavPrev.Size = New System.Drawing.Size(35, 23)
    Me.mfp_btnNavPrev.TabIndex = 22
    Me.mfp_btnNavPrev.Text = "<"
    '
    'mfp_lblNavLocation
    '
    Me.mfp_lblNavLocation.BackColor = System.Drawing.Color.White
    Me.mfp_lblNavLocation.Location = New System.Drawing.Point(270, 241)
    Me.mfp_lblNavLocation.Name = "mfp_lblNavLocation"
    Me.mfp_lblNavLocation.Size = New System.Drawing.Size(95, 23)
    Me.mfp_lblNavLocation.TabIndex = 23
    Me.mfp_lblNavLocation.Text = "Sin registros"
    Me.mfp_lblNavLocation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'mfp_btnNavNext
    '
    Me.mfp_btnNavNext.Location = New System.Drawing.Point(365, 241)
    Me.mfp_btnNavNext.Name = "mfp_btnNavNext"
    Me.mfp_btnNavNext.Size = New System.Drawing.Size(35, 23)
    Me.mfp_btnNavNext.TabIndex = 24
    Me.mfp_btnNavNext.Text = ">"
    '
    'mfp_btnNavLast
    '
    Me.mfp_btnNavLast.Location = New System.Drawing.Point(400, 241)
    Me.mfp_btnNavLast.Name = "mfp_btnNavLast"
    Me.mfp_btnNavLast.Size = New System.Drawing.Size(40, 23)
    Me.mfp_btnNavLast.TabIndex = 25
    Me.mfp_btnNavLast.Text = ">>"
    '
    'mfp_btnAdd
    '
    Me.mfp_btnAdd.Location = New System.Drawing.Point(195, 274)
    Me.mfp_btnAdd.Name = "mfp_btnAdd"
    Me.mfp_btnAdd.TabIndex = 26
    Me.mfp_btnAdd.Text = "&Agregar"
    '
    'mfp_btnDelete
    '
    Me.mfp_btnDelete.Location = New System.Drawing.Point(280, 274)
    Me.mfp_btnDelete.Name = "mfp_btnDelete"
    Me.mfp_btnDelete.TabIndex = 27
    Me.mfp_btnDelete.Text = "&Eliminar"
    '
    'mfp_btnCancel
    '
    Me.mfp_btnCancel.Location = New System.Drawing.Point(365, 274)
    Me.mfp_btnCancel.Name = "mfp_btnCancel"
    Me.mfp_btnCancel.TabIndex = 28
    Me.mfp_btnCancel.Text = "&Cancelar"
    '
    'DataForm1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(442, 315)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnLoad, Me.btnUpdate, Me.btnCancelAll, Me.mfp_lblau_id, Me.mfp_lblau_lname, Me.mfp_lblau_fname, Me.mfp_lblphone, Me.mfp_lbladdress, Me.mfp_editau_id, Me.mfp_editau_lname, Me.mfp_editau_fname, Me.mfp_editphone, Me.mfp_editaddress, Me.mfp_lblcity, Me.mfp_lblstate, Me.mfp_lblzip, Me.mfp_lblcontract, Me.mfp_editcity, Me.mfp_editstate, Me.mfp_editzip, Me.mfp_editcontract, Me.mfp_btnNavFirst, Me.mfp_btnNavPrev, Me.mfp_lblNavLocation, Me.mfp_btnNavNext, Me.mfp_btnNavLast, Me.mfp_btnAdd, Me.mfp_btnDelete, Me.mfp_btnCancel})
    Me.Name = "DataForm1"
    Me.Text = "DataForm1"
    CType(Me.objMiDataSet, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub mfp_btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnCancel.Click
    Me.BindingContext(objMiDataSet, "authors").CancelCurrentEdit()
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub mfp_btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnDelete.Click
    If (Me.BindingContext(objMiDataSet, "authors").Count > 0) Then
      Me.BindingContext(objMiDataSet, "authors").RemoveAt(Me.BindingContext(objMiDataSet, "authors").Position)
      Me.objMiDataSet_PositionChanged()
    End If

  End Sub
  Private Sub mfp_btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnAdd.Click
    Try
      'Borrar las ediciones actuales
      Me.BindingContext(objMiDataSet, "authors").EndCurrentEdit()
      Me.BindingContext(objMiDataSet, "authors").AddNew()
    Catch eEndEdit As System.Exception
      System.Windows.Forms.MessageBox.Show(eEndEdit.Message)
    End Try
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
    Try
      Me.UpdateDataSet()
    Catch eUpdate As System.Exception
      System.Windows.Forms.MessageBox.Show(eUpdate.Message)
    End Try
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub btnLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoad.Click
    Try
      Me.LoadDataSet()
    Catch eLoad As System.Exception
      System.Windows.Forms.MessageBox.Show(eLoad.Message)
    End Try
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub mfp_btnNavFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavFirst.Click
    Me.BindingContext(objMiDataSet, "authors").Position = 0
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub mfp_btnNavLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavLast.Click
    Me.BindingContext(objMiDataSet, "authors").Position = (Me.objMiDataSet.Tables("authors").Rows.Count - 1)
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub mfp_btnNavPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavPrev.Click
    Me.BindingContext(objMiDataSet, "authors").Position = (Me.BindingContext(objMiDataSet, "authors").Position - 1)
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub mfp_btnNavNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mfp_btnNavNext.Click
    Me.BindingContext(objMiDataSet, "authors").Position = (Me.BindingContext(objMiDataSet, "authors").Position + 1)
    Me.objMiDataSet_PositionChanged()

  End Sub
  Private Sub objMiDataSet_PositionChanged()
    Me.mfp_lblNavLocation.Text = (((Me.BindingContext(objMiDataSet, "authors").Position + 1).ToString + " de  ") _
                + Me.BindingContext(objMiDataSet, "authors").Count.ToString)

  End Sub
  Private Sub btnCancelAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelAll.Click
    Me.objMiDataSet.RejectChanges()

  End Sub
  Public Sub UpdateDataSet()
    'Obtener un nuevo conjunto de datos que s�lo contenga los cambios realizados en el conjunto de datos principal
    Dim objDataSetChanges As Navegacion.MiDataSet = New Navegacion.MiDataSet()
    Dim objDataSetUpdated As System.Data.DataSet = New Navegacion.MiDataSet()
    'Borrar las ediciones actuales
    Me.BindingContext(objMiDataSet, "authors").EndCurrentEdit()
    'Obtener un nuevo conjunto de datos que s�lo contenga los cambios realizados en el conjunto de datos principal
    objDataSetChanges = CType(objMiDataSet.GetChanges, Navegacion.MiDataSet)
    'Comprobar si objCustomersDatasetChanges tiene registros
    If (Not (objDataSetChanges) Is Nothing) Then
      Try
        'Llamar al m�todo de actualizaci�n pasando el conjunto de datos y cualquier par�metro
        Me.UpdateDataSource(objDataSetChanges)
      Catch eUpdate As System.Exception
        'Si se produjo un error en la actualizaci�n y es parte de una transacci�n, �ste es el lugar donde debe poner la desinstalaci�n
        Throw eUpdate
      End Try
      'Si la actualizaci�n se realiz� con �xito y es parte de una transacci�n, �ste es el lugar donde debe poner la confirmaci�n
      'Agregar c�digo para comprobar en el conjunto de datos devuelto - objCustomersDataSetUpdate - los errores que se puedan haber
      'introducido en el error del objeto de fila
      'Volver a combinar los cambios devueltos en el conjunto de datos principal
      Try
        objMiDataSet.Merge(objDataSetUpdated)
      Catch eUpdateMerge As System.Exception
        'Agregar c�digo de control de excepciones aqu�.
        Throw eUpdateMerge
      End Try
      'Confirmar los cambios que se acaban de combinar
      'Esto hace que cualquier fila marcada como actualizada, insertada o cambiada se marque como valor original
      objMiDataSet.AcceptChanges()
    End If

  End Sub
  Public Sub LoadDataSet()
    Dim objDataSetTemporal As Navegacion.MiDataSet
    objDataSetTemporal = New Navegacion.MiDataSet()
    Try
      'Ejecutar SelectCommand en DatasetCommmand y rellenar el conjunto de datos
      Me.FillDataSet(objDataSetTemporal)
    Catch eFillDataSet As System.Exception
      'Agregar c�digo de control de excepciones aqu�.
      Throw eFillDataSet
    End Try
    Try
      'Combinar los registros que se acaban de sacar del almac�n de datos con el conjunto de datos principal
      objMiDataSet.Merge(objDataSetTemporal)
    Catch eLoadMerge As System.Exception
      'Agregar c�digo de control de excepciones aqu�.
      Throw eLoadMerge
    End Try

  End Sub
  Public Function UpdateDataSource(ByVal dataSet As Navegacion.MiDataSet) As System.Int32
    Me.OleDbConnection1.Open()

    Dim UpdatedRows As System.Data.DataSet
    Dim InsertedRows As System.Data.DataSet
    Dim DeletedRows As System.Data.DataSet
    Dim AffectedRows As Integer = 0

    UpdatedRows = dataSet.GetChanges(System.Data.DataRowState.Modified)
    InsertedRows = dataSet.GetChanges(System.Data.DataRowState.Added)
    DeletedRows = dataSet.GetChanges(System.Data.DataRowState.Deleted)
    Try
      If (Not (UpdatedRows) Is Nothing) Then
        AffectedRows = OleDbDataAdapter1.Update(UpdatedRows)
      End If
      If (Not (InsertedRows) Is Nothing) Then
        AffectedRows = (AffectedRows + OleDbDataAdapter1.Update(InsertedRows))
      End If
      If (Not (DeletedRows) Is Nothing) Then
        AffectedRows = (AffectedRows + OleDbDataAdapter1.Update(DeletedRows))
      End If
    Catch updateException As System.Exception
      Throw updateException
    Finally
      Me.OleDbConnection1.Close()
    End Try


  End Function
  Public Sub FillDataSet(ByVal dataSet As Navegacion.MiDataSet)
    Me.OleDbConnection1.Open()

    dataSet.EnforceConstraints = False
    Try
      Me.OleDbDataAdapter1.Fill(dataSet)
    Catch fillException As System.Exception
      Throw fillException
    Finally
      dataSet.EnforceConstraints = True
      Me.OleDbConnection1.Close()
    End Try


  End Sub
End Class
