Imports System.Data.SqlClient
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
  Friend WithEvents TextBox2 As System.Windows.Forms.TextBox

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.TextBox1 = New System.Windows.Forms.TextBox()
    Me.TextBox2 = New System.Windows.Forms.TextBox()
    Me.SuspendLayout()
    '
    'TextBox1
    '
    Me.TextBox1.Location = New System.Drawing.Point(24, 32)
    Me.TextBox1.Name = "TextBox1"
    Me.TextBox1.TabIndex = 0
    Me.TextBox1.Text = "TextBox1"
    '
    'TextBox2
    '
    Me.TextBox2.Location = New System.Drawing.Point(24, 96)
    Me.TextBox2.Name = "TextBox2"
    Me.TextBox2.TabIndex = 1
    Me.TextBox2.Text = "TextBox2"
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 266)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox2, Me.TextBox1})
    Me.Name = "Form1"
    Me.Text = "Form1"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Conexi�n con la base de datos
    Dim Conexion As SqlConnection = New SqlConnection( _
       "server=INSPIRON;uid=sa;pwd=;database=pubs")

    ' Vamos a recuperar toda una tabla
    Dim Comando As SqlDataAdapter = New _
      SqlDataAdapter("SELECT * FROM authors", Conexion)

    ' Creamos un DataSet vac�o
    Dim MiDataSet As DataSet = New DataSet()
    ' lo llenamos con la tabla
    Comando.Fill(MiDataSet, "Autores")

    ' Enlazamos las cajas de texto con
    ' columnas de la tabla
    TextBox1.DataBindings.Add( _
     "Text", MiDataSet, "Autores.au_fname")
    TextBox2.DataBindings.Add( _
     "Text", MiDataSet, "Autores.au_lname")
  End Sub
End Class
