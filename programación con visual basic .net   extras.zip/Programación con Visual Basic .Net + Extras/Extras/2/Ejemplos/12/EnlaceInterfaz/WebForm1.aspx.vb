Imports System.Data.SqlClient
Public Class WebForm1
  Inherits System.Web.UI.Page
  Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

  'This call is required by the Web Form Designer.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

  End Sub

  Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    'CODEGEN: This method call is required by the Web Form Designer
    'Do not modify it using the code editor.
    InitializeComponent()
  End Sub

#End Region

  Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Conexi�n con la base de datos
    Dim Conexion As SqlConnection = New SqlConnection( _
       "server=INSPIRON;uid=sa;pwd=;database=pubs")

    ' Vamos a recuperar toda una tabla
    Dim Comando As SqlDataAdapter = New _
       SqlDataAdapter("SELECT * FROM authors", Conexion)

    ' Creamos un DataSet vac�o
    Dim MiDataSet As DataSet = New DataSet()

    ' lo llenamos con la tabla
    Comando.Fill(MiDataSet, "Autores")

    ' Enlazamos el DataGrid con la tabla de datos
    DataGrid1.DataSource = MiDataSet.Tables("Autores")
    DataGrid1.DataBind()

  End Sub

End Class
