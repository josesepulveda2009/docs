Imports System.Drawing.Drawing2D
Public Class Form1
  Inherits System.Windows.Forms.Form

  ' T�tulo del informe
  Private Titulo As String = _
         "Informe sobre uso de lenguajes"

  ' Lenguakes supuestamente estudiados
  Private Titulos() As String = { _
     "Visual Basic", "C++", "Java", _
     "Delphi", "Otros"}

  ' Datos hipot�ticos de los lenguajes
  Private Datos() As String = { _
     "32%", "27%", "15%", "12%", "14%"}

  ' Puntos para el gr�fico sectorial
  Private Puntos(,) As Single = { _
    {0, 32 * 3.6}, {32 * 3.6, 27 * 3.6}, _
    {(32 + 27) * 3.6, 15 * 3.6}, _
    {(32 + 27 + 15) * 3.6, 12 * 3.6}, _
    {(32 + 27 + 15 + 12) * 3.6, 14 * 3.6}}

  ' Estilos de relleno para cada sector
  Private Relleno() As HatchStyle = { _
    HatchStyle.BackwardDiagonal, _
    HatchStyle.Cross, HatchStyle.DashedHorizontal, _
    HatchStyle.LightDownwardDiagonal, _
    HatchStyle.DottedDiamond}

  ' L�nea que est� imprimi�ndose
  Private LineaTexto As Byte

  ' Texto del informe
  Private Texto() As String = { _
   "Seg�n el �ltimo sondeo efectuado por la pres-", _
   "tigiosa  revista Mundo  Bits, Visual Basic es", _
   "actualmente el  lenguaje de  programaci�n m�s", _
   "utilizado a nivel mundial, seguido de cerca -", _
   "por C++.", _
   "M�s distantes quedan Java, Delphi y lenguajes", _
   "minoritarios como FORTRAN o COBOL.", _
   "Este estudio se ha centrado en  los lenguajes", _
   "considerados de 'prop�sito general', aquellos", _
   "que pueden utilizarse  para desarrollar tanto", _
   "aplicaciones cl�sicas, basadas en  interfaces", _
   "de usuario  gr�ficas con conexi�n a  bases de", _
   "datos, como componentes  discretos, programas", _
   "de servidor web y librer�as conteniendo c�di-", _
   "go  precompilado listo para  reutilizar,  por", _
   "ejemplo en forma de controles  ActiveX o com-", _
   "ponentes JavaBeans.", _
   "Seg�n el �ltimo sondeo efectuado por la pres-", _
  "tigiosa  revista Mundo  Bits, Visual Basic es", _
  "actualmente el  lenguaje de  programaci�n m�s", _
  "utilizado a nivel mundial, seguido de cerca -", _
  "por C++.", _
  "M�s distantes quedan Java, Delphi y lenguajes", _
  "minoritarios como FORTRAN o COBOL.", _
  "Este estudio se ha centrado en  los lenguajes", _
  "considerados de 'prop�sito general', aquellos", _
  "que pueden utilizarse  para desarrollar tanto", _
  "aplicaciones cl�sicas, basadas en  interfaces", _
  "de usuario  gr�ficas con conexi�n a  bases de", _
  "datos, como componentes  discretos, programas", _
  "de servidor web y librer�as conteniendo c�di-", _
  "go  precompilado listo para  reutilizar,  por", _
  "ejemplo en forma de controles  ActiveX o com-", _
  "ponentes JavaBeans.", _
  "Seg�n el �ltimo sondeo efectuado por la pres-", _
  "tigiosa  revista Mundo  Bits, Visual Basic es", _
  "actualmente el  lenguaje de  programaci�n m�s", _
  "utilizado a nivel mundial, seguido de cerca -", _
  "por C++.", _
  "M�s distantes quedan Java, Delphi y lenguajes", _
  "minoritarios como FORTRAN o COBOL.", _
  "Este estudio se ha centrado en  los lenguajes", _
  "considerados de 'prop�sito general', aquellos", _
  "que pueden utilizarse  para desarrollar tanto", _
  "aplicaciones cl�sicas, basadas en  interfaces", _
  "de usuario  gr�ficas con conexi�n a  bases de", _
  "datos, como componentes  discretos, programas", _
  "de servidor web y librer�as conteniendo c�di-", _
  "go  precompilado listo para  reutilizar,  por", _
  "ejemplo en forma de controles  ActiveX o com-", _
   "ponentes JavaBeans." _
  }

    Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents tbNombreImpresora As System.Windows.Forms.TextBox
  Friend WithEvents Button2 As System.Windows.Forms.Button
  Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
  Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
  Friend WithEvents PageSetupDialog1 As System.Windows.Forms.PageSetupDialog
  Friend WithEvents Button3 As System.Windows.Forms.Button
  Friend WithEvents PrintPreviewControl1 As System.Windows.Forms.PrintPreviewControl
  Private PosY As Integer
#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
  Friend WithEvents Button1 As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
    Me.PageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
    Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
    Me.tbNombreImpresora = New System.Windows.Forms.TextBox()
    Me.Button1 = New System.Windows.Forms.Button()
    Me.Button2 = New System.Windows.Forms.Button()
    Me.Button3 = New System.Windows.Forms.Button()
    Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
    Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
    Me.ListBox1 = New System.Windows.Forms.ListBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.PrintPreviewControl1 = New System.Windows.Forms.PrintPreviewControl()
    Me.SuspendLayout()
    '
    'PageSetupDialog1
    '
    Me.PageSetupDialog1.Document = Me.PrintDocument1
    '
    'PrintPreviewDialog1
    '
    Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
    Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
    Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
    Me.PrintPreviewDialog1.Document = Me.PrintDocument1
    Me.PrintPreviewDialog1.Enabled = True
    Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
    Me.PrintPreviewDialog1.Location = New System.Drawing.Point(266, 24)
    Me.PrintPreviewDialog1.MaximumSize = New System.Drawing.Size(0, 0)
    Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
    Me.PrintPreviewDialog1.Opacity = 1
    Me.PrintPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
    Me.PrintPreviewDialog1.UseAntiAlias = True
    Me.PrintPreviewDialog1.Visible = False
    '
    'tbNombreImpresora
    '
    Me.tbNombreImpresora.Location = New System.Drawing.Point(8, 32)
    Me.tbNombreImpresora.Name = "tbNombreImpresora"
    Me.tbNombreImpresora.ReadOnly = True
    Me.tbNombreImpresora.Size = New System.Drawing.Size(208, 20)
    Me.tbNombreImpresora.TabIndex = 2
    Me.tbNombreImpresora.Text = ""
    '
    'Button1
    '
    Me.Button1.Location = New System.Drawing.Point(168, 216)
    Me.Button1.Name = "Button1"
    Me.Button1.TabIndex = 0
    Me.Button1.Text = "Imprimir"
    '
    'Button2
    '
    Me.Button2.Location = New System.Drawing.Point(232, 24)
    Me.Button2.Name = "Button2"
    Me.Button2.Size = New System.Drawing.Size(56, 24)
    Me.Button2.TabIndex = 3
    Me.Button2.Text = "Cambiar"
    '
    'Button3
    '
    Me.Button3.Location = New System.Drawing.Point(8, 216)
    Me.Button3.Name = "Button3"
    Me.Button3.Size = New System.Drawing.Size(104, 23)
    Me.Button3.TabIndex = 6
    Me.Button3.Text = "Configurar p�gina"
    '
    'PrintDialog1
    '
    Me.PrintDialog1.Document = Me.PrintDocument1
    '
    'PrintDocument1
    '
    '
    'ListBox1
    '
    Me.ListBox1.Location = New System.Drawing.Point(8, 88)
    Me.ListBox1.Name = "ListBox1"
    Me.ListBox1.Size = New System.Drawing.Size(168, 95)
    Me.ListBox1.TabIndex = 5
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(8, 16)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(136, 23)
    Me.Label1.TabIndex = 1
    Me.Label1.Text = "Impresora seleccionada"
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(8, 72)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(208, 23)
    Me.Label2.TabIndex = 4
    Me.Label2.Text = "Impresoras disponibles"
    '
    'PrintPreviewControl1
    '
    Me.PrintPreviewControl1.AutoZoom = False
    Me.PrintPreviewControl1.Document = Me.PrintDocument1
    Me.PrintPreviewControl1.Location = New System.Drawing.Point(320, 24)
    Me.PrintPreviewControl1.Name = "PrintPreviewControl1"
    Me.PrintPreviewControl1.Size = New System.Drawing.Size(328, 224)
    Me.PrintPreviewControl1.TabIndex = 7
    Me.PrintPreviewControl1.UseAntiAlias = False
    Me.PrintPreviewControl1.Zoom = 1
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(664, 262)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PrintPreviewControl1, Me.Button3, Me.ListBox1, Me.Label2, Me.Button2, Me.tbNombreImpresora, Me.Label1, Me.Button1})
    Me.Name = "Form1"
    Me.Text = "Impresi�n simple"
    Me.ResumeLayout(False)

  End Sub

#End Region

  ' Al pulsar el bot�n que hay en el formulario
  Private Sub Button1_Click(ByVal sender _
  As System.Object, ByVal e As System.EventArgs) _
  Handles Button1.Click
    PrintPreviewDialog1.ShowDialog()
  End Sub

  ' En este m�todo se controlar� toda la impresi�n
  Private Sub PrintDocument1_PrintPage( _
  ByVal sender As Object, ByVal e As _
  System.Drawing.Printing.PrintPageEventArgs) _
  Handles PrintDocument1.PrintPage

    ' Tipos de letra a usar para los distintos
    ' elementos que van a imprimirse
    Dim TipoTexto As Font = New _
      Font("Courier New", 14, FontStyle.Regular)
    Dim TipoTitulo As Font = New _
      Font("Arial", 24, FontStyle.Bold)
    Dim TipoTitulosDatos As Font = New _
      Font("Courier New", 12, _
          FontStyle.Underline Or FontStyle.Bold)
    Dim TipoDatos As Font = New _
      Font("Courier New", 10, FontStyle.Italic)

    ' Brocha y l�piz para los dibujos
    Dim Brocha As Brush
    Dim Lapiz As Pen = New Pen(Color.Black, 3)

    If LineaTexto = 0 Then ' Si es la primera l�nea
      ' tomamos la posici�n de la primera l�nea
      PosY = e.MarginBounds.Y
      ' y dibujamos el t�tulo del informe
      Dim Tamano As SizeF = _
        e.Graphics.MeasureString(Titulo, TipoTitulo)
      ' centr�ndolo en la parte superior de la 
      ' p�gina
      e.Graphics.DrawString(Titulo, TipoTitulo, _
        Brushes.Black, (e.PageBounds.Width - _
        Tamano.Width) / 2, PosY)

      ' Actualizamos la posici�n vertical
      PosY += Tamano.Height * 2
    End If

    Dim Indice As Byte ' para los bucles
    ' Alto de una l�nea de texto normal
    Dim AltoLinea As Integer = _
                  TipoTexto.GetHeight(e.Graphics)

    ' Recorremos todas las l�neas de texto
    For Indice = LineaTexto To Texto.GetUpperBound(0)
      ' imprimi�ndolas en la posici�n adecuada
      e.Graphics.DrawString(Texto(Indice), TipoTexto, _
            Brushes.Black, e.MarginBounds.Left, PosY)
      ' Actualizamos la posici�n vertical
      PosY += AltoLinea

      ' Si estamos al final de la p�gina
      If PosY + AltoLinea >= e.MarginBounds.Bottom Then
        ' recordamos la l�nea en la que estamos
        LineaTexto = Indice
        ' retomamos la posici�n vertical
        PosY = e.MarginBounds.Top
        ' e indicamos que hay m�s p�ginas
        e.HasMorePages = True
        Exit Sub ' abandonando el m�todo
      End If
    Next

    ' Al llegar aqu� ya hemos terminado de
    ' imprimir el texto del informe
    LineaTexto = Texto.GetUpperBound(0) + 1
    ' y actualizamos la posici�n vertical
    PosY += AltoLinea * 2

    ' Comprobamos si queda espacio para los datos
    If PosY + TipoTitulosDatos.GetHeight(e.Graphics) _
          * 2 > e.MarginBounds.Bottom Then
      ' Si no es as� retomamos la posici�n
      PosY = e.MarginBounds.Top
      ' indicamos que hay m�s p�ginas
      e.HasMorePages = True
      Exit Sub ' y salimos
    End If

    ' Vamos a imprimir los t�tulos y datos

    ' Tomamos la posici�n horizontal inicial
    Dim PosX As Integer = e.MarginBounds.Left
    ' y calculamos el alto de una l�nea
    AltoLinea = TipoTitulosDatos.GetHeight(e.Graphics)

    ' Recorremos los t�tulos a imprimir
    For Indice = 0 To Titulos.GetUpperBound(0)
      ' imprimimos el t�tulo
      e.Graphics.DrawString(Titulos(Indice), _
       TipoTitulosDatos, Brushes.Black, PosX, PosY)
      ' y debajo el porcentaje
      e.Graphics.DrawString(Datos(Indice), _
        TipoDatos, Brushes.Black, PosX, _
        PosY + AltoLinea)

      ' preparamos una brocha de relleno
      Brocha = New HatchBrush(Relleno(Indice), _
         Color.Black, Color.White)
      ' para dibujar un rect�ngulo debajo de
      ' cada t�tulo
      e.Graphics.FillRectangle(Brocha, PosX, _
         PosY + AltoLinea * 2, 20, 20)
      ' Actualizamos la posici�n horizontal
      PosX += e.Graphics.MeasureString( _
        Titulos(Indice), TipoTitulosDatos).Width + 10
    Next

    ' Vamos a dibujar el gr�fico sectorial

    ' Obtenemos la posici�n de origen
    PosY += AltoLinea * 2 + 30
    PosX = e.MarginBounds.Left
    ' y las dimensiones del gr�fico
    Dim Alto As Single = e.MarginBounds.Height - PosY
    Dim Ancho As Single = e.MarginBounds.Width

    ' Forzamos que el gr�fico sea circular
    If Alto > Ancho Then Alto = Ancho
    If Ancho > Alto Then Ancho = Alto

    ' Recorremos los datos a dibujar
    For Indice = 0 To Datos.GetUpperBound(0)
      ' preparamos una brocha de relleno
      Brocha = New HatchBrush(Relleno(Indice), _
        Color.Black, Color.White)

      ' rellenamos el sector
      e.Graphics.FillPie(Brocha, PosX, PosY, _
        Ancho, Alto, Puntos(Indice, 0), _
        Puntos(Indice, 1))
      ' y dibujamos el contorno
      e.Graphics.DrawPie(Lapiz, PosX, PosY, _
        Ancho, Alto, Puntos(Indice, 0), _
        Puntos(Indice, 1))
    Next
  End Sub

  ' Al iniciarse la impresi�n
  Private Sub PrintDocument1_BeginPrint( _
  ByVal sender As Object, ByVal e As _
  System.Drawing.Printing.PrintEventArgs) _
  Handles PrintDocument1.BeginPrint
    LineaTexto = 0 ' comenzar por la primera l�nea
  End Sub

  ' Al abrir el formulario
  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim Impresora As String
    ' Recorremos la lista de impresoras instaladas
    For Each Impresora In _
      PrintDocument1.PrinterSettings.InstalledPrinters
      ' a�adi�ndolas a la lista
      ListBox1.Items.Add(Impresora)
    Next
    ' mostrar el nombre de la impresora
    tbNombreImpresora.Text = _
      PrintDocument1.PrinterSettings.PrinterName
  End Sub

  ' Si se pulsa el bot�n de cambio
  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
    ' Mostramos el cuadro de di�logo y si se pulsa
    ' el bot�n OK
    If PrintDialog1.ShowDialog = DialogResult.OK Then
      ' actualizamos el nombre de la impresora
      tbNombreImpresora.Text = _
        PrintDocument1.PrinterSettings.PrinterName
    End If

  End Sub

  Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
    PageSetupDialog1.ShowDialog()
  End Sub
End Class
