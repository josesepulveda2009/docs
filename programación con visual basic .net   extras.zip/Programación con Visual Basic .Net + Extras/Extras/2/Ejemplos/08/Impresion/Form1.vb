Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
  Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
  Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
  Friend WithEvents PrintPreviewControl1 As System.Windows.Forms.PrintPreviewControl
  Friend WithEvents PageSetupDialog1 As System.Windows.Forms.PageSetupDialog
  Friend WithEvents reportDocument1 As CrystalDecisions.CrystalReports.Engine.ReportDocument
  Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
    Me.PageSetupDialog1 = New System.Windows.Forms.PageSetupDialog()
    Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
    Me.PrintPreviewControl1 = New System.Windows.Forms.PrintPreviewControl()
    Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
    Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
    Me.reportDocument1 = New CrystalDecisions.CrystalReports.Engine.ReportDocument()
    Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
    Me.SuspendLayout()
    '
    'PrintPreviewDialog1
    '
    Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
    Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
    Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
    Me.PrintPreviewDialog1.Enabled = True
    Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
    Me.PrintPreviewDialog1.Location = New System.Drawing.Point(110, 145)
    Me.PrintPreviewDialog1.MaximumSize = New System.Drawing.Size(0, 0)
    Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
    Me.PrintPreviewDialog1.Opacity = 1
    Me.PrintPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
    Me.PrintPreviewDialog1.Visible = False
    '
    'PrintPreviewControl1
    '
    Me.PrintPreviewControl1.AutoZoom = False
    Me.PrintPreviewControl1.Document = Me.PrintDocument1
    Me.PrintPreviewControl1.Location = New System.Drawing.Point(8, 16)
    Me.PrintPreviewControl1.Name = "PrintPreviewControl1"
    Me.PrintPreviewControl1.Size = New System.Drawing.Size(296, 232)
    Me.PrintPreviewControl1.TabIndex = 0
    Me.PrintPreviewControl1.UseAntiAlias = False
    Me.PrintPreviewControl1.Zoom = 1
    '
    'PrintDocument1
    '
    '
    'reportDocument1
    '
    Me.reportDocument1.PrintOptions.PaperOrientation = CrystalDecisions.Shared.PaperOrientation.DefaultPaperOrientation
    Me.reportDocument1.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.DefaultPaperSize
    Me.reportDocument1.PrintOptions.PaperSource = CrystalDecisions.Shared.PaperSource.Upper
    Me.reportDocument1.PrintOptions.PrinterDuplex = CrystalDecisions.Shared.PrinterDuplex.Default
    '
    'CrystalReportViewer1
    '
    Me.CrystalReportViewer1.ActiveViewIndex = -1
    Me.CrystalReportViewer1.DisplayGroupTree = False
    Me.CrystalReportViewer1.Location = New System.Drawing.Point(8, 256)
    Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
    Me.CrystalReportViewer1.ReportSource = "F:\DatosTrabajo\Libros\Actuales\GPVisualBasicNET\Ejemplos\08\Impresion\CrystalRep" & _
    "ort1.rpt"
    Me.CrystalReportViewer1.Size = New System.Drawing.Size(432, 184)
    Me.CrystalReportViewer1.TabIndex = 1
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(456, 446)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.CrystalReportViewer1, Me.PrintPreviewControl1})
    Me.Name = "Form1"
    Me.Text = "Form1"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub PrintDocument1_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
    Dim TipoLetra As Font = New Font("Courier New", 14, FontStyle.Bold)
    Dim Recuadro As Rectangle = e.PageBounds
    Recuadro.Inflate(-20, -20)
    e.Graphics.DrawRectangle(Pens.Black, Recuadro)
    e.Graphics.DrawString("Hola", TipoLetra, Brushes.Black, 30, 30)
    e.HasMorePages = False
  End Sub

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    '    PageSetupDialog1.Document = PrintDocument1
    '    PageSetupDialog1.ShowDialog()
    '   PrintPreviewDialog1.Document = PrintDocument1
    '  PrintPreviewDialog1.ShowDialog()
    Dim Informe As CrystalReport1 = New CrystalReport1()
    Informe.ExportOptions.ExportFormatType = _
          CrystalDecisions.[Shared].ExportFormatType.HTML40
    Informe.ExportOptions.ExportDestinationType = _
          CrystalDecisions.[Shared].ExportDestinationType.DiskFile
    Informe.ExportOptions.DestinationOptions.diskfilename = "G:\Informe.html"

    Informe.Export()

    '    PrintDialog1.Document = PrintDocument1
    '    If PrintDialog1.ShowDialog() = DialogResult.OK Then
    '    PrintDocument1.Print()
    '    End If
  End Sub

  Private Sub reportDocument1_InitReport(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reportDocument1.InitReport
  End Sub
End Class
