Public Class frmArchivo
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
  Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
  Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
  Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
  Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.MainMenu1 = New System.Windows.Forms.MainMenu()
    Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
    Me.TextBox1 = New System.Windows.Forms.TextBox()
    Me.MenuItem1 = New System.Windows.Forms.MenuItem()
    Me.SuspendLayout()
    '
    'MainMenu1
    '
    Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
    '
    'TextBox1
    '
    Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.TextBox1.Multiline = True
    Me.TextBox1.Name = "TextBox1"
    Me.TextBox1.Size = New System.Drawing.Size(292, 266)
    Me.TextBox1.TabIndex = 0
    Me.TextBox1.Text = "TextBox1"
    '
    'MenuItem1
    '
    Me.MenuItem1.Index = 0
    Me.MenuItem1.Text = "Cambiar color"
    '
    'frmArchivo
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 266)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1})
    Me.Menu = Me.MainMenu1
    Me.Name = "frmArchivo"
    Me.Text = "frmArchivo"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click
    ' Si se selecciona un color
    If ColorDialog1.ShowDialog() = DialogResult.OK Then
      ' lo establecemos como color del texto
      TextBox1.ForeColor = ColorDialog1.Color
    End If

  End Sub
End Class
