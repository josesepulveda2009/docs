Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents lbParametros As System.Windows.Forms.ListBox
  
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.lbParametros = New System.Windows.Forms.ListBox()
    Me.SuspendLayout()
    '
    'lbParametros
    '
    Me.lbParametros.Dock = System.Windows.Forms.DockStyle.Fill
    Me.lbParametros.Name = "lbParametros"
    Me.lbParametros.Size = New System.Drawing.Size(292, 264)
    Me.lbParametros.TabIndex = 0
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 266)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lbParametros})
    Me.Name = "Form1"
    Me.Text = "Informaci�n del entorno"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Matriz con los datos a recuperar
    Dim Datos() = { _
    "StartupPath= " + Application.StartupPath, _
    "ExecutablePath= " + _
          Application.ExecutablePath, _
    "CompanyName= " + Application.CompanyName, _
    "ProductName= " + Application.ProductName, _
    "ProductVersion= " + _
          Application.ProductVersion, _
    "UserAppDataPath= " + _
          Application.UserAppDataPath, _
    "CommonAppDataPath= " + _
    Application.CommonAppDataPath() _
}

    Dim Indice As Byte
    ' Recorremos la matriz a�adiendo los datos 
    ' a la lista
    For Indice = 0 To Datos.GetUpperBound(0) - 1
      lbParametros.Items.Add(Datos(Indice))
    Next
  End Sub
End Class
