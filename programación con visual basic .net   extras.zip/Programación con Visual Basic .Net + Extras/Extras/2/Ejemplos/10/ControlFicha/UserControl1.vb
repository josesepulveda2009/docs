Imports System.ComponentModel
Public Class UserControl1
  Inherits System.Windows.Forms.UserControl
  ' Creamos los componentes que tendr�
  Private lblNombre As Label
  Private txtNombre As TextBox
  Private lblTelefono As Label
  Private txtTelefono As TextBox

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call


  End Sub
  ' Definimos dos propiedades que permitan
  ' asignar y recuperar el Nombre y Tel�fono
  Public Property Nombre() As String
    Get
      Return txtNombre.Text
    End Get
    Set(ByVal Value As String)
      txtNombre.Text = Value

    End Set
  End Property

  Public Property Telefono() As String
    Get
      Return txtTelefono.Text
    End Get
    Set(ByVal Value As String)
      txtTelefono.Text = Value
    End Set
  End Property

  'UserControl1 overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    components = New System.ComponentModel.Container()
    lblNombre = New Label()
    txtNombre = New TextBox()
    lblTelefono = New Label()
    txtTelefono = New TextBox()
    ' para establecer las propiedades
    lblNombre.Location = New Point(8, 8)
    lblNombre.Text = "Nombre"
    lblNombre.AutoSize = True

    ' de los distintos controles
    txtNombre.Location = New Point(8, 24)
    txtNombre.Size = New Size(100, 20)

    lblTelefono.Location = New Point(8, 64)
    lblTelefono.Text = "Tel�fono"
    lblTelefono.AutoSize = True

    txtTelefono.Location = New Point(8, 80)
    txtTelefono.Size = New Size(100, 20)

    ' que finalmente a�adimos al UserControl
    Controls.Add(lblNombre)
    Controls.Add(txtNombre)
    Controls.Add(lblTelefono)
    Controls.Add(txtTelefono)

    ' Fijamos el tama�o del control
    Size = New Size(120, 120)

  End Sub

#End Region

End Class
