Imports System.Windows.Forms
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports Microsoft.VisualBasic

Namespace Anaya.GuiaVBNET.ControlBinario
  ' Esta clase, derivada de Component,
  ' es nuestro componente
  Public Class Convertidor
    Inherits System.Windows.Forms.Control
    ' tenemos dos variables internas que
    ' mantendr�n el valor actual
    Private Fbinario As String = "0"
    Private Fvalor As Integer = 0

    Protected Overrides Sub OnPaint(ByVal Args As PaintEventArgs)
      Args.Graphics.DrawString(Fbinario, Font, _
         New SolidBrush(ForeColor), ClientRectangle.Left, ClientRectangle.Top)
    End Sub

    ' la propiedad Binario permitir� la
    ' asignaci�n y lectura del valor en binario
    Public Property Binario() As String
      ' la lectura devuelve el contenido 
      Get
        Return Fbinario ' de la variable
      End Get

      ' al asignar lo primero que hacemos
      Set(ByVal Value As String)
        Fbinario = Value ' es guardar el nuevo valor
        Fvalor = 0

        ' que convertimos en un n�mero decimal
        Dim Contador As Integer
        Dim Exp As Integer = 0
        For Contador = Binario.Length To 1 Step -1
          ' vamos calculando el valor de cada d�gito
          ' y sum�ndolo
          Fvalor += System.Math.Pow(2, Exp) * _
            (Asc(Mid(Fbinario, Contador, 1)) - 48)
          Exp += 1
        Next
      End Set
    End Property

    ' la propiedad Valor facilita la lectura
    ' y asignaci�n del valor en decimal
    Public Property Valor() As Integer
      ' la lectura devuelve el valor de la variable
      Get
        Return Fvalor
      End Get

      ' al asignar guardamos el nuevo valor
      Set(ByVal Value As Integer)
        Fvalor = Value
        Fbinario = ""
        ' y vamos dividiendo el n�mero decimal 
        ' entre(2) guardando todos los restos 
        ' como d�gitos binarios
        Do While Value >= 2
          Fbinario = IIf(Value Mod 2 = 0, "0", "1") _
            & Fbinario
          Value /= 2
        Loop
        ' conservamos el �ltimo cociente 
        ' como primer d�gito
        Fbinario = (Chr(Value + 48)) & Binario
      End Set
    End Property
  End Class
End Namespace
