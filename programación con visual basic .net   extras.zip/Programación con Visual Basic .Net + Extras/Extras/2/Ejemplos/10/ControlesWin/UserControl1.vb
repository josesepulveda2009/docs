Imports System.ComponentModel
Public Class Convertidor
  Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'UserControl1 overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    '
    'UserControl1
    '
    Me.Name = "UserControl1"
    Me.Size = New System.Drawing.Size(120, 32)

  End Sub

#End Region
  ' tenemos dos variables internas que
  ' mantendr�n el valor actual
  Private Fbinario As String = "0"
  Private Fvalor As Integer = 0

  Protected Overrides Sub OnPaint(ByVal Args As PaintEventArgs)
    Args.Graphics.DrawString(Fbinario, Font, _
       New SolidBrush(ForeColor), ClientRectangle.Left, ClientRectangle.Top)
  End Sub

  ' la propiedad Binario permitir� la
  ' asignaci�n y lectura del valor en binario
  <Browsable(False)> _
  Public Property Binario() As String
    ' la lectura devuelve el contenido 
    Get
      Return Fbinario ' de la variable
    End Get

    ' al asignar lo primero que hacemos
    Set(ByVal Value As String)
      Fbinario = Value ' es guardar el nuevo valor
      Fvalor = 0

      ' que convertimos en un n�mero decimal
      Dim Contador As Integer
      Dim Exp As Integer = 0
      For Contador = Binario.Length To 1 Step -1
        ' vamos calculando el valor de cada d�gito
        ' y sum�ndolo
        Fvalor += System.Math.Pow(2, Exp) * _
          (Asc(Mid(Fbinario, Contador, 1)) - 48)
        Exp += 1
      Next
      Invalidate() ' actualizamos
    End Set
  End Property

  ' la propiedad Valor facilita la lectura
  ' y asignaci�n del valor en decimal
  <Category("Apariencia"), _
   Description("Contiene el valor en decimal"), _
 DefaultValue(0)> _
  Public Property Valor() As Integer
    ' la lectura devuelve el valor de la variable
    Get
      Return Fvalor
    End Get

    ' al asignar guardamos el nuevo valor
    Set(ByVal Value As Integer)
      Fvalor = Value
      Fbinario = ""
      ' y vamos dividiendo el n�mero decimal 
      ' entre(2) guardando todos los restos 
      ' como d�gitos binarios
      Do While Value >= 2
        Fbinario = IIf(Value Mod 2 = 0, "0", "1") _
          & Fbinario
        Value \= 2
      Loop
      ' conservamos el �ltimo cociente 
      ' como primer d�gito
      Fbinario = (Chr(Value + 48)) & Binario

      Invalidate() ' actualizamos
    End Set
  End Property

End Class
