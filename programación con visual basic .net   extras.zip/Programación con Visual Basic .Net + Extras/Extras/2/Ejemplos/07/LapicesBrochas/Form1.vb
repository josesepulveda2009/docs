Imports System.Drawing.Drawing2D
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents Button1 As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.Button1 = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'Button1
    '
    Me.Button1.Location = New System.Drawing.Point(232, 240)
    Me.Button1.Name = "Button1"
    Me.Button1.Size = New System.Drawing.Size(56, 24)
    Me.Button1.TabIndex = 0
    Me.Button1.Text = "L�pices"
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 266)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button1})
    Me.Name = "Form1"
    Me.Text = "Brochas"
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub Form1_Paint(ByVal sender As Object, _
  ByVal e As System.Windows.Forms.PaintEventArgs) _
  Handles MyBase.Paint

    ' Definimos el �rea base para dibujar
    ' los distintos rect�ngulos
    Dim Rectangulo As Rectangle = New _
      Rectangle(10, 10, 100, 100)

    ' Una brocha de transici�n entre dos colores
    ' en sentido diagonal
    Dim BrochaFundido As LinearGradientBrush = _
     New LinearGradientBrush(Rectangulo, _
     Color.Yellow, Color.Red, _
     LinearGradientMode.BackwardDiagonal)

    ' Una brocha s�lida con color a medida
    Dim BrochaSimple As SolidBrush = _
      New SolidBrush(Color.FromArgb(128, 0, 64))

    ' Una brocha con una patr�n predefindo
    Dim BrochaPatron As HatchBrush = _
      New HatchBrush(HatchStyle.Plaid, _
      Color.YellowGreen)

    ' Y una brocha con una textura gr�fica
    Dim BrochaImagen As TextureBrush = _
      New TextureBrush( _
      New Bitmap("C:\Windows\Nubes.bmp"))

    ' Un tipo de letra cualquiera
    Dim Tipo As Font = _
      New Font("Courier New", 24, FontStyle.Bold)

    With e.Graphics ' A dibujar
      ' Dibujamos el primer rect�ngulo con 
      ' la brocha de transici�n entre colores
      .FillRectangle(BrochaFundido, Rectangulo)
      ' y nos deplazamos cien puntos a la derecha
      Rectangulo.Offset(100, 0)
      ' para dibujar el siguiente rect�ngulo
      .FillRectangle(BrochaSimple, Rectangulo)
      ' ahora cien puntos a la izquierda y abajo
      Rectangulo.Offset(-100, 100)
      ' para dibujar otro rect�ngulo
      .FillRectangle(BrochaPatron, Rectangulo)
      ' y finalmente cien puntos m�s a la derecha
      Rectangulo.Offset(100, 0)
      ' para dibujar el �ltimo
      .FillRectangle(BrochaImagen, Rectangulo)

      ' Usamos dos de las brochas para escribir
      ' un mismo texto
      .DrawString("Brochas", Tipo, _
        BrochaImagen, 20, 210)
      .DrawString("Brochas", Tipo, _
        BrochaFundido, 120, 230)
    End With
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    Dim Lapices As frmLapices = New frmLapices()
    Lapices.ShowDialog()
  End Sub
End Class
