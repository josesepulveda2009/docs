Imports System
Imports System.Drawing.Drawing2D

Public Class frmLapices
  Inherits System.Windows.Forms.Form

  ' Miembros necesarios para mantener una lista
  ' de los estilos y terminadores existentes
  Private Terminadores As Array
  Private Trazos As Array
  ' as� como el terminador y el estilo elegidos
  Private Terminador As LineCap
  Private Trazo As DashStyle
#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents cbTrazo As System.Windows.Forms.ComboBox
  Friend WithEvents cbTerminadores As System.Windows.Forms.ComboBox
  Friend WithEvents Label2 As System.Windows.Forms.Label

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.cbTerminadores = New System.Windows.Forms.ComboBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.cbTrazo = New System.Windows.Forms.ComboBox()
    Me.SuspendLayout()
    '
    'cbTerminadores
    '
    Me.cbTerminadores.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cbTerminadores.DropDownWidth = 121
    Me.cbTerminadores.Location = New System.Drawing.Point(160, 24)
    Me.cbTerminadores.Name = "cbTerminadores"
    Me.cbTerminadores.Size = New System.Drawing.Size(121, 21)
    Me.cbTerminadores.TabIndex = 1
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(16, 8)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(70, 13)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "Tipo de trazo"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(160, 8)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(74, 13)
    Me.Label2.TabIndex = 0
    Me.Label2.Text = "Terminadores"
    '
    'cbTrazo
    '
    Me.cbTrazo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.cbTrazo.DropDownWidth = 121
    Me.cbTrazo.Location = New System.Drawing.Point(16, 24)
    Me.cbTrazo.Name = "cbTrazo"
    Me.cbTrazo.Size = New System.Drawing.Size(121, 21)
    Me.cbTrazo.TabIndex = 1
    '
    'frmLapices
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(304, 266)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cbTerminadores, Me.Label2, Me.cbTrazo, Me.Label1})
    Me.Name = "frmLapices"
    Me.Text = "frmLapices"
    Me.ResumeLayout(False)

  End Sub

#End Region

  ' Al abrirse el formulario
  Private Sub frmLapices_Load( _
  ByVal sender As System.Object, _
  ByVal e As System.EventArgs) Handles MyBase.Load

    ' Recuperamos la lista de terminadores
    Terminadores = System.Enum.GetValues( _
                               GetType(LineCap))
    ' y la lista de estilos
    Trazos = System.Enum.GetValues( _
                               GetType(DashStyle))

    ' Recorremos esas listas a�adiendo el nombre
    For Each Terminador In Terminadores
      ' de cada terminador al ComboBox
      cbTerminadores.Items.Add(Terminador.ToString())
    Next

    ' que corresponda
    For Each Trazo In Trazos
      cbTrazo.Items.Add(Trazo.ToString())
    Next

    ' Seleccionamos el primer terminador y estilo
    cbTerminadores.SelectedIndex = 0
    cbTrazo.SelectedIndex = 0
  End Sub

  ' Cada vez que se cambie el tipo de trazo
  Private Sub cbTrazo_SelectedIndexChanged( _
  ByVal sender As Object, _
  ByVal e As System.EventArgs) _
  Handles cbTrazo.SelectedIndexChanged
    ' Recuperamos el trazo seleccionado
    Trazo = Trazos(cbTrazo.SelectedIndex)
    Invalidate() ' y redibujamos
  End Sub

  ' Lo mismo si se cambia el tipo de terminador
  Private Sub cbTerminadores_SelectedIndexChanged( _
  ByVal sender As Object, _
  ByVal e As System.EventArgs) _
  Handles cbTerminadores.SelectedIndexChanged
    Terminador = Terminadores( _
       cbTerminadores.SelectedIndex)
    Invalidate()
  End Sub

  ' Cada vez que haya que dibujar el formulario
  Private Sub frmLapices_Paint( _
  ByVal sender As Object, _
  ByVal e As System.Windows.Forms.PaintEventArgs) _
  Handles MyBase.Paint
    ' Definimos una  brocha con una patr�n
    Dim BrochaPatron As HatchBrush = _
      New HatchBrush(HatchStyle.Sphere, _
      Color.Olive)
    ' y la usamos para construir el l�piz
    Dim Lapiz As Pen = New Pen(BrochaPatron, 8)

    ' Definimos el �rea base para una brocha
    Dim Rectangulo As Rectangle = New _
      Rectangle(250, 150, 100, 150)

    ' De transici�n entre dos colores
    ' en sentido diagonal
    Dim BrochaFundido As LinearGradientBrush = _
     New LinearGradientBrush(Rectangulo, _
     Color.Yellow, Color.Red, _
     LinearGradientMode.BackwardDiagonal)

    ' Establecemos el tipo de trazo y los 
    ' Terminadores()
    Lapiz.DashStyle = Trazo
    Lapiz.StartCap = Terminador
    Lapiz.EndCap = Terminador

    ' y dibujamos dos l�neas, una recta y una curva
    e.Graphics.DrawLine(Lapiz, 50, 150, 200, 250)
    ' cambiando la brocha de la segunda
    Lapiz.Brush = BrochaFundido
    e.Graphics.DrawArc(Lapiz, 250, 150, 100, 150, _
     -90, 180)
  End Sub
End Class
