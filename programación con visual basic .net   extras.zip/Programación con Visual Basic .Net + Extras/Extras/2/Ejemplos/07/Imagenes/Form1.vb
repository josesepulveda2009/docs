Public Class Form1
  Inherits System.Windows.Forms.Form

  ' Para mantener la imagen en memoria
  Private Imagen As Image
#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.Filter = "Archivos gr�ficos|*.bmp;*.jpg;*.gif;*.wmf;*.emf;*.tif"
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 266)
    Me.Name = "Form1"
    Me.Text = "Form1"

  End Sub

#End Region

  ' Al hacer clic sobre el formulario
  Private Sub Form1_Click(ByVal sender As Object, _
  ByVal e As System.EventArgs) Handles MyBase.Click
    ' Si se selecciona un archivo
    If OpenFileDialog1.ShowDialog() = _
                               DialogResult.OK Then
      ' mostramos su nombre
      Me.Text = OpenFileDialog1.FileName
      ' y recuperamos la imagen
      Imagen = Image.FromFile( _
            OpenFileDialog1.FileName)
      ' estableciendo el �rea de desplazamiento
      Me.AutoScrollMinSize = Imagen.Size

      Invalidate() ' forzamos la actualizaci�n
    End If
  End Sub

  ' Cada vez que tenga que actualizarse la ventana
  Private Sub Form1_Paint(ByVal sender As Object, _
  ByVal e As System.Windows.Forms.PaintEventArgs) _
  Handles MyBase.Paint
    ' S�lo si tenemos una imagen
    If Not (Imagen Is Nothing) Then
      ' la mostramos en el formulario
      e.Graphics.DrawImage(Imagen, _
                   Me.AutoScrollPosition)
    End If
  End Sub

  ' Si se cambia el formulario de tama�o
  Private Sub Form1_Resize(ByVal sender As Object, _
  ByVal e As System.EventArgs) Handles MyBase.Resize
    Invalidate() ' actualizar la visualizaci�n
  End Sub

  ' Controlamos las pulsaciones de tecla
  Private Sub Form1_KeyPress(ByVal sender As Object, _
  ByVal e As System.Windows.Forms.KeyPressEventArgs) _
  Handles MyBase.KeyPress
    ' Si se ha pulsado "R" rotamos la imagen
    If Char.ToUpper(e.KeyChar) = "R" Then
      ' rotamos la imagen 90 grados
      Imagen.RotateFlip(RotateFlipType.Rotate90FlipNone)
      Invalidate() ' y actualizamos
    End If

    ' Si se ha pulsado "T" a�adimos un titulo
    If Char.ToUpper(e.KeyChar) = "T" Then
      Dim Grafico As Graphics
      Dim TipoLetra As Font
      ' Obtenemos un Graphics a partir de la imagen
      Grafico = Graphics.FromImage(Imagen)
      ' preparamos el tipo de letra
      TipoLetra = New Font("Courier New", 24, _
          FontStyle.Bold Or FontStyle.Italic)
      ' escribimos el t�tulo
      Grafico.DrawString("GDI+", TipoLetra, _
          Brushes.Blue, 10, 10)
      Invalidate() ' y actualizamos
    End If
  End Sub

End Class
