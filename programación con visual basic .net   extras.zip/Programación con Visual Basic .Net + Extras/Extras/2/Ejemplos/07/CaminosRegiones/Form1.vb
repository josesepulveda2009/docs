Imports System.Drawing.Drawing2D
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 266)
    Me.Name = "Form1"
    Me.Text = "Form1"

  End Sub

#End Region
  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Un rect�ngulo de las dimensiones del formulario
    Dim Rectangulo As Rectangle = New Rectangle( _
              0, 0, Me.Size.Width, Me.Size.Height)
    ' un camino
    Dim Camino As GraphicsPath = New GraphicsPath()

    ' Preparamos un c�rculo
    Camino.AddArc(Rectangulo, 0, 359)
    ' para crear una regi�n a partir de �l
    Dim Area As Region = New Region(Camino)

    ' A�adimos a la regi�n un rect�ngulo estrecho
    ' en la parte superior
    Rectangulo.Width = 100
    Rectangulo.Height = 40
    ' uni�ndolo con el c�rculo
    Area.Union(Rectangulo)

    ' establecemos la regi�n como apariencia
    ' de la ventana
    Me.Region = Area
  End Sub


  Private Sub Form1_Paint(ByVal sender As Object, _
  ByVal e As System.Windows.Forms.PaintEventArgs) _
  Handles MyBase.Paint
    ' Creamos un nuevo camino
    Dim Camino As GraphicsPath = New GraphicsPath()
    ' Matrices con los puntos de una linea curva
    Dim Puntos() As Point = { _
         New Point(50, 150), _
         New Point(75, 200), _
         New Point(120, 140)}

    With Camino ' Preparamos el camino
      .StartFigure() ' iniciando una nueva figura
      ' formada por un rect�ngulo
      .AddRectangle(New Rectangle(10, 10, 100, 100))
      ' y un arco
      .AddArc(50, 75, 100, 50, 0, 359)
      .CloseFigure() ' cerramos la figura
      .StartFigure() ' e iniciamos otra
      ' con una l�nea curva definida por los puntos
      .AddCurve(Puntos)
    End With

    ' Rellenamos el camino
    e.Graphics.FillPath(Brushes.Aqua, Camino)
    ' y dibujamos su contorno
    e.Graphics.DrawPath(Pens.Blue, Camino)

    ' Preparamos una matriz de transformaci�n
    Dim Matriz As Matrix = New Matrix()
    ' trasladando el camino en el espacio
    Matriz.Translate(200, 50)
    Matriz.Scale(0.75, 0.75)
    ' y rot�ndolo 45�
    Matriz.Rotate(45)

    ' Aplicamos la transformaci�n al camino
    Camino.Transform(Matriz)
    ' y dibujamos s�lo el contorno en rojo
    e.Graphics.DrawPath(Pens.Red, Camino)
  End Sub
End Class
