Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 266)
    Me.Name = "Form1"
    Me.Text = "Form1"

  End Sub

#End Region

  Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
    ' Creamos el l�piz inicial
    Dim Pincel As Pen = New Pen(Color.Aqua, 5)
    ' lo usamos para dibujar un rect�ngulo
    e.Graphics.FillRectangle(Brushes.Gold, 10, 10, 100, 100)
    e.Graphics.DrawRectangle(Pincel, 10, 10, 100, 100)
    ' cambiamos su color
    Pincel.Color = Color.DarkCyan
    ' y dibujamos un arco
    e.Graphics.DrawArc(Pincel, 100, 100, 50, 50, 0, 180)
    ' cambiamos color y grosor
    Pincel.Color = Color.Blue
    Pincel.Width = 8
    ' y dibujamos una l�nea
    e.Graphics.DrawLine(Pincel, 10, 10, 110, 110)

    ' Creamos el objeto Font
    Dim TipoLetra As Font = New Font( _
      "Courier New", 14, _
      FontStyle.Underline Or FontStyle.Bold)
    ' Insertamos un texto
    e.Graphics.DrawString("GDI+ y Visual Basic.NET", _
                      TipoLetra, Brushes.Blue, 10, 200)
  End Sub
End Class
