Imports System

Namespace Anaya.GuiaVBNET.Visibilidad

    ' Tenemos una clase p�blica
    Public Class ClaseBase
        ' con algunas variables en distintos �mbitos
        Dim AmbitoDefecto As Integer
        Private AmbitoPrivado As Integer
        Protected AmbitoProtegido As Integer
        Friend AmbitoInterno As Integer
        Protected Friend AmbitoProtegidoeInterno As Integer
        Public AmbitoPublico As Integer

        Public Sub New()
            ' Aqu� podemos acceder a todos los miembros
            AmbitoDefecto = 5
            AmbitoPrivado = 2
            AmbitoProtegido = 10
            AmbitoInterno = 15
            AmbitoProtegidoeInterno = 12
            AmbitoPublico = 20
        End Sub

        ' Este m�todo muestra los valores de 
        ' los miembros
        Public Overridable Sub Muestra()

            Console.WriteLine("ClaseBase.Muestra()")
            Console.WriteLine("-------------------")
            Console.WriteLine("AmbitoDefecto = {0}", _
                               AmbitoDefecto)
            Console.WriteLine("AmbitoPrivado = {0}", _
                               AmbitoPrivado)
            Console.WriteLine("AmbitoProtegido = {0}", _
                               AmbitoProtegido)
            Console.WriteLine("AmbitoInterno = {0}", _
                               AmbitoInterno)
            Console.WriteLine( _
                   "AmbitoProtegidoeInterno = {0}", _
                   AmbitoProtegidoeInterno)
            Console.WriteLine("AmbitoPublico = {0}", _
                               AmbitoPublico)
            Console.WriteLine("-------------------")
        End Sub

    End Class ' Fin de la clase base

    ' Una clase derivada de la anterior
    Class ClaseDerivada
        Inherits ClaseBase

        ' en el constructor modificamos los
        ' miembros heredados
        Public Sub New()
            ' AmbitoDefecto++;
            ' AmbitoPrivado++;
            AmbitoProtegido += 1
            AmbitoInterno += 1
            AmbitoProtegidoeInterno += 1
            AmbitoPublico += 1
        End Sub

        ' Este m�todo muestra los valores de 
        ' los miembros
        Public Overrides Sub Muestra()
            Console.WriteLine("ClaseDerivada.Muestra()")
            Console.WriteLine("-------------------")
            ' Console.WriteLine("AmbitoDefecto = {0}", _
            ' AmbitoDefecto)
            ' Console.WriteLine("AmbitoPrivado = {0}", _
            ' AmbitoPrivado)
            Console.WriteLine("AmbitoProtegido = {0}", _
                   AmbitoProtegido)
            Console.WriteLine("AmbitoInterno = {0}", _
                   AmbitoInterno)
            Console.WriteLine( _
                    "AmbitoProtegidoeInterno = {0}", _
                    AmbitoProtegidoeInterno)
            Console.WriteLine("AmbitoPublico = {0}", _
                    AmbitoPublico)
            Console.WriteLine("-------------------")
        End Sub

    End Class ' Fin de la clase derivada

    ' Esta clase es independiente de la anterior
    Class Principal
        ' Este m�todo muestra los valores de miembros
        Public Shared Sub _
     Muestra(ByVal MiClaseBase As ClaseBase)
            Console.WriteLine("Principal.Muestra()")
            Console.WriteLine("-------------------")
            ' Console.WriteLine("AmbitoDefecto = {0}", _
            ' MiClaseBase.AmbitoDefecto)
            ' Console.WriteLine("AmbitoPrivado = {0}", _
            ' MiClaseBase.AmbitoPrivado)
            ' Console.WriteLine("AmbitoProtegido = {0}", _
            ' MiClaseBase.AmbitoProtegido)
            Console.WriteLine("AmbitoInterno = {0}", _
                    MiClaseBase.AmbitoInterno)
            Console.WriteLine( _
                    "AmbitoProtegidoeInterno = {0}", _
                    MiClaseBase.AmbitoProtegidoeInterno)
            Console.WriteLine("AmbitoPublico = {0}", _
                    MiClaseBase.AmbitoPublico)
            Console.WriteLine("-------------------")
        End Sub

        Shared Sub Main()
            ' Creamos un objeto de la clase 
            ' base o derivada
            Dim MiClaseBase As ClaseBase = New ClaseBase()
            Dim MiClaseDerivada As ClaseDerivada = New ClaseDerivada()

            MiClaseBase.Muestra()
            MiClaseDerivada.Muestra()
            Muestra(MiClaseBase)
        End Sub
    End Class ' Fin de la clase Principal

End Namespace ' Fin del espacio con nombre
