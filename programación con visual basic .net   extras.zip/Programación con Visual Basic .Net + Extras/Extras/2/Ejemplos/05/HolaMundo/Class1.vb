Namespace ClasesAnaya
    ' ClasesAnaya es el espacio superior

    Namespace GuiaVSNET
        ' GuiaVSNET es un espacio interior
        Public Class HolaMundo
            ' con una clase llamada HolaMundo
            Public Function Saludo() As String
                Return _
          "Hola desde el �mbito Anaya.GuiaVSNET"
            End Function
        End Class
    End Namespace

    Namespace GuiaVBNET
        ' GuiaNET es otro espacio interior
        Public Class HolaMundo
            ' tambi�n tiene una clase HolaMundo
            Public Function Saludo() As String
                Return _
          "Hola desde el �mbito Anaya.GuiaVBNET"
            End Function
        End Class
    End Namespace

End Namespace
