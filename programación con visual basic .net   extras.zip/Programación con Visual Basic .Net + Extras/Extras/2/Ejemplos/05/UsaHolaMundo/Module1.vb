Imports System
Imports VS = ClasesAnaya.GuiaVSNET ' Incluimos referencia
Imports VB = ClasesAnaya.GuiaVBNET ' a los dos �mbitos

Module Module1

    Sub Main()
        Dim MiHolaMundo As VB.HolaMundo = New VB.HolaMundo()

        Console.WriteLine(MiHolaMundo.Saludo())
    End Sub

End Module
