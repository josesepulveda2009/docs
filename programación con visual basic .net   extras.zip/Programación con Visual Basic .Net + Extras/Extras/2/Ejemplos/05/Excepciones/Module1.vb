Module Module1

    Sub Main()
        ' Variables para los valores 
        Dim Cociente As Byte
        Dim Dividendo, Divisor As Integer

        Try
            ' Solicitamos la introducci�n de los datos
            Console.WriteLine("Introduzca el dividendo: ")
            ' y convertimos a n�mero
            Dividendo = CInt(Console.ReadLine())
            Console.WriteLine("Introduzca el divisor: ")
            ' La conversi�n puede generar una excepci�n
            Divisor = CInt(Console.ReadLine())

            ' Efectuamos la divisi�n
            Cociente = Dividendo \ Divisor
            ' y mostramos el resultado
            Console.WriteLine("El resultado es {0}", Cociente)

            ' Si se produce una divisi�n por cero
        Catch X As DivideByZeroException
            Console.WriteLine("Se ha producido una divisi�n por cero")
            ' Si se ha producido un desbordamiento
        Catch X As OverflowException
            Console.WriteLine("Se ha producido un desbordamiento")
            ' En cualquier otro error aritm�tico
        Catch X As ArithmeticException
            Console.WriteLine("Se ha producido otro error aritm�tico")
            Console.WriteLine(X.Message)
            Console.WriteLine(X.ToString)
        End Try
        Console.ReadLine()
    End Sub

End Module
