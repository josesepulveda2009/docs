Imports System

Namespace Anaya.GuiaVBNET.ListaParametros

  Class ParametrosMetodos
    ' Un m�todo compartido, que puede utilizarse 
    ' directamente sin necesidad de crear un 
    ' objeto de la clase.
    ' Recibe una lista variable de par�metros
    Shared Sub Metodo(ByVal ParamArray Parametros() As Object)

      Dim Parametro As Object
      Dim Ind As Byte = 1
      ' mostramos el n�mero de par�metros 
      Console.WriteLine("Hay {0} par�metros", _
           Parametros.Length)

      ' recorremos la lista de par�metros
      For Each Parametro In Parametros
        ' mostrando el valor y su tipo
        Console.WriteLine( _
           "Par�metro {0}: Valor->{1}, Tipo->{2}", _
          Ind, Parametro, _
           Parametro.GetType().FullName)
        Ind += 1
      Next
    End Sub

    Shared Function Numero() As Integer
      Return 5
    End Function

    ' Al iniciar el programa simplemente llamamos 
    ' al m�todo anterior con una lista de 
    ' par�metros cualquiera
    Shared Sub Main()
      Metodo("Una cadena", 2, True, 7.5, _
             "Otra cadena")
      Console.WriteLine(Numero())
    End Sub
  End Class
End Namespace
