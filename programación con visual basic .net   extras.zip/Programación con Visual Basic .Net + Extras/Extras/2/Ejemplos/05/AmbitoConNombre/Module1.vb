Namespace Anaya.GuiaVBNET
    Class HolaMundo
        Public Shared Sub Main()
            System.Console.WriteLine("Hola desde Anaya.GuiaVBNET")
        End Sub
    End Class
End Namespace
