Class Agenda
    ' Constructor sin par�metros
    Shared Sub New()
        Console.WriteLine("Constructor de clase")
    End Sub

    Public Sub New()
        Console.WriteLine("Constructor por defecto")
    End Sub

    ' y con un par�metro
    Public Sub New(ByVal Parametro As String)
        Console.WriteLine("Constructor " & Parametro)
    End Sub

    ' Destructor
    Protected Overrides Sub Finalize()
        Console.WriteLine("Destructor")
    End Sub
End Class

Module Module1

    Sub Main()
        ' sin par�metros
        Dim MiAgenda As Agenda = New Agenda()
        ' con par�metros
        Dim OtraAgenda As Agenda = New Agenda("Par�metro")

    End Sub

End Module
