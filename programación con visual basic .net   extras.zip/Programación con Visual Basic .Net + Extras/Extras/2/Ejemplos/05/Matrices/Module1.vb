Imports System
Module Module1

    Public Structure Anotacion
        Public Fecha As Date
        Public Anotador As String
        Public Nota As String
        Public Sub New(ByVal F As Date, _
          ByVal A As String, ByVal N As String)
            Fecha = F
            Anotador = A
            Nota = N
        End Sub
    End Structure
    Sub Main()
        Dim ListaDatos(10) As Integer
        Dim MiAnotacion As Anotacion

        MiAnotacion = New Anotacion(Now, "Francisco", "Hay que llamar a los pintores")

        With MiAnotacion
            System.Console.WriteLine(.Fecha & " - " & .Anotador & " - " & .Nota)
        End With

        System.Console.WriteLine(ListaDatos.GetLength(0))
    End Sub

End Module
