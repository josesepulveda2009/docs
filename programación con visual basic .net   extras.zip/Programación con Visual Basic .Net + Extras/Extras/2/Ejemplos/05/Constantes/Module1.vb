Imports System

Namespace Anaya.GuiaVNET.Constantes

  Class Aplicacion

    Const SegundosMinuto As Integer = 60
    Const MinutosHora As Integer = 60
    Const HorasDia As Integer = 24

    Shared Sub Main()
      Console.WriteLine("Un d�a tiene {0} segundos", _
       SegundosMinuto * MinutosHora * HorasDia)
    End Sub
  End Class
End Namespace
