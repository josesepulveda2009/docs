Imports System

' Toda la aplicaci�n se incluye en un �mbito con 
' nombre que evita conflictos con otros proyectos
Namespace Anaya.GuiaVBNET.ClasesAnidadas

    Class Agenda  ' Nuestra clase de primer nivel

        Public N As Integer
        Class Anotacion  ' contiene a otra
            ' �sta tiene un constructor de clase
            Shared Sub New()
                Console.WriteLine( _
                   "Constructor de clase de Anotacion")
            End Sub

            ' un constructor sin par�metros
            Public Sub New()
                Console.WriteLine( _
                   "Constructor de Anotacion")
            End Sub

            ' y un constructor con un par�metro
            Public Sub New(ByVal Parametro As String)
                Console.WriteLine( _
                    "Constructor {0}", Parametro)
            End Sub

            ' destructor
            Protected Overrides Sub Finalize()
                Console.WriteLine( _
                  "Destructor de Anotacion")
            End Sub
        End Class ' Fin de la clase Anotacion

        ' Esta declaraci�n pertenece a la clase Agenda
        Private MiAnotacion As Anotacion

        ' Al construir un objeto de esta clase
        Public Sub New()
            Console.WriteLine("Constructor de Agenda")
            ' creamos uno de la clase Anotacion
            MiAnotacion = New _
                   Anotacion("Nueva anotaci�n")
        End Sub

        ' Al destruir el objeto
        Protected Overrides Sub Finalize()
            Console.WriteLine("Destructor de Agenda")
            ' liberamos la referencia, aunque realmente
            ' no ser�a necesario
            MiAnotacion = Nothing
        End Sub
    End Class ' Fin de la clase Agenda

    ' Esta clase contiene simplemente el m�todo 
    ' Main(), que pone en marcha la aplicaci�n 
    ' creando un objeto Agenda
    Class Principal
        Shared Sub Main()
            Dim MiAgenda As Agenda = New Agenda()
            Console.WriteLine("Objeto creado")
            MiAgenda = Nothing
            Console.WriteLine("Fin de la aplicaci�n")
        End Sub
    End Class ' Fin de la clase Principal

End Namespace ' Fin del �mbito con nombre
