Imports System

Namespace Anaya.GuiaVBNET.Propiedades

  ' Esta clase tiene como miembros
  Class Ficha
    ' dos variables privadas
    Private Pnombre As String, Pdireccion As String

    ' el constructor sin par�metros tambi�n
    ' es privado, de tal forma que no sea posible
    ' crear un objeto de esta clase con �l
    Private Sub New()
      '
    End Sub

    ' siendo obligatorio el uso de este
    ' segundo constructor
    Public Sub New(ByVal N As String, ByVal D As String)
      Pnombre = N
      Pdireccion = D
    End Sub

    ' La propiedad Nombre s�lo puede leerse
    Public ReadOnly Property Nombre() As String
      Get
        Return Pnombre
      End Get
    End Property

    ' La propiedad Direcci�n puede leerse
    ' y escribirse
    Public Property Direccion() As String
      Get
        Return Pdireccion
      End Get
      Set(ByVal Value As String)
        Pdireccion = Value
      End Set
    End Property
  End Class

  ' Usamos desde esta clase un objeto 
  ' de la anterior
  Class Aplicacion
    Shared Sub Main()

      Dim MiFicha As Ficha = New _
          Ficha("Francisco Charte", "El Almendral")
      Console.WriteLine("{0} -> {1}", _
         MiFicha.Nombre, MiFicha.Direccion)
      ' MiFicha.Nombre = "Paco Charte";
      MiFicha.Direccion = "El Nogal"
      Console.WriteLine("{0} -> {1}", _
        MiFicha.Nombre, MiFicha.Direccion)

    End Sub
  End Class
End Namespace
